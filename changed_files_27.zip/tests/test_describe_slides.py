"""describe_slides.py: found by Excel id or title, and it always says what it found and why
nothing was sent (no more silent 'Described 0')."""
from __future__ import annotations

import sys

from PIL import Image
from test_end_to_end import _prepare_one_recording

import describe_slides
import store


def _slides(vid: str, texts: list[str]) -> None:
    folder = store.slides_dir(vid)
    folder.mkdir(parents=True, exist_ok=True)
    slides = []
    for i, text in enumerate(texts):
        Image.new("RGB", (64, 36), "white").save(folder / f"slide_{i:03d}.jpg")
        slides.append({"id": f"{vid}@{i:03d}", "video_id": vid, "start": i * 10.0, "end": i * 10.0 + 10,
                       "file": f"slides/slide_{i:03d}.jpg", "text": text, "is_slide": len(text) >= 25,
                       "segment_ids": []})
    store.save_slides(vid, slides)


def test_found_by_excel_id_and_explained(gateway, monkeypatch, capsys):
    vid = _prepare_one_recording()                                  # Excel id 13, "Joining data"
    _slides(vid, ["Excel - Home Insert Formulas Data VLOOKUP(A2;B:C;2;0)", "x", "Alteryx Input -> Join -> Output tool"])
    monkeypatch.setattr(sys, "argv", ["describe_slides.py", "--video", "13", "--limit", "1"])
    assert describe_slides.main() == 0
    out = capsys.readouterr().out
    assert "Joining data" in out and "1 left (run again)" in out            # 3 screens, 2 with text, 1 described
    assert [bool(s.get("visual")) for s in store.load_slides(vid)] == [True, False, False]
    monkeypatch.setattr(sys, "argv", ["describe_slides.py", "--video", "joining"])
    describe_slides.main()
    assert "all described" in capsys.readouterr().out


def test_wrong_reference_and_no_text_are_explained(gateway, monkeypatch, capsys, caplog):
    vid = _prepare_one_recording()
    monkeypatch.setattr(sys, "argv", ["describe_slides.py", "--video", "99"])
    assert describe_slides.main() == 1 and "No processed recording matches '99'" in caplog.text
    _slides(vid, ["", "ab"])
    monkeypatch.setattr(sys, "argv", ["describe_slides.py", "--video", vid])
    assert describe_slides.main() == 0
    assert "no readable text on the screens" in capsys.readouterr().out

"""
retrieval.py - finds the excerpts that answer a question, as precisely as possible.

Three ways, so they can be compared (RETRIEVAL in .env, or qa_eval.py --compare):
  meaning         the meaning search of index.py alone (embeddings): finds the topic in other words
  hybrid          + a word search (BM25): finds exact names, terms, acronyms and numbers that a
                  meaning search can miss; the two rankings are fused (reciprocal rank fusion)
  hybrid+rerank   + the model reads the ~30 best candidates and scores how well each one answers
                  the question (0-3); only the ones that really answer it are kept (default, best)

Source priority (SOURCE_PRIORITY in .env, e.g. "document=1.3,Scrum Guide=1.5"): a weight per
source kind (recording, document) or per text in the title; it raises those sources in the
ranking, and the model is told which sources have priority when sources disagree.

Every excerpt keeps where it is: recording + time (03:10-04:05) and the slide on screen then, or
document + page / slide / section.

  uv run retrieval.py "What is the Definition of Done?"          # show what would be used
  uv run retrieval.py "What is a sprint?" --mode hybrid -k 10
"""
from __future__ import annotations

import argparse
import logging
import math
import re
import sys
from collections import Counter

import config
import index
import llm
import store

log = logging.getLogger("retrieval")

MODES = ("meaning", "hybrid", "hybrid+rerank")
CANDIDATES = 30      # how many fused candidates the model reads
KEEP = 8             # how many excerpts an answer is written from (at most)
RRF_K = 60           # reciprocal rank fusion constant (the usual value)

STOP = set("""a an the and or but if of to in on at by for with from as is are was were be been being it its this that
these those there here what which who whom whose how why when where do does did done can could should would will shall
may might must i you he she we they me him her us them my your our their mine yours not no yes so than then too very
just also about into over under again more most some any each every all both few other such only own same s t don
""".split())


def words(text: str) -> list[str]:
    """Lower-case words and numbers, without common filler words, plurals folded ('sprints' = 'sprint')."""
    out = []
    for w in re.findall(r"[a-z0-9]+(?:[-'][a-z0-9]+)*", (text or "").lower()):
        if w in STOP or len(w) < 2:
            continue
        if len(w) > 4 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        out.append(w)
    return out


def segment_text(seg: dict) -> str:
    """What a word search sees of an excerpt: its title, the slide on screen and what was said."""
    return " ".join(x for x in (seg.get("title", ""), seg.get("slide_text", ""), seg.get("text", "")) if x)


class BM25:
    """Okapi BM25 over all excerpts: the classic word search (k1=1.5, b=0.75)."""

    def __init__(self, segments: dict[str, dict], k1: float = 1.5, b: float = 0.75):
        self.ids = list(segments)
        self.docs = [Counter(words(segment_text(segments[i]))) for i in self.ids]
        self.lens = [sum(d.values()) for d in self.docs]
        self.avg = (sum(self.lens) / len(self.lens)) if self.lens else 1.0
        df = Counter(w for d in self.docs for w in d)
        n = len(self.docs)
        self.idf = {w: math.log(1 + (n - f + 0.5) / (f + 0.5)) for w, f in df.items()}
        self.k1, self.b = k1, b

    def search(self, query: str, top_k: int = 60) -> list[tuple[str, float]]:
        q = [w for w in dict.fromkeys(words(query)) if w in self.idf]
        scores = []
        for i, d in enumerate(self.docs):
            s = 0.0
            for w in q:
                tf = d.get(w, 0)
                if tf:
                    s += self.idf[w] * tf * (self.k1 + 1) / (tf + self.k1 * (1 - self.b + self.b * self.lens[i] / self.avg))
            if s > 0:
                scores.append((self.ids[i], s))
        scores.sort(key=lambda x: -x[1])
        return scores[:top_k]


_bm25: tuple[tuple, BM25] | None = None


def bm25() -> BM25:
    """The word index, built in memory once per run (a few thousand excerpts: well under a second)."""
    global _bm25
    segs = store.all_segments()
    key = (len(segs), next(iter(segs), ""), next(reversed(segs), "") if segs else "")
    if _bm25 is None or _bm25[0] != key:
        _bm25 = (key, BM25(segs))
    return _bm25[1]


def priority_rules() -> list[tuple[str, float]]:
    """SOURCE_PRIORITY='document=1.3,Scrum Guide=1.5' -> [('document', 1.3), ('scrum guide', 1.5)]."""
    out = []
    for part in (config.SOURCE_PRIORITY or "").split(","):
        key, _, value = part.partition("=")
        try:
            if key.strip():
                out.append((key.strip().lower(), float(value)))
        except ValueError:
            log.warning("SOURCE_PRIORITY: %r is not name=number, ignored", part)
    return out


def priority(seg: dict) -> float:
    """The weight of an excerpt's source: kind (recording / document) or text in its title."""
    weight = 1.0
    for key, w in priority_rules():
        if key == seg.get("kind", "recording") or key in seg.get("title", "").lower():
            weight *= w
    return weight


def where(seg: dict) -> str:
    """Where an excerpt is, for a person to find it: '03:10-04:05 · slide "Three roles"' in a
    recording, 'page 2' / 'slide 4' / a section in a document."""
    place = store.location(seg)
    if seg.get("kind") != "document" and seg.get("slide_text"):
        title = next((ln.strip() for ln in seg["slide_text"].splitlines() if len(ln.strip()) > 2), "")
        if title:
            place += f' · slide "{title[:60]}"'
    return place


def fuse(question: str, video_ids: set[str] | None = None, mode: str = "hybrid", top_k: int = CANDIDATES) -> list[dict]:
    """The candidates, best first: [{'segment', 'meaning', 'words', 'score', 'rank_meaning', 'rank_words'}]."""
    segs = store.all_segments()
    meaning = index.search(question, top_k=max(60, top_k), video_ids=video_ids)
    found: dict[str, dict] = {}
    for r, h in enumerate(meaning, 1):
        found[h["segment"]["id"]] = {"segment": h["segment"], "meaning": h["score"], "words": 0.0,
                                     "rank_meaning": r, "rank_words": None}
    if mode != "meaning":
        for r, (sid, s) in enumerate(bm25().search(question, top_k=max(60, top_k)), 1):
            seg = segs.get(sid)
            if seg is None or (video_ids and seg["video_id"] not in video_ids):
                continue
            item = found.setdefault(sid, {"segment": seg, "meaning": 0.0, "words": 0.0, "rank_meaning": None,
                                          "rank_words": None})
            item.update(words=round(s, 3), rank_words=r)
    for item in found.values():
        rrf = sum(1 / (RRF_K + r) for r in (item["rank_meaning"], item["rank_words"]) if r)
        item["score"] = round(rrf * priority(item["segment"]) * 1000, 3)
        if mode == "meaning":
            item["score"] = round(item["meaning"] * priority(item["segment"]), 3)
    return sorted(found.values(), key=lambda x: -x["score"])[:top_k]


RERANK = """You rank excerpts from training recordings and documents by how well they answer a learner's question.
For each excerpt give a score: 3 = answers the question directly; 2 = gives important facts for the answer;
1 = same topic but does not help answer; 0 = not related. Judge only what the excerpt says, not what you know.
Be strict: a passing mention of a word is 1, not 2.
Answer with one line per excerpt, in this form and nothing else:
C1: 3 - reason in at most 8 words
C2: 0 - reason in at most 8 words"""

LINE = re.compile(r"^\W*C(\d+)\W+([0-3])\b(?:\W+(.*))?$", re.M)                       # C1: 3 - why
JSONISH = re.compile(r'"id"\s*:\s*"?C?(\d+)"?\s*,\s*"score"\s*:\s*([0-3])(?:\s*,\s*"why"\s*:\s*"([^"]*))?')


def parse_scores(text: str, n: int) -> dict[int, tuple[int, str]]:
    """{candidate index: (score, why)} from the model's reply: 'C1: 3 - why' lines, or JSON-like
    {"id": "C1", "score": 3}. Tolerates code fences, extra text and a reply cut off at the end."""
    found = LINE.findall(text) or JSONISH.findall(text)
    out = {}
    for num, score, why in found:
        if 1 <= int(num) <= n and int(num) - 1 not in out:
            out[int(num) - 1] = (int(score), (why or "").strip().strip('"'))
    return out


def rerank(question: str, candidates: list[dict], keep: int = KEEP) -> list[dict]:
    """The model scores each candidate (0-3); the ones scored 2-3 are kept, best first. If the
    model can't be reached or scores too few, the search order is used (and noted)."""
    if not candidates:
        return []
    lines = []
    for n, c in enumerate(candidates, 1):
        seg = c["segment"]
        text = " ".join(segment_text(seg).split()[:140])
        lines.append(f"[C{n}] {seg.get('title', '')} ({where(seg)}): {text}")
    prompt = f"Question: {question}\n\nExcerpts:\n" + "\n\n".join(lines)
    try:
        reply = llm.chat(prompt, system=RERANK, step="rerank", model=config.RERANK_MODEL or None,
                         temperature=0.0, max_tokens=60 + 25 * len(candidates))
        scores = parse_scores(reply, len(candidates))
        if len(scores) < len(candidates) / 2:
            raise llm.LLMError(f"only {len(scores)} of {len(candidates)} excerpts scored; start of reply: {reply[:120]!r}")
    except llm.LLMError as e:
        log.warning("Rerank failed (%s); using the search order", str(e)[:200])
        for c in candidates:
            c["rerank"] = None
        return candidates[:keep]
    for i, c in enumerate(candidates):
        c["rerank"], c["why"] = scores.get(i, (0, "not scored"))
    good = [c for c in candidates if c["rerank"] >= 2]
    good.sort(key=lambda c: (-c["rerank"], -c["score"]))
    return good[:keep]


def retrieve(question: str, mode: str | None = None, keep: int = KEEP, video_ids: set[str] | None = None) -> dict:
    """The excerpts to answer from: {'mode', 'candidates' (all, with scores), 'kept' (in order)}.
    An empty 'kept' means the material doesn't cover the question."""
    mode = mode or config.RETRIEVAL
    if mode not in MODES:
        raise ValueError(f"Unknown retrieval mode {mode!r}; use one of {', '.join(MODES)}")
    candidates = fuse(question, video_ids, mode)
    if mode == "hybrid+rerank":
        kept = rerank(question, candidates, keep)
    else:
        # without the model: the best ones, if the meaning search found anything close enough
        best = max((c["meaning"] for c in candidates), default=0.0)
        kept = candidates[:keep] if best >= config.MIN_SCORE else []
    return {"mode": mode, "candidates": candidates, "kept": kept}


def with_neighbours(kept: list[dict], limit: int = 12) -> list[dict]:
    """The kept excerpts plus the minute before and after each (a single minute is rarely
    self-contained), in reading order: per source, then by position. Each keeps its own place."""
    segs = store.all_segments()
    by_pos = {(s["video_id"], s["idx"]): s for s in segs.values()}
    chosen: dict[str, dict] = {c["segment"]["id"]: c["segment"] for c in kept}
    for c in kept:
        if len(chosen) >= limit:
            break
        seg = c["segment"]
        for d in (-1, 1):
            n = by_pos.get((seg["video_id"], seg["idx"] + d))
            if n and n["id"] not in chosen and len(chosen) < limit:
                chosen[n["id"]] = n
    order = {c["segment"]["video_id"]: i for i, c in enumerate(kept)}
    return sorted(chosen.values(), key=lambda s: (order.get(s["video_id"], 99), s["video_id"], s["idx"]))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("question")
    ap.add_argument("--mode", choices=MODES, help="default: RETRIEVAL in .env")
    ap.add_argument("-k", type=int, default=KEEP)
    args = ap.parse_args()
    config.setup_logging()
    r = retrieve(args.question, args.mode, args.k)
    print(f"Mode {r['mode']}: {len(r['kept'])} excerpts kept of {len(r['candidates'])} candidates\n")
    for c in r["kept"] or r["candidates"][:args.k]:
        seg = c["segment"]
        extra = f" model {c['rerank']}/3 ({c.get('why', '')})" if c.get("rerank") is not None else ""
        print(f"- {seg['title']} · {where(seg)}  meaning {c['meaning']:.2f} words {c['words']:.1f}{extra}")
        print("   " + " ".join(seg["text"].split()[:30]) + " ...")
    if not r["kept"]:
        print("\nNothing answers this well enough: the material doesn't seem to cover it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

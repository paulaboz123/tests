"""
answer.py - answers a question in text, from the knowledge base only, with the source of every
sentence: which recording or document, where in it (time, slide, page, section), and the exact
words that support it.

  uv run answer.py "What is coffee?"
  uv run answer.py "Who orders the Product Backlog?" --length medium --level intermediate
  uv run answer.py "What happens in the Daily Scrum?" --mode hybrid     # compare retrieval modes

How it works:
 1. Find (retrieval.py): meaning search + word search, fused, weighted by source priority; then
    the model reads the ~30 best candidates and keeps the ones that really answer the question.
    Each kept excerpt brings the minute before and after.
 2. Write: Claude answers from those excerpts only. Most important information first, in its own
    words (the original wording only for a term or short definition, in quotes). Every sentence
    lists its excerpts and an evidence quote: the shortest exact words that support it.
    If the material does not answer the question, it says so and writes no answer.
 3. Check, without a model:
      sources     every sentence cites real excerpts (invented labels are removed and counted)
      evidence    every evidence quote is found word for word in the cited excerpt
      numbers     every number in the answer is in the cited excerpts
      copying     share of the answer copied word for word (8-word sequences); above COPY_LIMIT
                  the answer is rewritten once in own words
 4. Save answer.md (to read: the answer with [1] [2] and the sources with time and evidence),
    answer.json (everything, for qa_eval.py) and the run card (models, cost).
"""
from __future__ import annotations

import argparse
import difflib
import logging
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import config
import facts
import llm
import retrieval
import runcard
import safety
import store

log = logging.getLogger("answer")

LENGTHS = {"short": "2-4 sentences, about 50-100 words", "medium": "about 120-220 words",
           "long": "about 250-400 words, with the key details"}

SYSTEM = """You answer a learner's question using ONLY the excerpts given. They come from the company's training
recordings and documents.

Rules:
- Use only what the excerpts say. Do not add facts from your own knowledge, even if you know the topic well. If the
  excerpts do not answer the question, set "not_in_material" to true and give no sentences.
- Most important first: the direct answer in the first sentence, then the key details a learner needs. Leave out small
  talk, repetitions and side remarks.
- Write in your own words: summarise and paraphrase, in clear new sentences. Keep the original wording only for a term
  or a short definition, and then put it in quotes.
- Every sentence lists the labels of the excerpts it is based on (e.g. ["S2", "S5"]) and "evidence": the shortest
  exact words (at most 25) from one of those excerpts that support the sentence, copied character by character.
- If excerpts disagree, say so in a sentence and cite both. Prefer sources marked "priority: high".
- If part of the question is not covered, say which part in "not_covered".
- Plain English for a learner at level {level}. Length: {length}."""

SCHEMA = {"type": "object", "properties": {
    "not_in_material": {"type": "boolean"},
    "sentences": {"type": "array", "items": {"type": "object", "properties": {
        "text": {"type": "string"}, "sources": {"type": "array", "items": {"type": "string"}},
        "evidence": {"type": "string"}}, "required": ["text", "sources", "evidence"]}},
    "not_covered": {"type": "string"}}, "required": ["not_in_material", "sentences"]}

REWRITE = """You rewrite an answer for a learner in your own words: new, clear sentences with the same meaning,
no new facts. Keep each sentence's "sources" and "evidence" exactly as they are. Quote the original wording only
for a term or a short definition."""


# --- Excerpts for the prompt ----------------------------------------------------------------------
def material(segments: list[dict]) -> tuple[str, dict[str, dict]]:
    """The excerpts with labels S1..Sn, each with its source, place and priority."""
    labels, blocks, shown = {}, [], set()
    for n, seg in enumerate(segments, 1):
        label = f"S{n}"
        labels[label] = seg
        weight = retrieval.priority(seg)
        prio = " · priority: high" if weight > 1.0 else " · priority: low" if weight < 1.0 else ""
        head = f'[{label}] {store.source_kind(seg)} "{seg.get("title", "")}" · {retrieval.where(seg)}{prio}'
        slide = ""
        if seg.get("slide_text") and seg.get("slide_text") not in shown:
            shown.add(seg["slide_text"])
            slide = f"\nOn screen: {seg['slide_text'][:400]}"
        blocks.append(f"{head}{slide}\n{seg.get('text', '')}")
    return "\n\n".join(blocks), labels


# --- Checks (no model) ------------------------------------------------------------------------------
def tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", (text or "").lower())


def evidence_found(evidence: str, source: str) -> bool:
    """The evidence quote is in the source: word for word (ignoring case and punctuation), or with
    a small slip: at least 80% of its words, in order, in one place of the source."""
    ev, src = tokens(evidence), tokens(source)
    if len(ev) < 2:
        return False
    if " ".join(ev) in " ".join(src):
        return True
    m = difflib.SequenceMatcher(None, ev, src, autojunk=False).find_longest_match(0, len(ev), 0, len(src))
    if not m.size:
        return False
    lo = max(0, m.b - m.a - 3)   # the part of the source around the best match
    window = src[lo:lo + len(ev) + 6]
    matched = sum(b.size for b in difflib.SequenceMatcher(None, ev, window, autojunk=False).get_matching_blocks())
    return matched / len(ev) >= 0.8


def copy_stats(text: str, sources: list[str], n: int = 8) -> tuple[float, int]:
    """(share of the answer's 8-word sequences found word for word in the excerpts, longest copied
    run in words). Below ~0.2 is written in own words; definitions in quotes may add a little."""
    a = tokens(text)
    src = [tokens(s) for s in sources]
    grams = {tuple(t[i:i + n]) for t in src for i in range(len(t) - n + 1)}
    total = max(0, len(a) - n + 1)
    copied = sum(1 for i in range(total) if tuple(a[i:i + n]) in grams)
    longest = 0
    for t in src:
        if a and t:
            m = difflib.SequenceMatcher(None, a, t, autojunk=False).find_longest_match(0, len(a), 0, len(t))
            longest = max(longest, m.size)
    return (round(copied / total, 3) if total else 0.0), longest


def unsupported_numbers(sentence: str, sources: list[str]) -> list[str]:
    """Numbers in a sentence that none of its cited excerpts contain (0-2 are ignored: 'one of', 'two roles')."""
    text = " ".join(sources)
    return [facts.fmt(x) for x in facts.numbers_in(sentence) if abs(x) > 2 and not facts.grounded(x, text)]


def check(result: dict, labels: dict[str, dict]) -> dict:
    """The checks of an answer, per sentence and in total."""
    texts = {k: f"{s.get('slide_text', '')}\n{s.get('text', '')}" for k, s in labels.items()}
    invalid, unsourced, no_evidence, numbers = [], 0, 0, []
    for s in result["sentences"]:
        real = [x for x in s.get("sources", []) if x in labels]
        invalid += [x for x in s.get("sources", []) if x not in labels]
        s["sources"] = real
        cited = [texts[x] for x in real]
        s["evidence_ok"] = bool(real) and any(evidence_found(s.get("evidence", ""), t) for t in cited)
        s["numbers_not_in_sources"] = unsupported_numbers(s["text"], cited) if real else []
        unsourced += not real
        no_evidence += not s["evidence_ok"]
        numbers += s["numbers_not_in_sources"]
    body = " ".join(s["text"] for s in result["sentences"])
    rate, longest = copy_stats(body, list(texts.values()))
    n = len(result["sentences"]) or 1
    return {"sentences": len(result["sentences"]), "invalid_labels": sorted(set(invalid)),
            "unsourced_sentences": unsourced, "evidence_verified": round(1 - no_evidence / n, 3) if result["sentences"] else None,
            "numbers_not_in_sources": numbers, "copy_rate": rate, "longest_copy_words": longest,
            "words": len(body.split())}


# --- The answer -------------------------------------------------------------------------------------
def write(question: str, labels: dict[str, dict], text: str, level: str, length: str, model: str | None) -> dict:
    system = SYSTEM.format(level=level, length=LENGTHS.get(length, LENGTHS["short"]))
    prompt = f"Question: {question}\n\nExcerpts:\n{text}"
    out = None
    for attempt in range(2):   # one retry if the reply is broken or cites only invented labels
        try:
            out = llm.chat_json(prompt, SCHEMA, system=system, step="answer", model=model, temperature=0.2)
        except llm.LLMError as e:
            if attempt:
                raise
            log.warning("Answer not valid (%s); asking again", e)
            continue
        cited = [x for s in out.get("sentences", []) for x in s.get("sources", [])]
        if out.get("not_in_material") or not cited or any(x in labels for x in cited):
            break
        log.warning("The answer cited no real excerpt; asking again")
    out = out or {"not_in_material": True, "sentences": []}
    out.setdefault("not_covered", "")
    out["sentences"] = [s for s in out.get("sentences", []) if (s.get("text") or "").strip()]
    if out.get("not_in_material"):
        out["sentences"] = []
    return out


def rewrite(result: dict, model: str | None) -> dict:
    """Once, if too much was copied word for word: the same answer in own words."""
    import json
    prompt = "Answer to rewrite (JSON):\n" + json.dumps({"sentences": result["sentences"]}, ensure_ascii=False)
    try:
        out = llm.chat_json(prompt, SCHEMA, system=REWRITE, step="answer rewrite", model=model, temperature=0.3)
    except llm.LLMError as e:
        log.warning("Rewrite failed (%s); keeping the first answer", e)
        return result
    sentences = [s for s in out.get("sentences", []) if (s.get("text") or "").strip()]
    return {**result, "sentences": sentences} if sentences else result


QUOTED = re.compile(r"[\"'\u2018\u2019\u201c\u201d]([^\"'\u2018\u2019\u201c\u201d]{3,80})[\"'\u2018\u2019\u201c\u201d]")


def named_recordings(question: str) -> list[str]:
    """Recordings the question names in quotes ("Using the video 'Digi Buzzwords explained', ..."):
    the answer then comes only from them. [] = no recording named, search everything."""
    rows = store.available_recordings()
    found: list[str] = []
    for name in QUOTED.findall(question or ""):
        key = " ".join(re.sub(r"[\W_]+", " ", name.lower()).split())
        for r in rows:
            title = " ".join(re.sub(r"[\W_]+", " ", (r.get("title") or "").lower()).split())
            if key and title and (key == title or (min(len(key), len(title)) > 4 and (key in title or title in key))) \
                    and r["video_id"] not in found:
                found.append(r["video_id"])
    return found


def answer(question: str, length: str = "short", level: str = "beginner", mode: str | None = None,
           model: str | None = None, keep: int = retrieval.KEEP, save: bool = True) -> dict:
    """Answer a question from the knowledge base. Returns everything (see answer.json)."""
    t0 = time.perf_counter()
    mark = llm.meter_mark()
    record = {"question": question, "length": length, "level": level, "model": model or config.CHAT_MODEL,
              "created": datetime.now().isoformat(timespec="seconds")}
    problem = safety.request_problem(question)
    if problem:
        record.update(refused=problem, not_in_material=True, sentences=[], mode=mode or config.RETRIEVAL,
                      candidates=[], excerpts={}, checks={}, sources=[], text=f"Not answered: {problem}.")
        return _finish(record, mark, t0, save)
    scope = named_recordings(question)
    if scope:
        log.info("The question names %s recording(s): answering only from them", len(scope))
    found = retrieval.retrieve(question, mode, keep, video_ids=set(scope) or None)
    record["mode"] = found["mode"]
    record["scope"] = scope
    record["candidates"] = [{"id": c["segment"]["id"], "title": c["segment"].get("title", ""), "where": retrieval.where(c["segment"]),
                             "meaning": c["meaning"], "words": c["words"], "score": c["score"], "rerank": c.get("rerank"),
                             "why": c.get("why", "")} for c in found["candidates"]]
    record["kept"] = [c["segment"]["id"] for c in found["kept"]]
    if not found["kept"]:
        record.update(not_in_material=True, sentences=[], not_covered=question, excerpts={}, checks={}, sources=[],
                      text="The training material does not cover this question.")
        return _finish(record, mark, t0, save)
    segments = retrieval.with_neighbours(found["kept"])
    text, labels = material(segments)
    result = write(question, labels, text, level, length, model)
    checks = check(result, labels)
    if result["sentences"] and checks["copy_rate"] > config.COPY_LIMIT:
        log.info("%.0f%% copied word for word (limit %.0f%%): rewriting in own words",
                 checks["copy_rate"] * 100, config.COPY_LIMIT * 100)
        again = rewrite(result, model)
        again_checks = check(again, labels)
        if again_checks["copy_rate"] < checks["copy_rate"]:
            result, checks = again, {**again_checks, "rewritten": True}
    record.update(not_in_material=bool(result.get("not_in_material")) or not result["sentences"],
                  not_covered=result.get("not_covered", ""), sentences=result["sentences"], checks=checks,
                  excerpts={k: {"id": s["id"], "video_id": s["video_id"], "title": s.get("title", ""),
                                "kind": s.get("kind", "recording"), "where": retrieval.where(s),
                                "start": s.get("start", 0), "end": s.get("end", 0),
                                "file": _file(s), "text": s.get("text", "")} for k, s in labels.items()})
    record["sources"], record["text"] = numbered(record)
    return _finish(record, mark, t0, save)


def _file(seg: dict) -> str:
    try:
        meta = store.load_meta(seg["video_id"])
    except (FileNotFoundError, OSError):
        return ""
    return Path(meta.get("video_file") or meta.get("source_file") or meta.get("transcript_file") or "").name


def numbered(record: dict) -> tuple[list[dict], str]:
    """Sources numbered [1], [2] ... in order of first use, and the answer text with those numbers."""
    order: list[str] = []
    for s in record["sentences"]:
        for x in s["sources"]:
            if x not in order:
                order.append(x)
    num = {x: i for i, x in enumerate(order, 1)}
    text = " ".join(s["text"].strip() + "".join(f" [{num[x]}]" for x in s["sources"]) for s in record["sentences"])
    sources = []
    for x in order:
        e = record["excerpts"][x]
        quotes = [s["evidence"] for s in record["sentences"] if x in s["sources"] and s.get("evidence")]
        sources.append({"n": num[x], "label": x, **{k: e[k] for k in ("title", "kind", "where", "file", "video_id")},
                        "evidence": list(dict.fromkeys(quotes))})
    return sources, text


def markdown(record: dict) -> str:
    out = [f"# {record['question']}", ""]
    if record.get("refused"):
        return "\n".join(out + [record["text"], ""])
    if record["not_in_material"]:
        out += ["**The training material does not cover this question.** No answer was written, so nothing is "
                "invented.", ""]
    else:
        out += [record["text"], ""]
        if record.get("not_covered"):
            out += [f"*Not covered by the material:* {record['not_covered']}", ""]
        out += ["## Sources", ""]
        for s in record["sources"]:
            kind = "Document" if s["kind"] == "document" else "Recording"
            file = f" ({s['file']})" if s["file"] and s["file"] != s["title"] else ""
            out.append(f"**[{s['n']}]** {kind} \"{s['title']}\"{file} · {s['where']}")
            out += [f"> \"{q}\"" for q in s["evidence"]] + [""]
        c = record["checks"]
        out += ["## Checks", "", "| Check | Result |", "|---|---|",
                f"| Sentences with a source | {c['sentences'] - c['unsourced_sentences']} of {c['sentences']} |",
                f"| Evidence found word for word in the source | {c['evidence_verified']:.0%} |",
                f"| Numbers not in the sources | {', '.join(c['numbers_not_in_sources']) or 'none'} |",
                f"| Copied word for word | {c['copy_rate']:.0%} (longest run {c['longest_copy_words']} words)"
                + (", rewritten in own words" if c.get("rewritten") else "") + " |",
                f"| Invented source labels | {', '.join(c['invalid_labels']) or 'none'} |", ""]
    out += [f"*Retrieval: {record['mode']} · {len(record.get('kept', []))} excerpts kept of "
            f"{len(record.get('candidates', []))} candidates · model {record['model']} · "
            f"${record['cost_usd']:.4f} · {record['seconds']} s*", ""]
    return "\n".join(out)


def _finish(record: dict, mark: int, t0: float, save: bool) -> dict:
    calls = llm.calls_since(mark)
    record["cost_usd"] = round(sum(c["cost_usd"] for c in calls), 5)
    record["seconds"] = round(time.perf_counter() - t0, 1)
    record["calls"] = calls
    if save:
        folder = config.OUTPUT_DIR / f"{datetime.now():%Y%m%d-%H%M%S}-answer-{store.slugify(record['question'], 40)}"
        folder.mkdir(parents=True, exist_ok=True)
        store.write_json(folder / "answer.json", record)
        (folder / "answer.md").write_text(markdown(record), encoding="utf-8")
        sources = {k: store.all_segments().get(e["id"], e) for k, e in record.get("excerpts", {}).items()}
        runcard.write(folder, kind="answer", title=record["question"], request={"text": record["question"],
                      "length": record["length"], "level": record["level"], "retrieval": record.get("mode", "")},
                      sources=sources, calls=calls, timings={"total_s": record["seconds"]})
        record["folder"] = str(folder)
    return record


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("question")
    ap.add_argument("--length", choices=list(LENGTHS), default="short")
    ap.add_argument("--level", default="beginner", choices=["beginner", "intermediate", "expert"])
    ap.add_argument("--mode", choices=retrieval.MODES, help="how excerpts are found (default: RETRIEVAL in .env)")
    ap.add_argument("--model", help="override CHAT_MODEL")
    args = ap.parse_args()
    config.setup_logging()
    try:
        record = answer(args.question, args.length, args.level, args.mode, args.model)
    except (llm.LLMError, RuntimeError, ValueError) as e:
        log.error("%s", e)
        return 1
    print("\n" + markdown(record))
    if record.get("folder"):
        print(f"Saved: {record['folder']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

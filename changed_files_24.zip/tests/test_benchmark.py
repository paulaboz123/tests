"""Comparing solutions: cloud voices (priced per character), the Remotion engine, and the
benchmark that runs one script through every combination."""
from __future__ import annotations

import argparse
import csv

import numpy as np
import pytest
from conftest import needs_ffmpeg
from test_end_to_end import _prepare_one_recording

import benchmark
import config
import llm
import make_video
import remotion_render
import store
import tts

VOICES = [{"voice_id": "f1", "name": "Anna", "labels": {"gender": "female"}},
          {"voice_id": "m1", "name": "Ben", "labels": {"gender": "male"}}]
LILY, MATILDA, GEORGE = tts.ELEVEN_VOICES["lily"], tts.ELEVEN_VOICES["matilda"], tts.ELEVEN_VOICES["george"]


@pytest.fixture
def cloud_voices(project, monkeypatch):
    """ElevenLabs and Kokoro without network or model files; the Windows voice reported as not set up.
    In the test project, so the made-up voices never reach your real cost_log.csv."""
    spoken = {"elevenlabs": [], "kokoro": []}

    def eleven(text, voice_id, before="", after=""):
        spoken["elevenlabs"].append((voice_id, text))
        return np.zeros(int(len(text.split()) * 0.3 * 24000), dtype=np.float32), 24000, {"chars": None}

    class FakeKokoro:
        def get_voices(self):
            return {"af_heart", "am_michael"}

        def create(self, text, voice, speed, lang):
            spoken["kokoro"].append((voice, text))
            return np.zeros(int(len(text.split()) * 0.3 * 24000), dtype=np.float32), 24000

    real_check = tts.check

    def check(engine=None):
        engine = engine or config.TTS_ENGINE
        if engine == "kokoro":
            return True, "kokoro (test)"
        if engine == "system":
            return False, "pyttsx3 not installed (test)"
        return real_check(engine)
    monkeypatch.setattr(config, "ELEVENLABS_API_KEY", "test-key")
    monkeypatch.setattr(tts, "_elevenlabs", eleven)
    monkeypatch.setattr(tts, "_elevenlabs_voices", lambda: VOICES)
    monkeypatch.setattr(tts, "_get_kokoro", lambda: FakeKokoro())
    monkeypatch.setattr(tts, "check", check)
    return spoken


def test_cloud_voice_is_priced_per_character_and_split(cloud_voices, monkeypatch):
    monkeypatch.setattr(config, "TTS_ENGINE", "elevenlabs")
    assert tts.role_voice("narrator") == LILY and tts.role_voice("host") == MATILDA and tts.role_voice("expert") == GEORGE
    monkeypatch.setattr(config, "ELEVENLABS_HOST_VOICE", "jessica")                 # a name or an id
    monkeypatch.setattr(config, "ELEVENLABS_EXPERT_VOICE", "m1")
    assert tts.role_voice("host") == tts.ELEVEN_VOICES["jessica"] and tts.role_voice("expert") == "m1"
    text = "This sentence has about fifty characters in it. " * 70                 # ~3,500 characters
    mark = llm.meter_mark()
    samples, rate = tts.synthesize(text)
    calls = llm.calls_since(mark)
    assert rate == 24000 and len(cloud_voices["elevenlabs"]) == 2                   # split at a sentence end
    assert calls[0]["step"] == "voice" and calls[0]["backend"] == "elevenlabs"
    chars = len(tts.clean_for_speech(text))
    assert calls[0]["characters"] == chars
    assert calls[0]["cost_usd"] == pytest.approx(chars / 1000 * config.ELEVENLABS_USD_PER_1K_CHARS, rel=1e-3)
    assert "ElevenLabs" in tts.engine_label()


def test_every_combination_is_listed_once():
    vs = benchmark.variants(["kokoro", "elevenlabs"], ["html", "remotion"], ["clean", "presenter"], ["cartoon", "people"])
    assert len(vs) == 2 * 2 * (1 + 2) and len({v["name"] for v in vs}) == len(vs)
    assert {v["characters"] for v in vs if v["style"] == "clean"} == {""}


def args(**kw):
    base = dict(topic="how to join two tables", source=None, recording=None, minutes=1, level="beginner", wishes="",
                model=None, voices=["kokoro", "elevenlabs", "system"], renderers=["pillow"], styles=["clean"],
                characters=["cartoon"])
    return argparse.Namespace(**{**base, **kw})


@needs_ffmpeg
def test_benchmark_one_script_many_voices(gateway, cloud_voices):
    _prepare_one_recording()
    bench = benchmark.run(args(styles=["clean", "dialogue"]))
    s = store.read_json(bench / "benchmark.json", {})
    rows = {r["name"]: r for r in s["variants"]}
    assert rows["system-pillow-clean"]["status"] == "skipped" and "pyttsx3" in rows["system-pillow-clean"]["reason"]
    done = [r for r in s["variants"] if r["status"] == "done"]
    assert {r["name"] for r in done} == {"kokoro-pillow-clean", "elevenlabs-pillow-clean",
                                         "kokoro-pillow-dialogue-cartoon", "elevenlabs-pillow-dialogue-cartoon"}
    assert rows["elevenlabs-pillow-clean"]["voice_cost_usd"] > 0 and rows["kokoro-pillow-clean"]["voice_cost_usd"] == 0
    assert s["script_cost_usd"] > 0                                                  # the script: paid once, shared
    a = store.read_json(bench / rows["kokoro-pillow-clean"]["folder"] / "storyboard.json", {})
    b = store.read_json(bench / rows["elevenlabs-pillow-clean"]["folder"] / "storyboard.json", {})
    assert [x["narration"] for x in a["scenes"]] == [x["narration"] for x in b["scenes"]]   # same script
    d1 = store.read_json(bench / rows["kokoro-pillow-dialogue-cartoon"]["folder"] / "storyboard.json", {})
    d2 = store.read_json(bench / rows["elevenlabs-pillow-dialogue-cartoon"]["folder"] / "storyboard.json", {})
    assert d1["scenes"][1]["lines"] == d2["scenes"][1]["lines"]                    # conversation written once
    assert {v for v, _ in cloud_voices["elevenlabs"]} == {LILY, MATILDA, GEORGE}   # narrator, host and expert
    card = store.read_json(bench / rows["elevenlabs-pillow-clean"]["folder"] / "run_card.json", {})
    assert "ElevenLabs" in card["solution"]["voice"] and card["benchmark"]["variant"] == "elevenlabs-pillow-clean"
    page = (bench / "comparison.html").read_text(encoding="utf-8")
    assert page.count("<video") == 4 and "pyttsx3 not installed" in page
    assert "Video · Slides" in page and "Video · Animation: a conversation" in page and page.count("<audio") == 2
    assert "Cost per version" in page and "AI video (ElevenLabs)" in page
    with open(bench / "benchmark.csv", encoding="utf-8-sig") as f:
        header = next(csv.reader(f))
    assert "rating_voice_1to5" in header and "voice_cost_usd" in header


@needs_ffmpeg
def test_same_voice_is_made_once_for_two_video_engines(gateway, cloud_voices, monkeypatch):
    from test_slides_html import _browser_or_skip
    _browser_or_skip().close()
    _prepare_one_recording()
    bench = benchmark.run(args(voices=["elevenlabs"], renderers=["pillow", "html"]))
    rows = store.read_json(bench / "benchmark.json", {})["variants"]
    assert [r["status"] for r in rows] == ["done", "done"]
    assert rows[1]["voice_reused"] == "yes" and rows[1]["voice_cost_usd"] == rows[0]["voice_cost_usd"] > 0
    first_run = len(cloud_voices["elevenlabs"])
    assert first_run == len({t for _, t in cloud_voices["elevenlabs"]})            # every text spoken once only
    assert rows[1]["renderer_used"] == "html"


def test_remotion_gets_the_same_scenes_and_timing():
    sb = {"title": "T", "style": "clean", "scenes": [
        {"visual": "title", "heading": "Roles", "items": ["Know the roles"], "narration": "Hi."},
        {"visual": "cards", "heading": "Three roles", "narration": "x", "animation": "build",
         "elements": [{"title": "PO", "icon": "crown"}, {"title": "SM"}, {"title": "Devs"}]},
        {"visual": "chart", "heading": "Velocity", "narration": "y",
         "chart": {"labels": ["S1", "S2"], "values": ["18", 22], "unit": "pts", "highlight": 2}}]}
    plan = [(0, {"styles": None}), (1, {"styles": None}), (1, {"styles": []}), (1, {"styles": []}), (1, {"styles": []}),
            (2, {"styles": None})]
    p = remotion_render.props(sb, plan, [2.0, 1.0, 2.0, 2.0, 2.0, 3.0], "narration.wav")
    assert [x["start_s"] for x in p["scenes"]] == [0.0, 2.0, 9.0] and p["total_s"] == 12.0
    cards = p["scenes"][1]
    assert len(cards["units"]) == 3 and len(cards["appear"]) == 3 and "<svg" in cards["units"][0]["icon"]
    assert cards["appear"] == sorted(cards["appear"]) and cards["appear"][0] > 1.0           # with the voice
    assert p["scenes"][2]["chart"]["values"] == [18.0, 22.0] and p["audio"] == "narration.wav"
    ok, why = remotion_render.available()
    assert isinstance(ok, bool) and why


@needs_ffmpeg
def test_video_is_still_made_when_remotion_fails(gateway, fake_voice, monkeypatch):
    _prepare_one_recording()
    monkeypatch.setattr(config, "RENDERER", "remotion")
    monkeypatch.setattr(remotion_render, "available", lambda: (True, "test"))

    def broken(*a, **k):
        raise RuntimeError("Remotion render failed: test")
    monkeypatch.setattr(remotion_render, "render", broken)
    out_dir, info = make_video.make("how to join two tables", minutes=1)
    assert (out_dir / "lesson_video.mp4").exists() and info["renderer"] in ("html", "pillow")


def test_remotion_draws_the_same_cartoon_characters():
    beats = [(0, {"styles": None, "speaker": "host", "pause": 0.3, "mouth": [0.8] * 25}),
             (0, {"styles": None, "speaker": "expert", "pause": 0.3, "mouth": [0.5] * 50})]
    sc = {"visual": "cards", "heading": "Roles", "narration": "x", "elements": [{"title": "PO"}, {"title": "SM"}],
          "lines": [{"speaker": "host", "text": "a"}, {"speaker": "expert", "text": "b"}]}
    p = remotion_render.props({"title": "T", "style": "dialogue", "characters": "cartoon", "scenes": [sc]},
                              beats, [1.0, 2.0], "narration.wav")
    st = p["stage"]
    assert st["style"] == "dialogue" and st["tags"] and "function toon" in st["toon_js"]
    assert 'data-who="expert"' in st["front"] and 'data-who="host"' in st["front"]
    assert p["scenes"][0]["mouth"]["host"][10] == 0.8 and [w[2] for w in p["scenes"][0]["talk"]] == ["host", "expert"]
    p = remotion_render.props({"title": "T", "style": "presenter", "characters": "cartoon", "scenes": [sc]},
                              beats, [1.0, 2.0], "narration.wav")
    assert 'data-who="presenter"' in p["stage"]["front"] and tuple(p["stage"]["screen"]) == (46, 56, 908, 528)
    assert remotion_render.props({"title": "T", "style": "clean", "scenes": [sc]}, beats, [1.0, 2.0], "a.wav")["stage"] is None
    with pytest.raises(RuntimeError, match="cartoon"):
        remotion_render.props({"title": "T", "style": "dialogue", "characters": "people", "scenes": [sc]},
                              beats, [1.0, 2.0], "a.wav")
    assert "cartoon" in benchmark.can_run("kokoro", "remotion", "dialogue", "people")


def test_by_default_every_tool_as_slides_and_animation_with_two_narrators(monkeypatch):
    import sys
    seen = {}

    def fake_run(a):
        seen["args"] = a
        raise ValueError("stop")
    monkeypatch.setattr(benchmark, "run", fake_run)
    monkeypatch.setattr(sys, "argv", ["benchmark.py", "joins"])
    benchmark.main()
    a = seen["args"]
    assert a.styles == ["clean", "presenter"]                                      # slides and animation
    assert a.renderers == ["html", "remotion-pro"] and a.voices == ["kokoro", "elevenlabs"]
    assert a.characters == [] and not a.audio_only and a.vary == []                 # no talking bear by default
    vs = benchmark.variants(a.voices, a.renderers, a.styles, a.characters, a.presenters)
    assert len(vs) == 6 and not any(v["renderer"] == "html" and v["style"] == "presenter" for v in vs)
    for bad in (["--voices", "kokoro@flash"], ["--presenters", "dragon"], ["--presenters", "person-2d:pixar"]):
        monkeypatch.setattr(sys, "argv", ["benchmark.py", "joins", *bad])
        with pytest.raises(SystemExit):
            benchmark.main()
    monkeypatch.setattr(sys, "argv", ["benchmark.py", "joins", "--voices", "kokoro:bf_emma,elevenlabs:lily@flash",
                                      "--presenters", "cat,person-2d:notionists"])
    assert benchmark.main() == 1                                                   # stopped by the fake run
    assert seen["args"].voices == ["kokoro:bf_emma", "elevenlabs:lily@flash"]
    assert seen["args"].presenters == ["cat", "person-2d:notionists"]


def test_elevenlabs_parts_join_into_one_narration(project, monkeypatch):
    """Each part goes with what comes before and after it: the request ids of the parts just spoken
    (or their text), the next text, steady settings and a fixed seed; the silence at the ends is cut;
    the cost is what ElevenLabs says it billed."""
    sent, urls = [], []

    class Reply:
        def __init__(self, n):
            self.status_code, self.text = 200, ""
            quiet, loud = np.zeros(4800, dtype=np.int16), (np.ones(2400) * 8000).astype(np.int16)
            self.content = np.concatenate([quiet, loud, quiet]).tobytes()          # 0.2 s silence each side
            self.headers = {"request-id": f"req{n}", "character-cost": "21"}

    class Http:
        def post(self, url, params=None, json=None, headers=None, timeout=None):
            sent.append(json)
            urls.append(url)
            return Reply(len(sent))
    monkeypatch.setattr(llm, "_http", lambda: Http())
    monkeypatch.setattr(config, "ELEVENLABS_API_KEY", "test-key")
    monkeypatch.setattr(config, "TTS_ENGINE", "elevenlabs")
    monkeypatch.setattr(config, "ELEVENLABS_FORMAT", "pcm_24000")
    tts._stitch.clear()
    mark = llm.meter_mark()
    a, rate = tts.synthesize("There are three roles.", context={"before": "", "after": "The Product Owner orders."})
    b, _ = tts.synthesize("The Product Owner orders.", context={"before": "There are three roles.", "after": ""})
    c, _ = tts.synthesize("Something else.", context={"before": "A part made earlier.", "after": ""})
    assert sent[0]["next_text"] == "The Product Owner orders." and "previous_text" not in sent[0]
    assert sent[1]["previous_request_ids"] == ["req1"] and "previous_text" not in sent[1]   # continues the part before
    assert sent[2]["previous_text"] == "A part made earlier."                       # not just spoken: its text
    v = sent[0]["voice_settings"]
    assert v["stability"] == 0.6 and v["use_speaker_boost"] and sent[0]["seed"] == 4242
    assert sent[0]["model_id"] == "eleven_multilingual_v2" and urls[0].endswith(LILY)   # the default narrator
    assert len(a) / rate < 0.25                                                       # 0.1 s of voice, ends trimmed
    assert [x["characters"] for x in llm.calls_since(mark)] == [21, 21, 21]         # what ElevenLabs billed
    monkeypatch.setattr(config, "ELEVENLABS_CONTEXT", False)                        # the old way, to compare
    d, _ = tts.synthesize("Plain part.", context={"before": "x", "after": "y"})
    assert not {"previous_text", "next_text", "previous_request_ids"} & set(sent[3]) and len(d) / rate > 0.45
    monkeypatch.setattr(config, "ELEVENLABS_CONTEXT", True)
    monkeypatch.setattr(config, "ELEVENLABS_MODEL", "v3")                           # v3: no stitching
    tts.synthesize("Expressive part.", context={"before": "x", "after": "y"})
    assert sent[4]["model_id"] == "eleven_v3" and "next_text" not in sent[4]


def test_neighbours_are_the_same_voice():
    plan = [(0, {"text": "a", "voice": None}), (0, {"text": "q", "voice": "h"}), (0, {"text": "b", "voice": None}),
            (1, {"text": "r", "voice": "h"}), (1, {"text": "c", "voice": None})]
    assert make_video.neighbours(plan, 2) == {"before": "a", "after": "c"}
    assert make_video.neighbours(plan, 1) == {"before": "", "after": "r"}


def test_narrator_specs_and_presenters():
    assert benchmark.parse_voice("elevenlabs:lily@flash+plain") == {"engine": "elevenlabs", "voice": "lily", "model": "flash",
                                                                    "plain": True}
    assert benchmark.voice_config("kokoro:bf_emma") == {"TTS_ENGINE": "kokoro", "TTS_VOICE": "bf_emma"}
    c = benchmark.voice_config("elevenlabs:george@flash")
    assert c["ELEVENLABS_VOICE"] == "george" and c["ELEVENLABS_MODEL"] == "eleven_flash_v2_5" and "ELEVENLABS_CONTEXT" not in c
    assert benchmark.voice_config("elevenlabs+plain")["ELEVENLABS_CONTEXT"] is False
    assert benchmark.voice_label("elevenlabs:george@flash") == "ElevenLabs · George · flash_v2_5"
    assert "old way" in benchmark.voice_label("elevenlabs:lily+plain") and "bf_emma" in benchmark.voice_label("kokoro:bf_emma")
    with pytest.raises(ValueError):
        benchmark.parse_voice("kokoro@flash")
    with pytest.raises(ValueError):
        benchmark.parse_voice("polly")
    vs = benchmark.variants(["kokoro", "elevenlabs:lily@flash"], ["html", "remotion-pro"], ["clean", "presenter"], ["cartoon"],
                            ["robot", "person-2d:micah"])
    names = [v["name"] for v in vs]
    assert len(vs) == 2 * (2 + 1 + 2) and len(set(names)) == len(vs)
    assert "elevenlabs_lily_flash-remotion-pro-presenter-person-2d_micah" in names    # no : @ in folder names
    assert {v["presenter"] for v in vs if v["renderer"] == "html"} == {""}
    assert benchmark.presenter_config("person-2d:micah") == {"PRO_PRESENTER": "person-2d", "PRO_AVATAR": "micah"}


def test_report_rows_per_presenter(tmp_path):
    rows = [{"name": f"{v}-{pr}", "voice": v, "renderer": "remotion-pro", "style": "presenter", "characters": "", "presenter": pr,
             "status": "done", "reason": "", "folder": "x", "video": "x/v.mp4", "video_s": 50, "voice_cost_usd": 0.1,
             "voice_reused": "", "make_s": 100, "verdict": "OK", "problems": ""}
            for v in ("kokoro", "elevenlabs:lily@flash") for pr in ("robot", "person-2d:micah")]
    benchmark.report(tmp_path, {"request": "t", "script_cost_usd": 0.01, "script_model": "m", "characters_spoken": 800,
                                "total_s": 1, "variants": rows, "folder": str(tmp_path)})
    page = (tmp_path / "comparison.html").read_text(encoding="utf-8")
    assert page.count("<video") == 4 and "Remotion Pro · robot" in page and "Remotion Pro · person-2d:micah" in page
    assert "ElevenLabs · Lily · flash_v2_5" in page


def test_any_setting_in_several_versions():
    vary = benchmark.parse_vary(["THEME_ACCENT=#0b6e79,#7c3aed", "gsap=yes,no"])
    assert vary == [("THEME_ACCENT", ["#0b6e79", "#7c3aed"]), ("GSAP", ["yes", "no"])]
    vs = benchmark.variants(["kokoro"], ["html"], ["clean"], [], None, vary)
    assert len(vs) == 4 and len({v["name"] for v in vs}) == 4 and ":" not in "".join(v["name"] for v in vs)
    c = benchmark.vary_config([("GSAP", "no"), ("VIDEO_WIDTH", "1280"), ("ELEVENLABS_STABILITY", "0.4"), ("RENDERER", "HTML")])
    assert c == {"GSAP": False, "VIDEO_WIDTH": 1280, "VIDEO_HEIGHT": 720, "ELEVENLABS_STABILITY": 0.4, "RENDERER": "html"}
    for bad in (["ELEVENLABS_API_KEY=x"], ["NOT_A_SETTING=1"], ["GSAP="]):
        with pytest.raises(ValueError):
            benchmark.parse_vary(bad)
    audio = benchmark.variants(["kokoro", "elevenlabs:lily"], ["html", "remotion-pro"], ["clean", "presenter"], [], ["cat"],
                               None, audio_only=True)
    assert [v["name"] for v in audio] == ["kokoro-audio", "elevenlabs_lily-audio"]


@needs_ffmpeg
def test_audio_only_compares_narrators_fast(gateway, cloud_voices):
    _prepare_one_recording()
    bench = benchmark.run(args(voices=["kokoro", "elevenlabs:lily", "elevenlabs:lily+plain"], audio_only=True,
                               vary=[("TTS_SPEED", ["1.0", "1.1"])]))
    rows = store.read_json(bench / "benchmark.json", {})["variants"]
    assert len(rows) == 6 and {r["status"] for r in rows} == {"done"} and all(r["video"] == "" for r in rows)
    assert all((bench / r["folder"] / "lesson_audio.mp3").exists() for r in rows)
    assert not list(bench.glob("*/lesson_video.mp4"))                               # nothing drawn
    page = (bench / "comparison.html").read_text(encoding="utf-8")
    assert page.count("<audio") == 6 and "<video" not in page and "TTS_SPEED=1.1" in page and "old way" in page


@needs_ffmpeg
def test_a_tool_that_falls_back_is_marked(gateway, cloud_voices, monkeypatch):
    _prepare_one_recording()
    monkeypatch.setattr(remotion_render, "ensure_installed", lambda: None)
    monkeypatch.setattr(remotion_render, "available", lambda: (True, "test"))

    def broken(*a, **k):
        raise RuntimeError("Remotion render failed: No entry point specified")
    monkeypatch.setattr(remotion_render, "render", broken)
    bench = benchmark.run(args(voices=["kokoro"], renderers=["remotion-pro"], styles=["clean"]))
    row = store.read_json(bench / "benchmark.json", {})["variants"][0]
    assert row["status"] == "fallback" and "No entry point" in row["reason"] and row["renderer_used"] in ("html", "pillow")
    page = (bench / "comparison.html").read_text(encoding="utf-8")
    assert "Not this tool" in page and page.count("<audio") == 1


@needs_ffmpeg
def test_elevenlabs_audio_in_full_quality(project, monkeypatch, tmp_path):
    """mp3 at 44.1 kHz by default (as in ElevenLabs' web app; every plan has it), kept at 44.1 kHz."""
    import subprocess
    mp3 = tmp_path / "a.mp3"
    subprocess.run([config.FFMPEG, "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=f=440:d=1", "-ar", "44100",
                    "-c:a", "libmp3lame", "-b:a", "128k", str(mp3)], check=True)
    asked = []

    class Reply:
        status_code, text, headers = 200, "", {}
        content = mp3.read_bytes()

    class Http:
        def post(self, url, params=None, json=None, headers=None, timeout=None):
            asked.append(params["output_format"])
            return Reply()
    monkeypatch.setattr(llm, "_http", lambda: Http())
    monkeypatch.setattr(config, "ELEVENLABS_API_KEY", "test-key")
    monkeypatch.setattr(config, "TTS_ENGINE", "elevenlabs")
    samples, rate = tts.synthesize("A short sentence.")
    assert asked == ["mp3_44100_128"] and rate == 44100 and 0.9 < len(samples) / rate < 1.2
    assert benchmark.voice_config("elevenlabs+plain")["ELEVENLABS_FORMAT"] == "pcm_24000"   # the old way, as it was


def test_narration_gets_one_steady_loudness():
    rate = 24000
    t = np.arange(rate * 2) / rate
    quiet = (0.02 * np.sin(2 * np.pi * 200 * t)).astype(np.float32)
    out = tts.normalize(quiet, rate)
    rms = float(np.sqrt(np.mean(out ** 2)))
    assert abs(20 * np.log10(rms) - (-19)) < 0.5 and np.max(np.abs(out)) <= 0.89 + 1e-6
    ratio = out[rate // 2:rate // 2 + 100] / quiet[rate // 2:rate // 2 + 100]
    assert np.allclose(ratio[np.abs(quiet[rate // 2:rate // 2 + 100]) > 1e-3], ratio[0], rtol=1e-3)   # one gain
    loud = np.concatenate([quiet, np.ones(100, dtype=np.float32) * 0.9])          # a peak: gain kept below it
    assert np.max(np.abs(tts.normalize(loud, rate))) <= 0.89 + 1e-6
    assert np.array_equal(tts.normalize(np.zeros(1000, dtype=np.float32), rate), np.zeros(1000, dtype=np.float32))


def test_render_speed_settings(monkeypatch):
    import os
    monkeypatch.setattr(config, "REMOTION_CONCURRENCY", 64)
    assert remotion_render.concurrency() == (os.cpu_count() or 2)                   # never more than the cores
    monkeypatch.setattr(config, "REMOTION_CONCURRENCY", 0)
    assert remotion_render.concurrency() == max(1, (os.cpu_count() or 2) // 2)
    monkeypatch.setattr(config, "REMOTION_FPS", 25)
    assert remotion_render.fps() == 25
    monkeypatch.setattr(config, "REMOTION_FPS", 5)
    assert remotion_render.fps() == 24

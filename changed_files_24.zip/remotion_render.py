"""
remotion_render.py - the video drawn by Remotion (React video framework) instead of the built-in
engine: the same storyboard, the same voice and the same timing (each element appears when the
voice gets to it), so the two can be compared fairly (benchmark.py).

One-time setup (needs Node.js 18+):
  cd remotion
  npm install
Remotion uses the Chromium installed for Playwright (uv run playwright install chromium) when it
finds it; otherwise it downloads its own browser on the first render.

Licence: Remotion is free for individuals and for evaluation; a company of more than 3 people
needs a company licence for real use (remotion.pro/license). The run card notes this.
Use: RENDERER=remotion in .env, or benchmark.py --renderers remotion.

RENDERER=remotion-pro: the same lesson as a motion-design video (src/pro): a living dark backdrop,
glass cards that flip in with the voice, counters and charts that grow, push transitions, and
presenters that talk in time with the voice, wave, point at the screen and are happy about the right
answer: none in slides (clean, illustrated), one in the presenter style, two in a conversation.
PRO_PRESENTER chooses who (assets/README.md has the sources and licences):
  robot      3D, RobotExpressive (Quaternius, CC0), a glossy toy look (default)
  cat        3D, Toon Cat FREE (Omabuarts Studio, CC BY 4.0: credit needed)
  person-3d  3D, a woman and a man in suits (Quaternius, CC0)
  person-2d  2D, an illustrated person in a round portrait (DiceBear; PRO_AVATAR=micah | avataaars |
             notionists); about 3-4x faster to render than 3D
  none       the scenes only
3D is drawn by the browser: with a
way the browser chooses (fast; REMOTION_GL to force angle, egl, swiftshader ...); if that fails
it is retried with swangle (always works, several times slower).
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
from pathlib import Path

import cartoon
import config
import slides_html
import tts

log = logging.getLogger("remotion")
PROJECT = config.ROOT / "remotion"
ASSETS = PROJECT / "assets"
ROBOT = ASSETS / "robot.glb"
PRESENTERS = ("robot", "cat", "person-3d", "person-2d")
AVATARS = ("micah", "avataaars", "notionists")
MODELS = {"robot": ["robot.glb"], "cat": ["cat.glb"], "person-3d": ["woman-suit.glb", "man-suit.glb"], "person-2d": []}
SECOND_COLOUR = "#7c5cff"   # the second presenter in conversations
FPS = 30   # default; REMOTION_FPS in .env (fps())
LICENCE_NOTE = "Remotion: free for evaluation; company licence needed for production (from $0.01/render, $100/month min)"


ENTRY = PROJECT / "src" / "index.ts"
CLI_JS = PROJECT / "node_modules" / "@remotion" / "cli" / "remotion-cli.js"


def npx() -> str | None:
    return shutil.which("npx.cmd") or shutil.which("npx")


def node() -> str | None:
    """node.exe: on PATH, or next to npx (portable Node.js)."""
    found = shutil.which("node.exe") or shutil.which("node")
    if found:
        return found
    if npx():
        for name in ("node.exe", "node"):
            if (Path(npx()).parent / name).exists():
                return str(Path(npx()).parent / name)
    return None


def cli() -> list[str]:
    """How to start the Remotion command line: node with Remotion's own script (no npx.cmd, whose
    Windows batch file can lose arguments), else npx."""
    if node() and CLI_JS.exists():
        return [node(), str(CLI_JS)]
    return [npx() or "npx", "remotion"]


def missing_packages() -> list[str]:
    deps = json.loads((PROJECT / "package.json").read_text(encoding="utf-8"))["dependencies"]
    return [d for d in deps if not (PROJECT / "node_modules" / d / "package.json").exists()]


def ensure_installed() -> None:
    """Install the Remotion packages (npm install, once; ~1-2 min) when some are missing, e.g. in a
    fresh copy of the project or after an update that adds packages. Quiet when all are there."""
    if not (PROJECT / "package.json").exists() or not missing_packages():
        return
    npm = shutil.which("npm.cmd") or shutil.which("npm")
    if not npm:
        return
    log.info("Remotion: installing its packages once (npm install, 1-2 minutes) ...")
    r = subprocess.run([npm, "install", "--no-audit", "--no-fund"], cwd=PROJECT, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=900)
    if r.returncode != 0:
        log.warning("npm install failed: %s", (r.stderr or r.stdout)[-500:])


def available() -> tuple[bool, str]:
    """Can Remotion render here? (Node.js, the project files and its installed packages)"""
    if not npx() and not node():
        return False, "Node.js not found (install Node.js 18+, then: cd remotion && npm install)"
    if not ENTRY.exists():
        return False, (f"{ENTRY} is missing: the remotion folder is incomplete (the update packages hold only "
                       f"changed files); unpack the full project or remotion_full.zip first")
    if not (PROJECT / "node_modules" / "@remotion" / "cli").exists():
        return False, "Remotion not installed: cd remotion && npm install"
    missing = missing_packages()
    if missing:   # e.g. new packages in an update
        return False, f"Remotion packages missing ({', '.join(missing)}): cd remotion && npm install"
    deps = json.loads((PROJECT / "package.json").read_text(encoding="utf-8"))["dependencies"]
    return True, "Remotion " + deps["remotion"]


SHELL_NAMES = {"headless_shell", "headless_shell.exe", "chrome-headless-shell", "chrome-headless-shell.exe"}


def browser() -> str | None:
    """The headless Chromium that Playwright installs next to its browser (uv run playwright
    install chromium), so Remotion needs no download of its own. Remotion needs this "headless
    shell" build; the normal Chromium no longer has the old headless mode."""
    if os.getenv("REMOTION_BROWSER"):
        return os.getenv("REMOTION_BROWSER")
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            path = Path(p.chromium.executable_path)
    except Exception:   # noqa: BLE001 - no Playwright: Remotion fetches its own browser
        return None
    root = next((a.parent for a in path.parents if a.name.startswith("chromium")), None)
    if root is None:
        return None
    found = sorted(f for d in root.glob("chromium_headless_shell-*") for f in d.rglob("*")
                   if f.name in SHELL_NAMES and f.is_file())
    return str(found[-1]) if found else None


def units(scene: dict) -> list[dict]:
    """The parts of a scene that appear one by one, as plain data for the React side."""
    kind = scene.get("visual", "")
    if kind == "comparison":
        return [{"title": c.get("heading", ""), "items": c.get("items", [])} for c in scene.get("columns", [])]
    if kind == "table":
        head = scene.get("table_header", [])
        return [{"title": r[0] if r else "", "detail": " · ".join(f"{h}: {c}" for h, c in zip(head[1:], r[1:], strict=False))}
                for r in scene.get("table_rows", [])]
    if kind in ("question", "answer"):
        return [{"title": x} for x in scene.get("items", [])]
    out = []
    for e in slides_html.elements(scene):
        out.append({"title": e["title"], "detail": e["detail"], "value": e["value"],
                    "icon": (slides_html.svg_icon(e["icon"]).replace('width="24"', 'width="100%"')
                             .replace('height="24"', 'height="100%"') if e.get("icon") else "")})
    return out


# Where the screen sits in the presenter and dialogue rooms (1280x720 units, as in slides_html)
SCREENS = {"presenter": (46, 56, 908, 528), "dialogue": (250, 62, 780, 448)}


def stage(sb: dict) -> dict | None:
    """The room with the cartoon characters for the presenter and dialogue styles: the same
    drawings as the built-in engine; their mouths, eyes and arms are moved by the same code
    (cartoon.RUNTIME), so both engines show the same characters."""
    style = sb.get("style")
    if style not in SCREENS:
        return None
    if (sb.get("characters") or config.CHARACTERS) != "cartoon":
        raise RuntimeError("Remotion draws only the cartoon characters (CHARACTERS=cartoon)")
    import illustrations as il
    p = il.palette()
    if style == "presenter":
        bear = cartoon.character("bear", 1105, 702, 470, cls="toon-presenter", jacket=p["a"], jacket2=p["deep"],
                                 facing="left").replace('class="toon toon-presenter"', 'class="toon" data-who="presenter"')
        front = il.plant(1240, 700, 1.0, p) + bear
        back = slides_html.toon_room(p, shelf=False)
    else:
        bear = cartoon.character("bear", 128, 702, 440, cls="duo-expert", jacket=p["a"], jacket2=p["deep"])
        fox = cartoon.character("fox", 1152, 702, 420, cls="duo-host", jacket=p["violet"], jacket2="#4c3f8f", facing="left")
        front = (bear.replace('class="toon duo-expert"', 'class="toon" data-who="expert"')
                 + fox.replace('class="toon duo-host"', 'class="toon" data-who="host"'))
        back = slides_html.toon_room(p)
    back = back.replace('<svg class="room back" viewBox="0 0 1280 720">', "").removesuffix("</svg>")
    return {"style": style, "back": back, "front": front, "screen": SCREENS[style], "tags": style == "dialogue",
            "toon_js": cartoon.RUNTIME}


def props(sb: dict, plan: list[tuple[int, dict]], durations: list[float], audio: str, with_stage: bool = True) -> dict:
    """Everything the Remotion composition needs: scenes with start, length and timing."""
    room = stage(sb) if with_stage else None
    scenes, t = [], 0.0
    for i, sc in enumerate(sb["scenes"]):
        idx = [k for k, (j, _) in enumerate(plan) if j == i]
        beats, durs = [plan[k][1] for k in idx], [durations[k] for k in idx]
        us = units(sc)
        n = max(1, len(us))
        tl = (slides_html.dialogue_timeline(beats, durs, n, [u.get("title", "") for u in us]) if sb.get("style") == "dialogue"
              else slides_html.timeline(sc, beats, durs, n))
        if room:   # who talks when, and how open each mouth is (from the real voice)
            tl.update(slides_html.speech_track(beats, durs))
        item = {"kind": sc.get("visual", ""), "start_s": round(t, 3), "duration_s": round(sum(durs), 3),
                "talk": tl.get("talk", []), "mouth": tl.get("mouth", {}),
                "heading": sc.get("heading", ""), "subheading": sc.get("subheading", ""), "label": sc.get("label", ""),
                "units": us, "appear": tl["appear"], "active": tl["active"], "correct": sc.get("correct")}
        ch = sc.get("chart")
        if ch and ch.get("values"):
            item["chart"] = {k: ch.get(k) for k in ("labels", "values", "unit", "highlight", "takeaway")}
            item["chart"]["values"] = [float(v) for v in ch["values"]]
        scenes.append(item)
        t += sum(durs)
    return {"fps": fps(), "width": config.VIDEO_WIDTH, "height": config.VIDEO_HEIGHT, "total_s": round(t, 3),
            "audio": audio, "title": sb["title"], "accent": config.THEME_ACCENT, "accent2": config.THEME_ACCENT_2,
            "scenes": scenes, "stage": room}


def presenter() -> tuple[str, str]:
    """Who presents (PRO_PRESENTER) and, for person-2d, the look (PRO_AVATAR); "none" = nobody.
    Unknown values fall back to the defaults with a warning."""
    who = config.PRO_PRESENTER.replace("_", "-")
    if who in ("none", "no", "off", ""):
        return "none", ""
    if who not in PRESENTERS:
        log.warning("PRO_PRESENTER=%s is not one of %s: using robot", config.PRO_PRESENTER, ", ".join(PRESENTERS))
        who = "robot"
    look = config.PRO_AVATAR if config.PRO_AVATAR in AVATARS else "micah"
    if who == "person-2d" and look != config.PRO_AVATAR:
        log.warning("PRO_AVATAR=%s is not one of %s: using micah", config.PRO_AVATAR, ", ".join(AVATARS))
    return who, (look if who == "person-2d" else "")


def cast(sb: dict) -> list[dict]:
    """The presenters of a Pro video: none for slides (clean, illustrated), one for the presenter
    style, two for a conversation; PRO_PRESENTER=none = never."""
    if presenter()[0] == "none" or sb.get("style") not in ("presenter", "dialogue"):
        return []
    if sb.get("style") == "dialogue":
        return [{"who": "expert", "color": config.THEME_ACCENT, "side": "left"},
                {"who": "host", "color": SECOND_COLOUR, "side": "right"}]
    return [{"who": "presenter", "color": config.THEME_ACCENT, "side": "right"}]


def pro_props(sb: dict, plan: list[tuple[int, dict]], durations: list[float], wav: Path) -> dict:
    """The Pro composition's data: the scenes, who talks when, and how open the mouth is per frame."""
    data = props(sb, plan, durations, wav.name, with_stage=False)
    samples, rate = tts._read_wav(wav)
    starts = [sum(durations[:k]) for k in range(len(durations))]
    talk = [[round(s + 0.1, 3), round(s + d - min(0.3, (b.get("pause") or 0.3)), 3), b.get("speaker") or "presenter"]
            for (_, b), s, d in zip(plan, starts, durations, strict=True)]
    who, look = presenter()
    data.update({"mouth": cartoon.mouth_envelope(samples, rate, fps()), "talk": talk, "cast": cast(sb),
                 "character": who if who != "none" else "robot", "avatar": look or "micah", "stage": None,
                 "sharp": 1.5 if config.VIDEO_WIDTH >= 1920 else 1.0})   # 3D pixel density: sharper at full HD
    return data


def concurrency() -> int:
    """Frames drawn at once: REMOTION_CONCURRENCY (at most the number of cores, which Remotion
    requires), or half the processor cores."""
    cores = os.cpu_count() or 2
    return min(cores, config.REMOTION_CONCURRENCY) if config.REMOTION_CONCURRENCY > 0 else max(1, cores // 2)


def fps() -> int:
    """Frames per second: REMOTION_FPS (24-60), default 30."""
    return min(60, max(24, int(getattr(config, "REMOTION_FPS", FPS) or FPS)))


def gl_modes() -> list[str]:
    """How the browser draws 3D, in the order to try: REMOTION_GL if set, else the browser's own
    choice ("" = no flag; fast, and on Windows it uses the graphics chip), then swangle: always works,
    but every frame of the page is then drawn in software (several times slower)."""
    first = config.REMOTION_GL if config.REMOTION_GL not in ("", "default", "auto") else ""
    return [first] + (["swangle"] if first != "swangle" else [])


def render(out_dir: Path, sb: dict, plan: list[tuple[int, dict]], durations: list[float], wav: Path,
           ai: bool = False, pro: bool = False) -> Path:
    """Render lesson_video.mp4 with Remotion (audio included). Raises RuntimeError on failure.
    ai: Claude writes each scene's React code first (react_scenes.py, engine "remotion-ai").
    pro: the Pro composition (engine "remotion-pro")."""
    ensure_installed()
    ok, why = available()
    if not ok:
        raise RuntimeError(why)
    if pro:
        return _render_pro(out_dir, sb, plan, durations, wav)
    data = props(sb, plan, durations, wav.name)
    if ai:
        import react_scenes
        try:
            react_scenes.prepare(data, out_dir)
            return _render(out_dir, data, wav)
        except RuntimeError as e:   # e.g. a broken bundle: the templates still make the video
            log.warning("Remotion with Claude's scenes failed (%s); rendering the templates", str(e)[:200])
        finally:
            react_scenes.clear()
    return _render(out_dir, data, wav)


def _render_pro(out_dir: Path, sb: dict, plan: list[tuple[int, dict]], durations: list[float], wav: Path) -> Path:
    data = pro_props(sb, plan, durations, wav)
    copies = []
    for name in (MODELS.get(data["character"], []) if data["cast"] else []):   # the 3D model(s), next to the voice
        if not (ASSETS / name).exists():
            raise RuntimeError(f"{ASSETS / name} is missing (3D presenter {data['character']}); "
                               f"copy it from the package or choose another PRO_PRESENTER")
        shutil.copyfile(ASSETS / name, wav.parent / name)
        copies.append(wav.parent / name)
    try:
        last = None
        for gl in gl_modes():
            data["aa"] = gl != "swangle"   # smooth 3D edges cost a lot when drawn in software
            try:
                return _render(out_dir, data, wav, composition="Pro",
                               extra=([f"--gl={gl}"] if gl else []) + ["--timeout=180000"])
            except RuntimeError as e:
                last = e
                log.warning("Remotion Pro with --gl=%s failed (%s)", gl or "default", str(e)[-300:])
        raise last or RuntimeError("Remotion Pro render failed")
    finally:
        for f in copies:
            f.unlink(missing_ok=True)


def _render(out_dir: Path, data: dict, wav: Path, composition: str = "Lesson", extra: list[str] | None = None) -> Path:
    props_file = out_dir / "remotion_props.json"
    props_file.write_text(json.dumps(data), encoding="utf-8")
    out = out_dir / "lesson_video.mp4"
    cmd = [*cli(), "render", str(ENTRY), composition, str(out.resolve()), f"--props={props_file.resolve()}",
           f"--public-dir={wav.parent.resolve()}", "--log=error", f"--concurrency={concurrency()}", *(extra or [])]
    chrome = browser()
    if chrome:
        cmd.append(f"--browser-executable={chrome}")
    log.info("Remotion: rendering %s scenes, %.0f s ...", len(data["scenes"]), data["total_s"])
    # utf-8: Node writes UTF-8; Windows' own code page can't read some of its characters and would crash
    r = subprocess.run(cmd, cwd=PROJECT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=3600)
    if r.returncode != 0 or not out.exists():
        text = (r.stderr or "") + (r.stdout or "")
        (out_dir / "remotion_error.txt").write_text(   # the whole story, to send to whoever helps
            "Command:\n" + subprocess.list2cmdline(cmd) + f"\n\nExit code: {r.returncode}\n\n{text}", encoding="utf-8")
        reason = next((ln.strip() for ln in text.splitlines() if "error" in ln.lower()), "") or text.strip()[-300:]
        raise RuntimeError(f"Remotion render failed: {reason[:400]} (details: {out_dir / 'remotion_error.txt'})")
    (out_dir / "remotion_error.txt").unlink(missing_ok=True)
    return out

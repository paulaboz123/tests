"""
benchmark.py - one request, every tool at its best, side by side: the same script (same prompt, same
material, same content) is voiced by every narrator and drawn by every video tool, as slides and as
an animation, so the solutions can be compared on how they look and sound, time and cost.

  uv run benchmark.py "a 1-minute video presentation on data connections" --minutes 1
      default: narrators kokoro + elevenlabs, tools html (local, open source) + remotion-pro,
      types clean (slides) + presenter (animation) = 8 videos, plus each narrator as audio
  uv run benchmark.py --report "data/output/<comparison folder>"     (rebuild the page, e.g. after AI clips)
  uv run benchmark.py "the scrum roles" --minutes 2 --voices kokoro,elevenlabs,system ^
      --renderers html,remotion --styles clean,presenter,dialogue
  uv run benchmark.py --from data/output/<folder of an existing video>     (reuse its script)
  uv run benchmark.py --from data/output/<folder> --voices kokoro:af_heart,kokoro:bf_emma,elevenlabs:lily,^
      elevenlabs:lily+plain,elevenlabs:george@flash --renderers remotion-pro --styles presenter ^
      --presenters robot,cat,person-2d:micah

Voices (--voices):     engine[:voice][@model][+plain]
   kokoro (local, free)          kokoro:bf_emma ... (uv run tts.py --voices)
   elevenlabs (cloud, paid)      elevenlabs:lily, :george, :matilda ... or a voice id; @v2 (multilingual,
                                 best), @flash, @turbo (half the credits), @v3 (most expressive, no
                                 context); +plain = the old way (each part on its own), to hear the difference
   system (Windows voice)
   One script, so every narrator says the same; ElevenLabs characters are counted per narrator.
Video (--renderers):   html (built-in engine) · remotion (cd remotion && npm install) · remotion-ai · remotion-pro
                       (Remotion, Claude writes each scene's React code; react_scenes.py) · pillow (simple)
Video types (--styles, default all four):
   clean        slides with a narrator
   illustrated  slides with illustrations and motion
   presenter    an animated cartoon presenter next to the slides
   dialogue     two characters talking about the slides (two voices)
   --characters cartoon and/or people: the drawn characters of the built-in engines (default: none,
   so their animation versions are left out; remotion-pro draws its own presenters)
Presenters of remotion-pro (--presenters, default PRO_PRESENTER in .env): robot, cat, person-3d,
   person-2d (PRO_AVATAR) or person-2d:micah / :avataaars / :notionists, none
Any setting of .env in several versions (--vary, repeatable; every combination is made):
   --vary THEME_ACCENT=#0b6e79,#7c3aed --vary GSAP=yes,no --vary VIDEO_WIDTH=1280,1920
Only the voices (--audio-only): one narration per narrator, no video; minutes instead of an hour:
   uv run benchmark.py --from data/output/<folder> --audio-only --voices kokoro:af_heart,elevenlabs:lily,elevenlabs:jessica

The script is written once (its cost is shown once, shared by all variants). Variants that cannot
run here (no key, no Node.js ...) are skipped with the reason. Each variant has its own folder with
the video and a run card; the voice of one engine is made once and reused by the other variants
with the same voice (no double cloud cost).

Result in the comparison folder:
  comparison.html  the document to compare: video (slides, animation) per tool and narrator, the audio
                   per narrator, AI video added later (ElevenLabs), and the cost of each version
  benchmark.csv    the same as a table (Excel); fill in the rating columns while watching
  benchmark.md     short summary
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import html
import itertools
import json
import logging
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path

import config
import lesson
import llm
import make_video
import quality
import remotion_render
import runcard
import store
import storyboard
import tts

log = logging.getLogger("benchmark")

VOICES = ("kokoro", "elevenlabs", "system")
RENDERERS = ("html", "remotion", "remotion-ai", "remotion-pro", "pillow")
STYLES = tuple(storyboard.STYLES)


@contextlib.contextmanager
def settings(**values):
    """Change config values for one variant and put them back afterwards."""
    old = {k: getattr(config, k) for k in values}
    try:
        for k, v in values.items():
            setattr(config, k, v)
        yield
    finally:
        for k, v in old.items():
            setattr(config, k, v)


def parse_voice(spec: str) -> dict:
    """A narrator: engine[:voice][@model][+plain], e.g. kokoro:bf_emma, elevenlabs:lily@flash."""
    rest = spec.strip()
    plain = rest.lower().endswith("+plain")
    rest = rest[:-len("+plain")] if plain else rest
    rest, _, model = rest.partition("@")
    engine, _, voice = rest.partition(":")
    engine = engine.strip().lower()
    if engine not in VOICES:
        raise ValueError(f"unknown voice engine {engine!r} in {spec!r}; use {', '.join(VOICES)}")
    if engine != "elevenlabs" and (model or plain):
        raise ValueError(f"{spec!r}: @model and +plain are for elevenlabs")
    return {"engine": engine, "voice": voice.strip(), "model": model.strip(), "plain": plain}


def voice_config(spec: str) -> dict:
    """The .env values a narrator stands for (applied while its variants are made)."""
    v = parse_voice(spec)
    out = {"TTS_ENGINE": v["engine"]}
    if v["engine"] == "kokoro" and v["voice"]:
        out["TTS_VOICE"] = v["voice"]
    if v["engine"] == "elevenlabs":
        if v["voice"]:
            out["ELEVENLABS_VOICE"] = v["voice"]
        if v["model"]:
            out["ELEVENLABS_MODEL"] = tts.eleven_model_id(v["model"])
        if v["plain"]:   # how it was before: each part on its own, ElevenLabs' standard settings, random take
            out.update(ELEVENLABS_CONTEXT=False, ELEVENLABS_STABILITY=0.5, ELEVENLABS_SIMILARITY=0.75,
                       ELEVENLABS_STYLE=0.0, ELEVENLABS_SEED=0, ELEVENLABS_FORMAT="pcm_24000")
    return out


def voice_label(spec: str) -> str:
    """How a narrator is shown in the report."""
    try:
        v = parse_voice(spec)
    except ValueError:
        return spec
    if v["engine"] == "kokoro":
        return f"Kokoro · {v['voice'] or config.TTS_VOICE} (local, free)"
    if v["engine"] == "system":
        return "Windows voice (local, free)"
    name = tts.eleven_voice_name(tts.eleven_voice_id(v["voice"] or config.ELEVENLABS_VOICE or tts.ELEVEN_DEFAULTS["narrator"]))
    model = tts.eleven_model_id(v["model"] or config.ELEVENLABS_MODEL).removeprefix("eleven_")
    return f"ElevenLabs · {name} · {model}" + (" · old way (parts separately)" if v["plain"] else "")


def presenter_config(presenter: str) -> dict:
    """PRO_PRESENTER / PRO_AVATAR for a remotion-pro variant ('' = as in .env)."""
    if not presenter:
        return {}
    who, _, look = presenter.partition(":")
    return {"PRO_PRESENTER": who, **({"PRO_AVATAR": look} if look else {})}


VOICE_KEYS = ("TTS_", "ELEVENLABS_", "HOST_VOICE", "EXPERT_VOICE")   # settings that change the voice
SECRET = ("KEY", "TOKEN", "SECRET", "PASSWORD")


def parse_vary(items: list[str]) -> list[tuple[str, list[str]]]:
    """--vary KEY=a,b (several times) -> [(KEY, [a, b]), ...]; only real settings, never keys."""
    out = []
    for item in items:
        key, _, values = item.partition("=")
        key = key.strip().upper()
        vals = [x.strip() for x in values.split(",") if x.strip()]
        if not key or not vals:
            raise ValueError(f"--vary {item!r}: write KEY=value1,value2")
        if not hasattr(config, key) or key.startswith("_") or any(w in key for w in SECRET):
            raise ValueError(f"--vary {item!r}: {key} is not a setting that can be varied")
        out.append((key, vals))
    return out


def vary_config(pairs: list[tuple[str, str]]) -> dict:
    """[(KEY, "value")] -> config values of the right type (yes/no, numbers, text)."""
    out = {}
    for key, raw in pairs:
        old = getattr(config, key)
        if isinstance(old, bool):
            value = raw.lower() in ("yes", "true", "1", "on")
        elif isinstance(old, int):
            value = int(float(raw))
        elif isinstance(old, float):
            value = float(raw)
        else:
            value = raw.lower() if isinstance(old, str) and old == old.lower() and not raw.startswith("#") else raw
        out[key] = value
        if key == "VIDEO_WIDTH":   # the height follows (16:9)
            out["VIDEO_HEIGHT"] = value * 9 // 16
    return out


def slug(text: str) -> str:
    """A part of a folder name (no : @ + on Windows)."""
    return re.sub(r"[^A-Za-z0-9_-]+", "_", text).strip("_")


def can_run(voice: str, renderer: str, style: str = "", characters: str = "") -> str:
    """Why a variant cannot run here ('' = it can)."""
    if renderer in ("remotion", "remotion-ai") and style in ("presenter", "dialogue") and (characters or config.CHARACTERS) != "cartoon":
        return "remotion: draws only the cartoon characters (use --characters cartoon)"
    with settings(**voice_config(voice)):
        ok, why = tts.check()
    if not ok:
        return f"voice {voice}: {why}"
    if renderer.startswith("remotion"):
        remotion_render.ensure_installed()
        ok, why = remotion_render.available()
        if not ok:
            return f"remotion: {why}"
    if renderer == "html":
        import slides_html
        with settings(RENDERER="html"):
            ok, why = slides_html.available()
        if not ok:
            return f"html: {why}"
    return ""


def variants(voices: list[str], renderers: list[str], styles: list[str], characters: list[str],
             presenters: list[str] | None = None, vary: list[tuple[str, list[str]]] | None = None,
             audio_only: bool = False) -> list[dict]:
    """Every combination once. Animated styles: the built-in engines vary their drawn characters
    (--characters; none = left out), remotion-pro its own presenters (--presenters). --vary
    multiplies everything by its values. audio_only: one narration per narrator, nothing drawn."""
    combos = [list(zip([k for k, _ in vary], vals, strict=True)) for vals in itertools.product(*[v for _, v in vary])] \
        if vary else [[]]
    out = []
    if audio_only:
        for voice, combo in itertools.product(voices, combos):
            name = "-".join(x for x in (slug(voice), "audio", *(slug(f"{k}-{v}") for k, v in combo)) if x)
            out.append({"name": name, "voice": voice, "renderer": "audio", "style": "clean", "characters": "",
                        "presenter": "", "vary": combo})
        return out
    for voice, renderer, style, combo in itertools.product(voices, renderers, styles, combos):
        if style not in ("presenter", "dialogue"):
            options = [("", "")]
        elif renderer == "remotion-pro":
            options = [("", p) for p in (presenters or [""])]
        else:
            options = [(ch, "") for ch in characters]
        for ch, pr in options:
            name = "-".join(x for x in (slug(voice), renderer, style, ch, slug(pr), *(slug(f"{k}-{v}") for k, v in combo)) if x)
            out.append({"name": name, "voice": voice, "renderer": renderer, "style": style, "characters": ch,
                        "presenter": pr, "vary": combo})
    return out


def base_storyboard(args, bench: Path) -> dict:
    """The one script all variants share: written now, or taken from an existing folder."""
    if args.source:
        sb = storyboard.load(Path(args.source))
        log.info("Using the script of %s", args.source)
        return sb
    # illustrated first: its script keeps the pictures; the other styles drop them (illustration_rules)
    style = ("illustrated" if "illustrated" in args.styles
             else "presenter" if any(s in ("presenter", "dialogue") for s in args.styles) else args.styles[0])
    folder = make_video.plan(args.topic, args.recording, args.minutes, args.level, args.model, args.wishes, style)
    target = bench / "script"
    shutil.move(str(folder), target)
    return storyboard.load(target)


def run(args) -> Path:
    created = datetime.now().strftime("%Y%m%d-%H%M%S")
    bench = config.OUTPUT_DIR / f"{created}-benchmark-{store.slugify(args.topic or Path(args.source).name, 40)}"
    bench.mkdir(parents=True)
    t0 = time.perf_counter()
    sb = base_storyboard(args, bench)
    shared_calls = list(sb.get("plan_calls") or []) if not args.source else []   # the script, paid once
    dialogue_lines = None
    audio_only = getattr(args, "audio_only", False)
    plan = variants(args.voices, args.renderers, args.styles, args.characters, getattr(args, "presenters", None),
                    getattr(args, "vary", None), audio_only)
    if not plan:
        raise ValueError("nothing to make: animated styles with --renderers html/remotion need --characters cartoon or people")
    if not audio_only and not args.characters and any(s in ("presenter", "dialogue") for s in args.styles) \
            and any(r != "remotion-pro" for r in args.renderers):
        log.info("Animated versions of %s left out (their drawn bear and fox); add --characters cartoon or people "
                 "to include them", ", ".join(r for r in args.renderers if r != "remotion-pro"))
    chars = sum(len(sc.get("narration", "")) for sc in sb["scenes"])
    cloud = [v for v in args.voices if parse_voice(v)["engine"] == "elevenlabs"]
    if cloud:
        log.info("Cloud voices will speak about %s characters each (%s); ElevenLabs free plan: 10,000 a month",
                 f"{chars:,}", ", ".join(cloud))
    eleven_short = ""
    if cloud:   # enough characters left this month? (narration + conversation, each once, per narrator)
        import usage
        q = usage.elevenlabs(refresh=True)
        need = int(chars * (1 + (1.15 if "dialogue" in args.styles and not audio_only else 0)) * len(cloud))
        if q:
            log.info("ElevenLabs: needs ~%s characters, %s of %s left", f"{need:,}", f"{q['left']:,}", f"{q['limit']:,}")
            if need > q["left"]:
                eleven_short = (f"ElevenLabs: needs ~{need:,} characters, only {q['left']:,} left"
                                + (f" (resets {q['resets']})" if q["resets"] else " this month"))
    rows, voice_cache = [], {}
    for k, v in enumerate(plan, 1):
        row = {**v, "status": "", "reason": "", "folder": ""}
        rows.append(row)
        why = eleven_short if parse_voice(v["voice"])["engine"] == "elevenlabs" and eleven_short else \
            can_run(v["voice"], v["renderer"] if v["renderer"] != "audio" else "", v["style"], v["characters"])
        if why:
            row.update(status="skipped", reason=why)
            log.warning("[%s/%s] %s skipped: %s", k, len(plan), v["name"], why)
            continue
        folder = bench / f"{k:02d}-{v['name']}"
        variant_sb = json.loads(json.dumps(sb))
        variant_sb.update(style=v["style"], characters=v["characters"] or config.CHARACTERS, plan_calls=[])
        storyboard.illustration_rules(variant_sb["scenes"], v["style"])   # pictures only where this style has them
        if v["style"] != "dialogue":   # a script taken from a conversation video: back to one narrator
            for sc in variant_sb["scenes"]:
                if sc.get("narration_original"):
                    sc["narration"] = sc["narration_original"]
                sc.pop("lines", None)
        if v["style"] == "dialogue":
            if dialogue_lines is None:   # the conversation is written once and shared too
                import dialogue
                tmp = json.loads(json.dumps(sb))
                mark = llm.meter_mark()
                dialogue.add_lines(tmp, args.model)
                shared_calls += llm.calls_since(mark)
                dialogue_lines = [(sc.get("lines"), sc.get("narration")) for sc in tmp["scenes"]]
            for sc, (lines, narration) in zip(variant_sb["scenes"], dialogue_lines, strict=True):
                sc["lines"], sc["narration"] = lines, narration
                sc.pop("beats", None)
        variant_sb.setdefault("request", {}).update(style=v["style"], characters=variant_sb["characters"])
        storyboard.save(variant_sb, folder)
        voice_vary = tuple(x for x in v["vary"] if x[0].startswith(VOICE_KEYS))
        key = (v["voice"], v["style"] == "dialogue", voice_vary)
        if key in voice_cache:   # same voice and same text: reuse the audio, no second cloud cost
            shutil.copytree(voice_cache[key]["folder"] / "audio", folder / "audio", dirs_exist_ok=True)
        log.info("[%s/%s] %s ...", k, len(plan), v["name"])
        vt = time.perf_counter()
        try:
            values = {**voice_config(v["voice"]), **({"RENDERER": v["renderer"]} if v["renderer"] != "audio" else {}),
                      **presenter_config(v["presenter"]), **vary_config(v["vary"])}   # --vary wins
            with settings(**values):
                _, info = make_video.make(rerender=folder, audio_only=v["renderer"] == "audio")
                q = quality.check_any(folder) if v["renderer"] != "audio" else {"status": "", "fail": [], "issues": []}
        except Exception as e:   # one broken version must not stop the comparison of the others
            row.update(status="failed", reason=f"{type(e).__name__}: {e}"[:300], folder=folder.name)
            log.error("%s failed: %s", v["name"], e, exc_info=not isinstance(e, (RuntimeError, ValueError, OSError)))
            continue
        card = store.read_json(folder / "run_card.json", {})
        voice_cost = sum(x["cost_usd"] for x in card["cost"]["by_step"] if x["step"] == "voice")
        reused = key in voice_cache
        if reused:
            voice_cost = voice_cache[key]["cost"]
        else:
            voice_cache[key] = {"folder": folder, "cost": voice_cost}
        row.update(status="done", folder=folder.name, voice_label=voice_label(v["voice"]),
                   video=f"{folder.name}/lesson_video.mp4" if v["renderer"] != "audio" else "",
                   voice_engine=card["solution"].get("voice", ""), renderer_used=info.get("renderer", ""),
                   voice_cost_usd=round(voice_cost, 4), voice_reused="yes" if reused else "",
                   other_cost_usd=round(card["cost"]["total_usd"] - (0 if reused else voice_cost), 4),
                   video_s=info.get("duration_s", ""), make_s=round(time.perf_counter() - vt, 1),
                   verdict=q["status"], problems="; ".join(q["fail"] + q["issues"])[:300],
                   licence=remotion_render.LICENCE_NOTE if v["renderer"].startswith("remotion") else "free")
        if info.get("fallback"):   # Remotion failed: the video is the designer slides, say so
            row.update(status="fallback", reason=info["fallback"])
        card["benchmark"] = {"folder": bench.name, "variant": v["name"], "voice_reused": reused,
                             "shared_script_cost_usd": runcard.cost_summary(shared_calls)["total_usd"]}
        runcard.save(folder, card)
    shared = runcard.cost_summary(shared_calls)
    summary = {"created": created, "request": args.topic or args.source, "minutes": args.minutes, "level": args.level,
               "script_cost_usd": shared["total_usd"], "script_model": sb.get("model", ""),
               "characters_spoken": chars, "total_s": round(time.perf_counter() - t0, 1), "variants": rows,
               "folder": str(bench)}
    store.write_json(bench / "benchmark.json", summary)
    report(bench, summary)
    return bench


COLUMNS = ["name", "status", "tool", "type", "voice", "voice_label", "renderer", "style", "characters", "presenter", "vary",
           "voice_engine", "renderer_used",
           "voice_cost_usd", "voice_reused", "other_cost_usd", "ai_video_cost_usd", "licence", "video_s", "make_s", "verdict",
           "problems", "reason", "folder", "rating_voice_1to5", "rating_visuals_1to5", "notes"]

TOOLS = {"audio": "Audio only", "html": "Local, open source", "remotion-pro": "Remotion Pro", "remotion": "Remotion (templates)",
         "remotion-ai": "Remotion, scenes written by Claude", "pillow": "Simple slides (local)"}
TOOL_NOTES = {"html": "designer slides with motion (GSAP) and drawn characters, all on the laptop",
              "remotion-pro": "motion design and presenters (React; 3D with three.js or 2D), on the laptop",
              "remotion": "React templates", "remotion-ai": "Claude writes each scene's React code", "pillow": "still pictures"}
TYPES = {"clean": "Slides", "illustrated": "Slides with illustrations", "presenter": "Animation: a presenter",
         "dialogue": "Animation: a conversation"}


def who(r: dict) -> str:
    """What sets a variant apart besides tool, type and narrator: the drawn character or presenter,
    and the --vary settings ('' for none)."""
    vary = ", ".join(f"{k}={v}" for k, v in (r.get("vary") or []))
    return " · ".join(x for x in (r.get("presenter") or r.get("characters") or "", vary) if x)


def who_suffix(r: dict) -> str:
    return f" · {who(r)}" if who(r) else ""


def _licence(renderer: str) -> str:
    return remotion_render.LICENCE_NOTE if renderer.startswith("remotion") else "free (open source, runs on the laptop)"


def _ai_video(bench: Path, r: dict) -> list[dict]:
    """Real-looking videos added to a version later (ai_clips.py add / presenter): file and cost."""
    if r.get("status") != "done":
        return []
    card = store.read_json(bench / r["folder"] / "run_card.json", {}) or {}
    out = []
    for key, label in (("ai_clips", "AI clips (intro, breaks, ending)"), ("ai_presenter", "AI presenter (lip sync)")):
        e = card.get(key)
        if e and (bench / r["folder"] / e["file"]).exists():
            out.append({"file": f"{r['folder']}/{e['file']}", "label": label, "tool": e.get("tool", ""),
                        "model": e.get("model", ""), "cost_usd": float(e.get("cost_usd") or 0), "variant": r["name"]})
    return out


def report(bench: Path, s: dict) -> None:
    """comparison.html (to watch and listen: every tool, same content), benchmark.csv (to rate in
    Excel) and benchmark.md. Run again with --report to add AI videos made later."""
    rows = s["variants"]
    for r in rows:
        r["vary"] = [tuple(x) for x in (r.get("vary") or [])]   # (lists after a round trip through json)
        r.setdefault("tool", TOOLS.get(r["renderer"], r["renderer"]))
        r.setdefault("type", "Audio" if r["renderer"] == "audio" else TYPES.get(r["style"], r["style"]))
        ai = _ai_video(bench, r)
        r["ai_video_cost_usd"] = round(sum(x["cost_usd"] for x in ai), 4) if ai else ""
        r["_ai"] = ai
    with open(bench / "benchmark.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS, extrasaction="ignore")
        w.writeheader()
        w.writerows([{**r, "vary": ", ".join(f"{k}={v}" for k, v in r["vary"])} for r in rows])
    done = [r for r in rows if r["status"] == "done"]
    script = float(s.get("script_cost_usd") or 0)
    md = [f"# Comparison: {s['request']}", "",
          f"One script for every version: ${script:.4f} ({s['script_model']}), {s['characters_spoken']:,} characters spoken.",
          f"{len(done)} of {len(rows)} versions made in {s['total_s']} s.", "",
          "| Tool | Type | Narrator | Voice $ | AI video $ | Length s | Make s | Verdict |", "|---|---|---|---|---|---|---|---|"]
    md += [f"| {r['tool']}{who_suffix(r)} | {r['type']} | {voice_label(r['voice'])} | {r.get('voice_cost_usd', '')} | "
           f"{r.get('ai_video_cost_usd', '')} | {r.get('video_s', '')} | {r.get('make_s', '')} | "
           f"{r.get('verdict') or r['status'] + ': ' + r['reason'][:80]} |" for r in rows]
    (bench / "benchmark.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    (bench / "comparison.html").write_text(_page(s, rows, script), encoding="utf-8")
    old = bench / "benchmark.html"
    old.write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=comparison.html">'
                   '<a href="comparison.html">comparison.html</a>', encoding="utf-8")
    for r in rows:
        r.pop("_ai", None)


def _page(s: dict, rows: list[dict], script: float) -> str:
    e = html.escape
    voices = list(dict.fromkeys(r["voice"] for r in rows))
    audio_rows_all = rows
    rows = [r for r in rows if r["renderer"] != "audio"]   # the video tables; the audio list below has all
    tools = list(dict.fromkeys((r["renderer"], who(r)) for r in rows))
    styles = [x for x in TYPES if any(r["style"] == x for r in rows)]
    minutes = lambda r: max(0.1, float(r.get("video_s") or 0) / 60)  # noqa: E731

    def cell(r: dict | None) -> str:
        if not r:
            return '<td class="na">not in this run</td>'
        if r["status"] == "fallback":   # made, but not with this tool
            return (f'<td><video controls preload="metadata" src="{e(r["video"])}"></video>'
                    f'<p class="why"><b>Not this tool:</b> {e(r["reason"])}</p></td>')
        if r["status"] != "done":
            return f'<td><div class="skip">{e(r["status"])}</div><p class="why">{e(r["reason"])}</p></td>'
        problems = f'<br><small>{e(r["problems"][:140])}</small>' if r.get("problems") else ""
        return (f'<td><video controls preload="metadata" src="{e(r["video"])}"></video>'
                f'<p class="facts">{r["video_s"]} s long · voice ${r["voice_cost_usd"]}{" (reused)" if r["voice_reused"] else ""}'
                f' · made in {r["make_s"]} s · <span class="v-{e(r["verdict"])}">{e(r["verdict"])}</span>{problems}</p></td>')

    sections = []
    for st in styles:
        head = "".join(f"<th>{e(voice_label(v))}</th>" for v in voices)
        body = ""
        for tl, character in tools:
            if not any((r["renderer"], who(r)) == (tl, character) and r["style"] == st for r in rows):
                continue
            row = {r["voice"]: r for r in rows if (r["renderer"], who(r)) == (tl, character) and r["style"] == st}
            body += (f'<tr><th class="tool">{e(TOOLS.get(tl, tl))}{e(" · " + character if character else "")}'
                     f'<small>{e(TOOL_NOTES.get(tl, ""))}</small>'
                     f'<small class="lic">{e(_licence(tl))}</small></th>' + "".join(cell(row.get(v)) for v in voices) + "</tr>")
        sections.append(f'<section><h2>Video · {e(TYPES[st])}</h2><table class="grid"><thead><tr><th>Tool · narrator</th>{head}'
                        f"</tr></thead><tbody>{body}</tbody></table></section>")

    ai = [x for r in rows for x in r.get("_ai", [])]
    if ai:
        cards = "".join(f'<figure><video controls preload="metadata" src="{e(x["file"])}"></video><figcaption>{e(x["label"])}: '
                        f'{e(x["model"])} in {e(x["tool"])}, ${x["cost_usd"]:.2f} · on top of {e(x["variant"])}</figcaption></figure>'
                        for x in ai)
        ai_html = f'<div class="cards">{cards}</div>'
    else:
        ai_html = ("<p>None yet. ElevenLabs makes real-looking video (Google Veo clips, a presenter who says our narration)"
                   " only on a paid plan: in the web app from Starter ($6/month), from the code (eleven_video.py) from Pro "
                   "($99/month); the free plan has no video. Make the clips for one version, put them in with "
                   "<code>ai_clips.py add</code> or <code>ai_clips.py presenter</code>, then rebuild this page: "
                   f"<code>uv run benchmark.py --report \"{e(s.get('folder', ''))}\"</code>.</p>")
    sections.append(f"<section><h2>AI video (ElevenLabs)</h2>{ai_html}</section>")

    audio_rows = ""
    audio_keys = list(dict.fromkeys((r["voice"], tuple(x for x in (r.get("vary") or []) if x[0].startswith(VOICE_KEYS)))
                                    for r in audio_rows_all))
    for v, vv in audio_keys:
        same = [x for x in audio_rows_all if x["voice"] == v and tuple(y for y in (x.get("vary") or [])
                                                                        if y[0].startswith(VOICE_KEYS)) == vv]
        r = next((x for x in same if x["status"] in ("done", "fallback") and x["style"] != "dialogue"), None)
        label = voice_label(v) + (" · " + ", ".join(f"{a}={b}" for a, b in vv) if vv else "")
        if not r:
            why = next((x["reason"] for x in same), "")
            audio_rows += f'<tr><th>{e(label)}</th><td colspan="4" class="why">{e(why)}</td></tr>'
            continue
        per_min = float(r["voice_cost_usd"] or 0) / minutes(r)
        audio_rows += (f'<tr><th>{e(label)}<small>{e(r.get("voice_engine", ""))}</small></th>'
                       f'<td><audio controls preload="metadata" src="{e(r["folder"])}/lesson_audio.mp3"></audio></td>'
                       f'<td>{r["video_s"]} s</td><td>${r["voice_cost_usd"]}</td><td>${per_min:.3f}</td></tr>')
    sections.append('<section><h2>Audio · the same narration, other narrators</h2><table class="list"><thead><tr><th>Narrator</th>'
                    f"<th>Listen</th><th>Length</th><th>Voice cost</th><th>Per minute</th></tr></thead><tbody>{audio_rows}</tbody></table>"
                    "<p class=\"note\">Each video above uses its narrator's own timing, so picture and voice always fit. Versions"
                    " with the same narrator are equally long; another narrator speaks at its own pace.</p></section>")

    cost_rows = ""
    for r in [x for x in audio_rows_all if x["status"] == "done"]:
        voice = float(r["voice_cost_usd"] or 0)
        extra = float(r["ai_video_cost_usd"] or 0)
        total = script + voice + extra
        cost_rows += (f'<tr><td>{e(r["tool"])}{e(who_suffix(r))}</td><td>{e(r["type"])}</td><td>{e(voice_label(r["voice"]))}</td>'
                      f'<td>${script:.3f}</td><td>${voice:.3f}</td><td>{f"${extra:.2f}" if extra else "-"}</td><td>$0 (laptop)</td>'
                      f'<td><b>${total:.3f}</b></td><td>${total / minutes(r):.3f}</td><td>{r["make_s"]} s</td>'
                      f'<td><small>{e(_licence(r["renderer"]))}</small></td></tr>')
    sections.append('<section><h2>Cost per version</h2><table class="list"><thead><tr><th>Tool</th><th>Type</th><th>Narrator</th>'
                    "<th>Script (Claude)</th><th>Voice</th><th>AI video</th><th>Drawing</th><th>Total</th><th>Per minute</th>"
                    f"<th>Time to make</th><th>Licence</th></tr></thead><tbody>{cost_rows}</tbody></table>"
                    "<p class=\"note\">The script is written once for all versions; its cost is in every total, so each total is"
                    " what that version alone would cost. Estimates from list prices; ElevenLabs at the paid-plan rate per"
                    " character (the free plan's 10,000 characters a month cost $0).</p></section>")

    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Comparison: {e(str(s['request']))}</title><style>
body{{margin:0;padding:28px max(16px,3vw);font:15px/1.5 "Segoe UI",system-ui,sans-serif;background:#f4f6f8;color:#14232a}}
h1{{font-size:26px;margin:0 0 4px}} h2{{font-size:19px;margin:34px 0 12px}} .sub{{color:#56666d;margin:0}}
table{{border-collapse:collapse;background:#fff;border:1px solid #d9e2e3;border-radius:10px;overflow:hidden;width:100%}}
th,td{{border-bottom:1px solid #e6ecee;padding:10px 12px;text-align:left;vertical-align:top}} thead th{{background:#eef3f4;font-size:13px}}
.grid td{{width:{int(80 / max(1, len(voices)))}%}} .tool{{width:20%}} th small{{display:block;font-weight:400;color:#56666d;font-size:12px;margin-top:4px}}
.lic{{color:#8a5a00!important}} video{{width:100%;border-radius:6px;background:#000}} audio{{width:100%}}
.facts{{font-size:13px;color:#33444b;margin:6px 0 0}} .why,.na{{color:#56666d;font-size:13px}}
.skip{{padding:30px;text-align:center;color:#56666d;background:#eef1f3;border-radius:6px}}
.cards{{display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:16px}} figure{{margin:0;background:#fff;border:1px solid #d9e2e3;border-radius:10px;padding:10px}}
figcaption{{font-size:13px;color:#33444b;margin-top:6px}} .note{{color:#56666d;font-size:13px}}
.v-OK{{color:#1f7a45;font-weight:600}} .v-CHECK{{color:#b26a00;font-weight:600}} .v-FAIL{{color:#b4372f;font-weight:600}}
</style></head><body><h1>Comparison: {e(str(s['request']))}</h1>
<p class="sub">The same script (same content) made with every tool and narrator. Script written once by {e(s.get('script_model', ''))}
for ${script:.4f}; {s['characters_spoken']:,} characters spoken. Rate the versions in benchmark.csv.</p>
{''.join(sections)}</body></html>"""


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("topic", nargs="?", help="what the lesson is about")
    ap.add_argument("--from", dest="source", help="reuse the script of an existing video folder")
    ap.add_argument("--recording", help="ids or titles of recordings (instead of searching all)")
    ap.add_argument("--minutes", type=float, default=1)
    ap.add_argument("--level", choices=list(lesson.LEVELS), default="beginner")
    ap.add_argument("--wishes", default="")
    ap.add_argument("--model", help="override CHAT_MODEL for the script")
    ap.add_argument("--voices", default="kokoro,elevenlabs",
                    help="narrators, comma-separated: engine[:voice][@model][+plain], engines " + ", ".join(VOICES))
    ap.add_argument("--renderers", default="html,remotion-pro", help=f"video tools, comma-separated: {', '.join(RENDERERS)}")
    ap.add_argument("--styles", default="clean,presenter",
                    help=f"video types, comma-separated: {', '.join(STYLES)} (default: slides and animation)")
    ap.add_argument("--report", metavar="FOLDER", help="only rebuild comparison.html of a finished comparison (e.g. after adding AI clips)")
    ap.add_argument("--characters", default="",
                    help="drawn characters of the built-in engines for presenter/dialogue: cartoon, people or both "
                         "(default: none, those versions are left out)")
    ap.add_argument("--vary", action="append", default=[], metavar="KEY=a,b",
                    help="a setting of .env in several versions, e.g. THEME_ACCENT=#0b6e79,#7c3aed (repeatable)")
    ap.add_argument("--audio-only", action="store_true", help="only the narration of each narrator, no video (fast)")
    ap.add_argument("--presenters", default="",
                    help="remotion-pro presenters, comma-separated: robot, cat, person-3d, person-2d[:micah|avataaars|notionists],"
                         " none (default: PRO_PRESENTER in .env)")
    args = ap.parse_args()
    config.setup_logging()
    if args.report:
        bench = Path(args.report)
        summary = store.read_json(bench / "benchmark.json", None)
        if not summary:
            ap.error(f"no benchmark.json in {bench}")
        report(bench, summary)
        print(f"Rebuilt: {bench / 'comparison.html'}")
        return 0
    if not (args.topic or args.source):
        ap.error("give a topic or --from <folder>")
    for name, allowed in (("renderers", RENDERERS), ("styles", STYLES), ("characters", ("cartoon", "people"))):
        values = [x.strip() for x in getattr(args, name).split(",") if x.strip()]
        bad = [x for x in values if x not in allowed]
        if bad:
            ap.error(f"--{name}: unknown {bad}; use {', '.join(allowed)}")
        setattr(args, name, values)
    args.voices = [x.strip() for x in args.voices.split(",") if x.strip()]
    for v in args.voices:
        try:
            parse_voice(v)
        except ValueError as e:
            ap.error(f"--voices: {e}")
    try:
        args.vary = parse_vary(args.vary)
    except ValueError as e:
        ap.error(str(e))
    args.presenters = [x.strip().lower() for x in args.presenters.split(",") if x.strip()]
    for pr in args.presenters:
        who_, _, look = pr.partition(":")
        if who_ not in (*remotion_render.PRESENTERS, "none") or (look and look not in remotion_render.AVATARS):
            ap.error(f"--presenters: unknown {pr!r}; use {', '.join(remotion_render.PRESENTERS)}, none; "
                     f"person-2d:{'/'.join(remotion_render.AVATARS)}")
    try:
        bench = run(args)
    except lesson.NotEnoughMaterial as e:
        log.error("%s", e)
        return 2
    except (RuntimeError, ValueError, OSError) as e:
        log.error("%s", e)
        return 1
    s = store.read_json(bench / "benchmark.json", {})
    print(f"\nScript (shared): ${s['script_cost_usd']:.4f}")
    for r in s["variants"]:
        if r["status"] == "done":
            print(f"  {r['name']:<40} voice ${r['voice_cost_usd']:<7} other ${r['other_cost_usd']:<7} "
                  f"{r['make_s']:>6}s  {r['verdict']}")
        else:
            print(f"  {r['name']:<40} {r['status']}: {r['reason'][:90]}")
    print(f"\nWatch and compare: {bench / 'comparison.html'}\nRate in Excel:     {bench / 'benchmark.csv'}")
    return 0


if __name__ == "__main__":
    code = main()
    import usage
    usage.report()   # spent today, ElevenLabs characters left, Remotion
    sys.exit(code)

"""
react_scenes.py - the experimental video engine "remotion-ai": Claude writes the React (Remotion)
code of every scene itself, instead of the fixed templates, so the motion fits each scene (a
timeline for steps, a cycle for a loop, a comparison for two sides ...).

  RENDERER=remotion-ai in .env, or compare_solutions.py --engines remotion-ai

Safe by construction:
- Claude gets only the scene's data (heading, items, chart values, timing) and must take every word
  from it: a component that writes words of its own is refused.
- Only React and Remotion may be used: no network, files, browser APIs, timers, random numbers,
  images or raw HTML; anything else is refused before it is run.
- The code is compiled first (esbuild); a scene that does not compile gets one retry with the error,
  then the template is used. A scene that fails while rendering also falls back to the template
  (an error boundary in Lesson.tsx), so a video is always made.
Every scene costs one Claude call (shown on the run card as step "react_scenes"). The code of each
scene is kept in the video folder (ai_scenes/) to look at.
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path

import config
import llm

log = logging.getLogger("react_scenes")
AI_DIR = config.ROOT / "remotion" / "src" / "ai"
EMPTY_INDEX = ("// Scenes written by Claude for one render (react_scenes.py); empty between renders.\n"
               "import type React from 'react';\nimport type {Scene} from '../Lesson';\n\n"
               "export type AIScene = React.FC<{sc: Scene; accent: string; accent2: string}>;\n"
               "export const AI_SCENES: Record<number, AIScene> = {};\n")
MAX_CHARS = 14000
ALLOWED_MODULES = {"react", "remotion", "../Lesson"}
BANNED = re.compile(
    r"(fetch\s*\(|XMLHttpRequest|WebSocket|\beval\s*\(|new\s+Function|\bFunction\s*\(|\bwindow\b|\bdocument\b|globalThis"
    r"|localStorage|sessionStorage|dangerouslySetInnerHTML|\brequire\s*\(|\bimport\s*\(|https?://|Math\.random|\bDate\b"
    r"|setTimeout|setInterval|requestAnimationFrame|useEffect|useLayoutEffect|useState|useRef|<img|<video|<iframe|<script"
    r"|staticFile|<Audio|<Img|<OffthreadVideo|process\.)")
# words typed between JSX tags (<div>Key steps</div>): all words must come from the scene's data
JSX_TEXT = re.compile(r"(?:<[A-Za-z][^<>]*?>|</[A-Za-z.]+>)([^<>{}]*?[A-Za-z]{2,}[^<>{}]*?)(?=</?[A-Za-z{])")

SYSTEM = """You write one scene of a training video as a React component for Remotion (1920x1080, 30 fps).
You get the scene's data as JSON. Write a component that shows exactly this data with clear, calm,
professional motion that fits the content: a timeline or numbered path for steps, a cycle for a loop,
two columns for a comparison, a hub for parts of a whole, a big number for a key figure, bars for a
chart. Make it look designed, not like plain cards.

Hard rules (the code is checked; breaking one means the scene is thrown away):
- TypeScript + JSX, one file. Imports only from 'react' and 'remotion' (AbsoluteFill, interpolate,
  spring, Easing, useCurrentFrame, useVideoConfig), plus `import type {Scene} from '../Lesson';`.
- Export exactly: export const {name}: React.FC<{sc: Scene; accent: string; accent2: string}> = ({sc, accent, accent2}) => { ... };
- Every word on screen comes from `sc` (sc.heading, sc.subheading, sc.units[i].title / detail / value /
  items, sc.chart). Never type words, labels or numbers of your own into the JSX.
- Animate only from useCurrentFrame() (frame 0 = start of this scene). Unit i appears at sc.appear[i]
  seconds (frame = sc.appear[i] * fps) and is highlighted while the time is inside sc.active[i] = [from, to]
  seconds (null = never). sc.duration_s is the scene's length. Use spring/interpolate, no CSS animations.
- No state, effects, refs, timers, random numbers, dates, network, images, raw HTML, window or document.
- Readable: heading 64-80 px, other text at least 28 px, keep 100 px margins, nothing outside the frame,
  at most 6 units on screen; long details may be shortened with CSS (line clamp), never rewritten.
- Colours: accent and accent2 for emphasis, #0f1b2d for text, #5b6b7f for quiet text, white or #f6f8fb
  backgrounds. Font: inherit.
Answer with the code only, in one ```tsx block."""


class SceneCodeError(ValueError):
    pass


def check_code(code: str, name: str) -> str:
    """Why this component may not be used ('' = fine): the safety and contract checks."""
    if len(code) > MAX_CHARS:
        return f"too long ({len(code)} characters)"
    if not re.search(rf"export\s+const\s+{re.escape(name)}\b", code):
        return f"no exported component {name}"
    for mod in re.findall(r"""from\s+['"]([^'"]+)['"]""", code):
        if mod not in ALLOWED_MODULES:
            return f"imports {mod!r} (only react and remotion are allowed)"
    m = BANNED.search(code)
    if m:
        return f"uses {m.group(0).strip()!r}, which is not allowed"
    m = JSX_TEXT.search(code)
    if m and not re.fullmatch(r"[\s\W\d]*", m.group(1).replace("&nbsp;", "")):
        return f"writes its own words on screen ({m.group(1).strip()[:40]!r}); all words must come from sc"
    return ""


def compile_errors(files: list[Path]) -> dict[str, str]:
    """esbuild's errors per file ({} = all compile). Uses the esbuild that Remotion installs."""
    script = ("const e=require('esbuild'),fs=require('fs');const out={};for(const f of process.argv.slice(1)){"
              "try{e.transformSync(fs.readFileSync(f,'utf8'),{loader:'tsx',jsx:'automatic'})}"
              "catch(x){out[f]=(x.errors||[]).map(r=>r.text+(r.location?' (line '+r.location.line+')':'')).join('; ')||String(x)}}"
              "console.log(JSON.stringify(out))")
    import remotion_render
    node = remotion_render.node()   # on PATH, or next to npx (portable Node.js)
    if not node:
        raise RuntimeError("Node.js not found")
    r = subprocess.run([node, "-e", script, *map(str, files)], cwd=config.ROOT / "remotion", capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=120)
    if r.returncode != 0:
        raise RuntimeError(f"esbuild check failed: {(r.stderr or r.stdout)[-300:]}")
    return {Path(k).name: v for k, v in json.loads(r.stdout.strip().splitlines()[-1]).items()}


def scene_data(sc: dict) -> dict:
    """What Claude sees of a scene: its data and timing, no icons or character drawings."""
    keep = {k: sc[k] for k in ("kind", "heading", "subheading", "label", "appear", "active", "correct", "duration_s")
            if sc.get(k) not in (None, "", [])}
    keep["units"] = [{k: u[k] for k in ("title", "detail", "value", "items") if u.get(k)} for u in sc.get("units", [])]
    if sc.get("chart"):
        keep["chart"] = sc["chart"]
    return keep


def write_scene(i: int, sc: dict, model: str | None = None, error: str = "", previous: str = "") -> str:
    """Ask Claude for the component of scene i (again with the error, when the first try failed)."""
    name = f"Scene{i}"
    prompt = f"Scene data:\n{json.dumps(scene_data(sc), ensure_ascii=False, indent=1)}\n\nComponent name: {name}"
    if error:
        prompt += f"\n\nYour previous code was refused: {error}\nFix it.\n```tsx\n{previous[:MAX_CHARS]}\n```"
    text = llm.chat(prompt, system=SYSTEM.replace("{name}", name), step="react_scenes", model=model,
                    temperature=0.4, max_tokens=4000)
    m = re.search(r"```(?:tsx|typescript|ts|jsx)?\s*\n(.*?)```", text, re.S)
    return (m.group(1) if m else text).strip() + "\n"


def prepare(props: dict, out_dir: Path, model: str | None = None) -> dict:
    """Write the scenes' components into remotion/src/ai (kept in out_dir/ai_scenes too).
    Returns {"written": [...], "template": {scene: reason}}."""
    AI_DIR.mkdir(parents=True, exist_ok=True)
    clear()
    keep = out_dir / "ai_scenes"
    keep.mkdir(parents=True, exist_ok=True)
    codes, why = {}, {}
    for i, sc in enumerate(props["scenes"]):
        try:
            code = write_scene(i, sc, model)
        except llm.LLMError as e:
            why[i] = f"no code: {str(e)[:120]}"
            continue
        problem = check_code(code, f"Scene{i}")
        if problem:   # one retry with the reason
            code = write_scene(i, sc, model, problem, code)
            problem = check_code(code, f"Scene{i}")
        if problem:
            why[i] = problem
            continue
        codes[i] = code
    files = {i: AI_DIR / f"scene_{i}.tsx" for i in codes}
    for i, code in codes.items():
        files[i].write_text(code, encoding="utf-8")
    errors = compile_errors(list(files.values())) if files else {}
    for i in [i for i in codes if files[i].name in errors]:
        code = write_scene(i, props["scenes"][i], model, "does not compile: " + errors[files[i].name], codes[i])
        problem = check_code(code, f"Scene{i}")
        if not problem:
            files[i].write_text(code, encoding="utf-8")
            problem = compile_errors([files[i]]).get(files[i].name, "")
        if problem:
            why[i] = problem
            files[i].unlink(missing_ok=True)
            codes.pop(i)
        else:
            codes[i] = code
    for i, code in codes.items():
        (keep / f"scene_{i}.tsx").write_text(code, encoding="utf-8")
    index = EMPTY_INDEX.replace("export const AI_SCENES: Record<number, AIScene> = {};", "".join(
        f"import {{Scene{i}}} from './scene_{i}';\n" for i in codes)
        + "\nexport const AI_SCENES: Record<number, AIScene> = {" + ", ".join(f"{i}: Scene{i}" for i in codes) + "};")
    (AI_DIR / "index.ts").write_text(index, encoding="utf-8")
    (keep / "report.json").write_text(json.dumps({"written": sorted(codes), "template": why}, indent=1), encoding="utf-8")
    if why:
        log.warning("Claude's scenes: %s of %s used; template for %s", len(codes), len(props["scenes"]),
                    "; ".join(f"scene {i + 1}: {w}" for i, w in sorted(why.items())))
    return {"written": sorted(codes), "template": why}


def clear() -> None:
    """Back to no AI scenes (between renders, so a normal Remotion render uses only templates)."""
    AI_DIR.mkdir(parents=True, exist_ok=True)
    for f in AI_DIR.glob("scene_*.tsx"):
        f.unlink()
    (AI_DIR / "index.ts").write_text(EMPTY_INDEX, encoding="utf-8")

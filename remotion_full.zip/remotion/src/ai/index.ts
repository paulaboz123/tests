// Scenes written by Claude for one render (react_scenes.py); empty between renders.
import type React from 'react';
import type {Scene} from '../Lesson';

export type AIScene = React.FC<{sc: Scene; accent: string; accent2: string}>;
export const AI_SCENES: Record<number, AIScene> = {};

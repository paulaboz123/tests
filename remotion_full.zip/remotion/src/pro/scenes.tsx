// The Pro scene layouts: one per kind of visual in the storyboard. Every element appears when the
// voice reaches it (sc.appear) and lights up while the voice talks about it (sc.active).
import React from 'react';
import {interpolate} from 'remotion';
import type {Scene, Unit} from '../Lesson';
import {FAINT, Glass, INK, Icon, Kinetic, SOFT, clamp, clean, hexA, isOn, ramp, useSpring, useT} from './theme';

type P = {sc: Scene; accent: string; accent2: string; w: number; h: number};

const appearAt = (sc: Scene, i: number) => sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.4 + i * 0.5;
const activeIndex = (sc: Scene, t: number) => sc.active.findIndex((w) => isOn(w, t));

// Heading block shared by most scenes: a small label, the heading word by word, an accent bar.
const Head: React.FC<{sc: Scene; accent: string; accent2: string; size?: number}> = ({sc, accent, accent2, size = 74}) => {
  const t = useT();
  const bar = ramp(t, 0.25, 0.9);
  const label = clean(sc.label) || {steps: 'Step by step', timeline: 'Timeline', cycle: 'The cycle', comparison: 'Side by side',
    stats: 'Key numbers', chart: 'The data', question: 'Quick check', answer: 'The answer', example: 'Example',
    concept: 'Key idea', callout: 'Remember', table: 'Overview', hub: 'How it connects', calculation: 'Worked example'}[sc.kind] || '';
  return (
    <div style={{marginBottom: 46}}>
      {label ? (
        <div style={{display: 'inline-flex', alignItems: 'center', gap: 12, padding: '10px 20px', borderRadius: 999,
          background: 'rgba(255,255,255,.08)', border: '1px solid rgba(255,255,255,.14)', color: SOFT, fontSize: 22,
          fontWeight: 600, letterSpacing: '.12em', textTransform: 'uppercase', marginBottom: 22, opacity: ramp(t, 0, 0.4)}}>
          <span style={{width: 10, height: 10, borderRadius: 5, background: accent2, boxShadow: `0 0 14px ${accent2}`}} />{label}
        </div>
      ) : null}
      <Kinetic text={clean(sc.heading)} at={0.05} size={size} />
      <div style={{height: 7, width: 150 * bar, borderRadius: 4, marginTop: 22,
        background: `linear-gradient(90deg, ${accent}, ${accent2})`, boxShadow: `0 0 24px ${hexA(accent, 0.8)}`}} />
      {sc.subheading ? <div style={{fontSize: 30, color: SOFT, marginTop: 20, opacity: ramp(t, 0.4, 0.9)}}>{clean(sc.subheading)}</div> : null}
    </div>
  );
};

// One element as a glass card that flips up into place.
const Card: React.FC<{u: Unit; i: number; sc: Scene; accent: string; accent2: string; compact?: boolean; n: number}> =
  ({u, i, sc, accent, accent2, compact, n}) => {
  const t = useT();
  const at = appearAt(sc, i);
  const s = useSpring(at, 14, 120);
  const on = isOn(sc.active[i], t);
  const any = activeIndex(sc, t) >= 0;
  const start = sc.active[i]?.[0];
  return (
    <div style={{flex: 1, minWidth: 0, opacity: Math.min(1, s * 1.4), perspective: 1200,
      transform: `translateY(${(1 - s) * 70}px)`, filter: `blur(${(1 - Math.min(1, s)) * 8}px)`}}>
      <Glass on={on} dim={any && !on} accent={accent} sweepAt={start}
        style={{height: '100%', transform: `rotateX(${(1 - s) * 28}deg) scale(${on ? 1.035 : 1})`, transformOrigin: '50% 100%',
          padding: compact ? '26px 32px' : '42px 40px', display: 'flex', flexDirection: compact ? 'row' : 'column',
          alignItems: compact ? 'center' : 'flex-start', gap: compact ? 28 : 26}}>
        <Icon svg={u.icon} label={String(i + 1)} size={compact ? 70 : 92} accent={accent} accent2={accent2} on={on} />
        <div style={{minWidth: 0}}>
          {u.value ? <div style={{fontSize: compact ? 44 : 60, fontWeight: 800, color: accent2, marginBottom: 6}}>{u.value}</div> : null}
          <div style={{fontSize: compact ? 36 : n > 3 ? 36 : 42, fontWeight: 700, color: INK, lineHeight: 1.15}}>{clean(u.title)}</div>
          {u.detail ? <div style={{fontSize: compact ? 25 : 28, color: SOFT, marginTop: 12, lineHeight: 1.38}}>{clean(u.detail)}</div> : null}
          {u.items ? (
            <div style={{marginTop: 16, display: 'flex', flexDirection: 'column', gap: 12}}>
              {u.items.map((x, k) => {
                const p = ramp(t, at + 0.3 + k * 0.25, at + 0.8 + k * 0.25);
                return <div key={k} style={{fontSize: 27, color: SOFT, opacity: p, transform: `translateX(${(1 - p) * 30}px)`,
                  display: 'flex', gap: 14}}><span style={{color: accent2}}>●</span>{clean(x)}</div>;
              })}
            </div>
          ) : null}
        </div>
      </Glass>
    </div>
  );
};

const Cards: React.FC<P> = ({sc, accent, accent2}) => {
  const n = sc.units.length;
  const grid = n === 4;
  const list = n >= 5;
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} />
      <div style={{flex: list || grid ? 1 : '0 0 auto', minHeight: 0, display: grid ? 'grid' : 'flex', gridTemplateColumns: grid ? '1fr 1fr' : undefined,
        flexDirection: list ? 'column' : 'row', gap: list ? 18 : 30, alignItems: 'stretch', marginTop: list || grid ? 0 : 20}}>
        {sc.units.map((u, i) => <Card key={i} u={u} i={i} sc={sc} accent={accent} accent2={accent2} compact={list || grid} n={n} />)}
      </div>
    </div>
  );
};

// Steps and timelines: nodes in a row, joined by a line that draws itself as the voice moves on.
const Flow: React.FC<P> = ({sc, accent, accent2, w}) => {
  const t = useT();
  const n = Math.max(1, sc.units.length);
  const reached = sc.units.reduce((k, _, i) => (t >= appearAt(sc, i) ? i : k), -1);
  const prog = reached < 0 ? 0 : Math.min(1, (reached + ramp(t, appearAt(sc, Math.min(n - 1, reached + 1)) - 0.6,
    appearAt(sc, Math.min(n - 1, reached + 1)))) / Math.max(1, n - 1));
  const span = w - w / n;
  const act = activeIndex(sc, t);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} />
      <div style={{position: 'relative', flex: 1}}>
        <div style={{position: 'absolute', left: w / n / 2, top: 64, width: span, height: 6, borderRadius: 3, background: 'rgba(255,255,255,.12)'}} />
        <div style={{position: 'absolute', left: w / n / 2, top: 64, width: span * prog, height: 6, borderRadius: 3,
          background: `linear-gradient(90deg, ${accent}, ${accent2})`, boxShadow: `0 0 22px ${hexA(accent2, 0.9)}`}} />
        <div style={{position: 'absolute', left: w / n / 2 + span * prog - 14, top: 53, width: 28, height: 28, borderRadius: 14,
          background: '#fff', boxShadow: `0 0 30px 8px ${hexA(accent2, 0.85)}`, opacity: n > 1 ? 1 : 0}} />
        <div style={{display: 'flex', position: 'absolute', inset: 0}}>
          {sc.units.map((u, i) => {
            const s = useSpring(appearAt(sc, i), 12, 140);
            const on = act === i;
            return (
              <div key={i} style={{flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '0 14px',
                opacity: Math.min(1, s * 1.5), transform: `translateY(${(1 - s) * 50}px)`}}>
                <div style={{width: 134, height: 134, borderRadius: 67, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: on ? `linear-gradient(135deg, ${accent}, ${accent2})` : 'rgba(12,22,40,.9)',
                  border: `3px solid ${on ? '#fff' : hexA(accent, 0.9)}`, transform: `scale(${(0.6 + 0.4 * s) * (on ? 1.1 : 1)})`,
                  boxShadow: on ? `0 0 60px ${hexA(accent2, 0.8)}` : `0 18px 40px rgba(0,0,0,.45)`, color: '#fff', fontSize: 52, fontWeight: 800}}>
                  {u.icon ? <span style={{width: 58, height: 58, display: 'inline-flex'}} dangerouslySetInnerHTML={{__html: u.icon}} /> : i + 1}
                </div>
                <div style={{fontSize: 22, color: accent2, fontWeight: 700, letterSpacing: '.14em', marginTop: 26}}>
                  {sc.kind === 'timeline' ? (u.value || `STAGE ${i + 1}`) : `STEP ${i + 1}`}</div>
                <div style={{fontSize: n > 4 ? 30 : 36, fontWeight: 700, color: INK, textAlign: 'center', marginTop: 10, lineHeight: 1.15}}>{clean(u.title)}</div>
                {u.detail ? <div style={{fontSize: n > 4 ? 22 : 25, color: SOFT, textAlign: 'center', marginTop: 12, lineHeight: 1.35}}>{clean(u.detail)}</div> : null}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// A cycle: elements around a ring that fills as the voice goes round.
const Cycle: React.FC<P> = ({sc, accent, accent2, w, h}) => {
  const t = useT();
  const n = Math.max(3, sc.units.length);
  const size = Math.min(h - 230, w * 0.5);
  const r = size / 2 - 40;
  const reached = sc.units.reduce((k, _, i) => (t >= appearAt(sc, i) ? i + 1 : k), 0);
  const fill = ramp(t, 0.2, appearAt(sc, sc.units.length - 1) + 0.8) * (reached / n);
  const act = activeIndex(sc, t);
  const circ = 2 * Math.PI * r;
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} size={64} />
      <div style={{flex: 1, position: 'relative'}}>
        <svg width={size} height={size} style={{position: 'absolute', left: (w - size) / 2, top: 0, overflow: 'visible'}}>
          <defs><linearGradient id="ring" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={accent} /><stop offset="1" stopColor={accent2} /></linearGradient></defs>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,.12)" strokeWidth={10} />
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="url(#ring)" strokeWidth={10} strokeLinecap="round"
            strokeDasharray={circ} strokeDashoffset={circ * (1 - fill)} transform={`rotate(-90 ${size / 2} ${size / 2})`}
            style={{filter: `drop-shadow(0 0 12px ${accent2})`}} />
        </svg>
        {sc.units.map((u, i) => {
          const a = -Math.PI / 2 + (2 * Math.PI * i) / sc.units.length;
          const s = useSpring(appearAt(sc, i), 13, 130);
          const on = act === i;
          const cx = w / 2 + Math.cos(a) * r, cy = size / 2 + Math.sin(a) * r;
          return (
            <div key={i} style={{position: 'absolute', left: cx - 160, top: cy - 70, width: 320, opacity: Math.min(1, s * 1.5),
              transform: `scale(${(0.5 + 0.5 * s) * (on ? 1.08 : 1)})`}}>
              <Glass on={on} accent={accent} style={{padding: '22px 24px', textAlign: 'center'}}>
                <div style={{fontSize: 30, fontWeight: 700, color: INK}}>{clean(u.title)}</div>
                {u.detail ? <div style={{fontSize: 21, color: SOFT, marginTop: 8, lineHeight: 1.3}}>{clean(u.detail)}</div> : null}
              </Glass>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// A hub: the main idea in the middle, the parts around it, joined by glowing spokes.
const Hub: React.FC<P> = ({sc, accent, accent2, w, h}) => {
  const t = useT();
  const n = Math.max(1, sc.units.length);
  const cx = w / 2, cy = (h - 200) / 2 + 10;
  const rx = Math.min(w / 2 - 190, 560), ry = Math.min((h - 200) / 2 - 60, 300);
  const act = activeIndex(sc, t);
  const core = useSpring(0.1, 12, 120);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} size={60} />
      <div style={{flex: 1, position: 'relative'}}>
        <svg width={w} height={h - 200} style={{position: 'absolute', inset: 0, overflow: 'visible'}}>
          {sc.units.map((_, i) => {
            const a = -Math.PI / 2 + (2 * Math.PI * i) / n;
            const p = ramp(t, appearAt(sc, i) - 0.3, appearAt(sc, i) + 0.3);
            return <line key={i} x1={cx} y1={cy} x2={cx + Math.cos(a) * rx * p} y2={cy + Math.sin(a) * ry * p}
              stroke={act === i ? accent2 : hexA(accent, 0.7)} strokeWidth={act === i ? 6 : 3}
              style={{filter: act === i ? `drop-shadow(0 0 10px ${accent2})` : undefined}} />;
          })}
        </svg>
        <div style={{position: 'absolute', left: cx - 120, top: cy - 120, width: 240, height: 240, borderRadius: 120,
          background: `radial-gradient(circle at 35% 30%, ${accent2}, ${accent})`, transform: `scale(${core})`,
          boxShadow: `0 0 90px ${hexA(accent, 0.85)}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
          textAlign: 'center', padding: 26, fontSize: 30, fontWeight: 800, color: '#fff', lineHeight: 1.1}}>
          {clean(sc.label) || clean(sc.heading).split(' ').slice(0, 3).join(' ')}
        </div>
        {sc.units.map((u, i) => {
          const a = -Math.PI / 2 + (2 * Math.PI * i) / n;
          const s = useSpring(appearAt(sc, i), 13, 130);
          return (
            <div key={i} style={{position: 'absolute', left: cx + Math.cos(a) * rx - 170, top: cy + Math.sin(a) * ry - 52, width: 340,
              opacity: Math.min(1, s * 1.5), transform: `scale(${0.6 + 0.4 * s})`}}>
              <Glass on={act === i} accent={accent} style={{padding: '18px 22px', display: 'flex', gap: 16, alignItems: 'center'}}>
                <Icon svg={u.icon} label={String(i + 1)} size={54} accent={accent} accent2={accent2} on={act === i} />
                <div style={{fontSize: 27, fontWeight: 700, color: INK, lineHeight: 1.15}}>{clean(u.title)}</div>
              </Glass>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Side by side: columns with their points; "VS" between two.
const Compare: React.FC<P> = ({sc, accent, accent2}) => {
  const t = useT();
  const vs = useSpring(0.6, 10, 160);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} />
      <div style={{flex: 1, display: 'flex', gap: 60, position: 'relative'}}>
        {sc.units.map((u, i) => <Card key={i} u={u} i={i} sc={sc} accent={i % 2 ? accent2 : accent} accent2={i % 2 ? accent : accent2} n={sc.units.length} />)}
        {sc.units.length === 2 ? (
          <div style={{position: 'absolute', left: '50%', top: '42%', width: 96, height: 96, marginLeft: -48, borderRadius: 48,
            background: '#fff', color: '#0b1220', fontWeight: 900, fontSize: 32, display: 'flex', alignItems: 'center', justifyContent: 'center',
            transform: `scale(${vs}) rotate(${(1 - vs) * -90}deg)`, boxShadow: `0 0 50px ${hexA(accent2, 0.8)}`, opacity: t > 0.3 ? 1 : 0}}>VS</div>
        ) : null}
      </div>
    </div>
  );
};

// Numbers that count up when the voice says them.
const number = (v?: string) => {
  const m = (v || '').match(/^([^\d-]*)(-?[\d.,]+)(.*)$/);
  if (!m) return null;
  const n = parseFloat(m[2].replace(/,/g, ''));
  return Number.isFinite(n) ? {pre: m[1], n, post: m[3], dec: (m[2].split('.')[1] || '').length} : null;
};

const Stats: React.FC<P> = ({sc, accent, accent2}) => {
  const t = useT();
  const act = activeIndex(sc, t);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} />
      <div style={{flex: 1, display: 'flex', gap: 30}}>
        {sc.units.map((u, i) => {
          const at = appearAt(sc, i);
          const s = useSpring(at, 14, 120);
          const num = number(u.value);
          const k = ramp(t, at, at + 1.2);
          const shown = num ? `${num.pre}${(num.n * k).toFixed(num.dec)}${num.post}` : (u.value || clean(u.title));
          return (
            <div key={i} style={{flex: 1, opacity: Math.min(1, s * 1.4), transform: `translateY(${(1 - s) * 60}px)`}}>
              <Glass on={act === i} accent={accent} style={{height: '100%', padding: '46px 40px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
                <div style={{fontSize: 104, fontWeight: 800, lineHeight: 1, background: `linear-gradient(120deg, #fff, ${accent2})`,
                  WebkitBackgroundClip: 'text', color: 'transparent', letterSpacing: '-0.03em'}}>{shown}</div>
                <div style={{fontSize: 34, fontWeight: 700, color: INK, marginTop: 22}}>{u.value ? clean(u.title) : ''}</div>
                {u.detail ? <div style={{fontSize: 26, color: SOFT, marginTop: 10, lineHeight: 1.35}}>{clean(u.detail)}</div> : null}
              </Glass>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Bar chart: bars grow in turn, the highlighted one glows in the second colour.
const Chart: React.FC<P> = ({sc, accent, accent2}) => {
  const t = useT();
  const c = sc.chart!;
  const max = Math.max(...c.values, 1);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} size={66} />
      <Glass accent={accent} style={{flex: 1, padding: '40px 50px 30px', display: 'flex', flexDirection: 'column'}}>
        <div style={{flex: 1, position: 'relative', display: 'flex', alignItems: 'flex-end', gap: 46, borderBottom: '2px solid rgba(255,255,255,.25)'}}>
          {[0.25, 0.5, 0.75, 1].map((g) => <div key={g} style={{position: 'absolute', left: 0, right: 0, bottom: `${g * 82}%`,
            borderTop: '1px dashed rgba(255,255,255,.10)'}} />)}
          {c.values.map((v, i) => {
            const at = sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.4 + i * 0.4;
            const g = useSpring(at, 16, 90);
            const hi = c.highlight === i + 1;
            const k = ramp(t, at, at + 1);
            return (
              <div key={i} style={{flex: 1, height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', alignItems: 'center'}}>
                <div style={{fontSize: 40, fontWeight: 800, color: hi ? accent2 : INK, marginBottom: 12, opacity: k}}>
                  {Number.isInteger(v) ? Math.round(v * k) : (v * k).toFixed(1)}{c.unit ? <span style={{fontSize: 24, color: SOFT}}> {c.unit}</span> : null}</div>
                <div style={{width: '64%', height: `${(v / max) * 82 * Math.min(1, g)}%`, borderRadius: '18px 18px 4px 4px',
                  background: hi ? `linear-gradient(180deg, ${accent2}, ${hexA(accent2, 0.55)})` : `linear-gradient(180deg, ${accent}, ${hexA(accent, 0.45)})`,
                  boxShadow: hi ? `0 0 60px ${hexA(accent2, 0.7)}` : `0 0 30px ${hexA(accent, 0.35)}`}} />
              </div>
            );
          })}
        </div>
        <div style={{display: 'flex', gap: 46, paddingTop: 16}}>
          {c.labels.map((l, i) => <div key={i} style={{flex: 1, textAlign: 'center', fontSize: 26, color: SOFT}}>{clean(l)}</div>)}
        </div>
      </Glass>
      {c.takeaway ? (
        <div style={{marginTop: 26, fontSize: 32, fontWeight: 700, color: INK, opacity: ramp(t, appearAt(sc, c.values.length - 1) + 0.8, appearAt(sc, c.values.length - 1) + 1.4),
          display: 'flex', alignItems: 'center', gap: 14}}><span style={{color: accent2}}>▲</span>{clean(c.takeaway)}</div>
      ) : null}
    </div>
  );
};

// Quiz: the options; on the answer the right one turns green with a burst, the others fade.
const Quiz: React.FC<P> = ({sc, accent, accent2}) => {
  const t = useT();
  const answer = sc.kind === 'answer' ? sc.correct || 0 : 0;
  const reveal = ramp(t, 0.5, 1.0);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} size={62} />
      <div style={{display: 'flex', flexDirection: 'column', gap: 22}}>
        {sc.units.map((u, i) => {
          const s = useSpring(appearAt(sc, i), 14, 130);
          const right = answer === i + 1;
          const good = '#34d399';
          return (
            <div key={i} style={{opacity: Math.min(1, s * 1.4) * (answer && !right ? 1 - 0.55 * reveal : 1), transform: `translateX(${(1 - s) * -60}px) scale(${right ? 1 + 0.03 * reveal : 1})`}}>
              <Glass on={right && reveal > 0.5} accent={right ? good : accent} style={{padding: '24px 30px', display: 'flex', alignItems: 'center', gap: 26}}>
                <div style={{width: 64, height: 64, borderRadius: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30, fontWeight: 800,
                  color: '#fff', background: right && reveal > 0.5 ? good : `linear-gradient(135deg, ${accent}, ${accent2})`}}>
                  {right && reveal > 0.5 ? '✓' : String.fromCharCode(65 + i)}</div>
                <div style={{fontSize: 36, fontWeight: 600, color: INK}}>{clean(u.title)}</div>
              </Glass>
            </div>
          );
        })}
      </div>
      {answer ? <Burst at={0.7} color={'#34d399'} color2={accent2} /> : null}
    </div>
  );
};

// A short confetti-like burst of light particles (same every render: no randomness).
const Burst: React.FC<{at: number; color: string; color2: string}> = ({at, color, color2}) => {
  const t = useT();
  const p = interpolate(t, [at, at + 1.6], [0, 1], clamp);
  if (p <= 0 || p >= 1) return null;
  return (
    <div style={{position: 'absolute', left: '45%', top: '55%'}}>
      {Array.from({length: 26}).map((_, i) => {
        const a = (i / 26) * Math.PI * 2 + (i % 3) * 0.3;
        const d = 220 + (i % 5) * 70;
        return <div key={i} style={{position: 'absolute', width: 14, height: 14, borderRadius: i % 2 ? 7 : 3,
          background: i % 2 ? color : color2, opacity: 1 - p,
          transform: `translate(${Math.cos(a) * d * p}px, ${Math.sin(a) * d * p + 260 * p * p}px) rotate(${p * 540}deg)`}} />;
      })}
    </div>
  );
};

// One big idea (concept, example, callout): a large card, then any parts below it.
const Focus: React.FC<P> = ({sc, accent, accent2}) => {
  const t = useT();
  const [first, ...rest] = sc.units;
  const s = useSpring(appearAt(sc, 0), 13, 110);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} />
      {first ? (
        <div style={{opacity: Math.min(1, s * 1.4), transform: `translateY(${(1 - s) * 60}px) scale(${0.94 + 0.06 * s})`}}>
          <Glass on={isOn(sc.active[0], t)} accent={accent} sweepAt={appearAt(sc, 0) + 0.2}
            style={{padding: '48px 56px', display: 'flex', gap: 44, alignItems: 'center',
              borderLeft: `8px solid ${accent2}`}}>
            <Icon svg={first.icon} label={sc.kind === 'callout' ? '!' : '★'} size={130} accent={accent} accent2={accent2} />
            <div>
              <div style={{fontSize: 48, fontWeight: 800, color: INK, lineHeight: 1.12}}>{clean(first.title)}</div>
              {first.detail ? <div style={{fontSize: 31, color: SOFT, marginTop: 16, lineHeight: 1.4}}>{clean(first.detail)}</div> : null}
            </div>
          </Glass>
        </div>
      ) : null}
      {rest.length ? (
        <div style={{display: 'flex', gap: 26, marginTop: 30, flex: 1, minHeight: 0}}>
          {rest.map((u, i) => <Card key={i} u={u} i={i + 1} sc={sc} accent={accent} accent2={accent2} compact n={rest.length} />)}
        </div>
      ) : null}
    </div>
  );
};

// A table as rows that slide in.
const Table: React.FC<P> = ({sc, accent, accent2}) => {
  const t = useT();
  const act = activeIndex(sc, t);
  return (
    <div style={{display: 'flex', flexDirection: 'column', height: '100%'}}>
      <Head sc={sc} accent={accent} accent2={accent2} size={62} />
      <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>
        {sc.units.map((u, i) => {
          const s = useSpring(appearAt(sc, i), 15, 130);
          return (
            <div key={i} style={{opacity: Math.min(1, s * 1.4), transform: `translateX(${(1 - s) * 80}px)`}}>
              <Glass on={act === i} accent={accent} style={{padding: '22px 30px', display: 'flex', gap: 30, alignItems: 'center'}}>
                <div style={{width: 300, fontSize: 30, fontWeight: 700, color: INK}}>{clean(u.title)}</div>
                <div style={{flex: 1, fontSize: 26, color: SOFT, lineHeight: 1.35}}>{clean(u.detail)}</div>
              </Glass>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// The opening (or a section) card: a big title, the goals as chips, a light streak.
const Title: React.FC<P> = ({sc, accent, accent2}) => {
  const t = useT();
  const streak = interpolate(t, [0.2, 1.6], [-30, 130], clamp);
  return (
    <div style={{height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', position: 'relative'}}>
      <div style={{position: 'absolute', top: '18%', left: `${streak}%`, width: 520, height: 3, transform: 'rotate(-8deg)',
        background: `linear-gradient(90deg, transparent, ${accent2}, #fff, transparent)`, filter: 'blur(1px)', opacity: 0.85}} />
      <div style={{fontSize: 26, color: accent2, fontWeight: 700, letterSpacing: '.3em', textTransform: 'uppercase', marginBottom: 30,
        opacity: ramp(t, 0, 0.5)}}>{clean(sc.label) || 'Video lesson'}</div>
      <Kinetic text={clean(sc.heading)} at={0.15} size={118} gap={0.08} style={{maxWidth: '92%'}} />
      <div style={{height: 9, width: 260 * ramp(t, 0.6, 1.3), marginTop: 40, borderRadius: 5,
        background: `linear-gradient(90deg, ${accent}, ${accent2})`, boxShadow: `0 0 30px ${hexA(accent2, 0.9)}`}} />
      {sc.units.length ? (
        <div style={{display: 'flex', gap: 22, marginTop: 56, flexWrap: 'wrap'}}>
          {sc.units.map((u, i) => {
            const s = useSpring(appearAt(sc, i), 14, 140);
            return <div key={i} style={{fontSize: 30, color: INK, padding: '16px 30px', borderRadius: 999, opacity: Math.min(1, s * 1.4),
              transform: `translateY(${(1 - s) * 30}px)`, background: 'rgba(255,255,255,.08)', border: '1px solid rgba(255,255,255,.18)',
              display: 'flex', alignItems: 'center', gap: 14}}><span style={{color: accent2}}>✦</span>{clean(u.title)}</div>;
          })}
        </div>
      ) : null}
      {sc.subheading ? <div style={{fontSize: 34, color: FAINT, marginTop: 30}}>{clean(sc.subheading)}</div> : null}
    </div>
  );
};

export const SceneBody: React.FC<P> = (p) => {
  const k = p.sc.kind;
  if (k === 'title') return <Title {...p} />;
  if (p.sc.chart && p.sc.chart.values?.length) return <Chart {...p} />;
  if ((k === 'steps' || k === 'timeline') && p.sc.units.length >= 2 && p.sc.units.length <= 6) return <Flow {...p} />;
  if (k === 'cycle' && p.sc.units.length >= 3 && p.sc.units.length <= 6) return <Cycle {...p} />;
  if (k === 'hub' && p.sc.units.length >= 2 && p.sc.units.length <= 6) return <Hub {...p} />;
  if (k === 'comparison') return <Compare {...p} />;
  if ((k === 'stats' || k === 'calculation') && p.sc.units.length <= 4) return <Stats {...p} />;
  if (k === 'question' || k === 'answer') return <Quiz {...p} />;
  if (k === 'concept' || k === 'example' || k === 'callout') return <Focus {...p} />;
  if (k === 'table') return <Table {...p} />;
  return <Cards {...p} />;
};

// Shared look of the Pro lessons: colours, fonts, timing helpers and the glass card.
import React, {createContext, useContext} from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import '@fontsource/inter/800.css';

export const FONT = 'Inter, "Segoe UI", Arial, sans-serif';
export const INK = '#f4f7fb';
export const SOFT = 'rgba(226,234,245,.74)';
export const FAINT = 'rgba(226,234,245,.42)';
export const NIGHT = '#070d1a';

export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Time inside a scene (seconds from the scene's start; negative while it is still coming in).
export const LeadContext = createContext(0);
export const useT = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lead = useContext(LeadContext);
  return frame / fps - lead;
};

// A spring that starts at `at` seconds of the scene (0 before, ~1 after).
export const useSpring = (at: number, damping = 15, stiffness = 110) => {
  const t = useT();
  const {fps} = useVideoConfig();
  return spring({frame: Math.round((t - at) * fps), fps, config: {damping, stiffness, mass: 0.9}});
};

// 0 -> 1 between two times, eased.
export const ramp = (t: number, a: number, b: number) =>
  interpolate(t, [a, b], [0, 1], {...clamp, easing: (x) => 1 - Math.pow(1 - x, 3)});

export const isOn = (w: number[] | null | undefined, t: number) => !!w && t >= w[0] && t <= w[1];

export const hexA = (hex: string, alpha: number) => {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
};

// Glass card: frosted, with a light edge; `on` = the voice is talking about it right now.
export const Glass: React.FC<{on?: boolean; dim?: boolean; accent: string; style?: React.CSSProperties;
  children: React.ReactNode; sweepAt?: number}> = ({on, dim, accent, style, children, sweepAt}) => {
  const t = useT();
  const sweep = sweepAt === undefined ? -1 : interpolate(t, [sweepAt, sweepAt + 1.1], [-0.6, 1.6], clamp);
  return (
    <div style={{position: 'relative', overflow: 'hidden', borderRadius: 30,
      background: on ? `linear-gradient(150deg, ${hexA(accent, 0.30)}, rgba(255,255,255,.06))`
        : 'linear-gradient(150deg, rgba(255,255,255,.11), rgba(255,255,255,.035))',
      border: `1.5px solid ${on ? hexA(accent, 0.95) : 'rgba(255,255,255,.14)'}`,
      boxShadow: on ? `0 0 0 6px ${hexA(accent, 0.16)}, 0 34px 90px ${hexA(accent, 0.42)}`
        : '0 30px 80px rgba(0,0,0,.38), inset 0 1px 0 rgba(255,255,255,.12)',
      opacity: dim ? 0.5 : 1, ...style}}>
      {sweep > -0.6 && sweep < 1.6 ? (
        <div style={{position: 'absolute', top: 0, bottom: 0, width: '45%', left: `${sweep * 100}%`,
          background: 'linear-gradient(100deg, transparent, rgba(255,255,255,.22), transparent)',
          transform: 'skewX(-18deg)', pointerEvents: 'none'}} />
      ) : null}
      {children}
    </div>
  );
};

// The icon of an element (an SVG drawn with currentColor) in a glowing gradient tile.
export const Icon: React.FC<{svg?: string; label?: string; size: number; accent: string; accent2: string; on?: boolean}> =
  ({svg, label, size, accent, accent2, on}) => (
  <div style={{width: size, height: size, borderRadius: size * 0.3, flexShrink: 0,
    background: `linear-gradient(135deg, ${accent}, ${accent2})`, color: '#fff', display: 'flex',
    alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: size * 0.42,
    boxShadow: `0 ${size * 0.18}px ${size * 0.5}px ${hexA(accent, on ? 0.7 : 0.38)}`}}>
    {svg ? <span style={{width: size * 0.5, height: size * 0.5, display: 'inline-flex'}} dangerouslySetInnerHTML={{__html: svg}} />
      : label}
  </div>
);

// Words that rise one after another, sharpening as they arrive.
export const Kinetic: React.FC<{text: string; at: number; size: number; weight?: number; color?: string;
  gap?: number; style?: React.CSSProperties}> = ({text, at, size, weight = 800, color = INK, gap = 0.055, style}) => {
  const t = useT();
  const words = text.split(/\s+/).filter(Boolean);
  return (
    <div style={{fontSize: size, fontWeight: weight, color, lineHeight: 1.08, letterSpacing: '-0.02em', ...style}}>
      {words.map((w, i) => {
        const p = ramp(t, at + i * gap, at + i * gap + 0.55);
        return (
          <span key={i} style={{display: 'inline-block', marginRight: '0.26em', opacity: p,
            transform: `translateY(${(1 - p) * size * 0.45}px)`, filter: `blur(${(1 - p) * 10}px)`}}>{w}</span>
        );
      })}
    </div>
  );
};

export const clean = (s?: string) => (s || '').replace(/\*\*/g, '');

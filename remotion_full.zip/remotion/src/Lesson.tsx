// The lesson as a Remotion video: the same scenes, audio and timing as the built-in engine
// (props written by remotion_render.py), drawn with React and Remotion's spring animations.
import React, {useLayoutEffect, useMemo} from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {AI_SCENES} from './ai';

export type Unit = {title: string; detail?: string; value?: string; icon?: string; items?: string[]};
export type Scene = {kind: string; start_s: number; duration_s: number; heading: string; subheading?: string;
  label?: string; units: Unit[]; appear: number[]; active: (number[] | null)[]; correct?: number;
  chart?: {labels: string[]; values: number[]; unit?: string; highlight?: number; takeaway?: string};
  talk?: [number, number, string][]; mouth?: Record<string, number[]>};
export type Stage = {style: string; back: string; front: string; screen: [number, number, number, number];
  tags: boolean; toon_js: string};
export type LessonProps = {fps: number; width: number; height: number; total_s: number; audio: string;
  title: string; accent: string; accent2: string; scenes: Scene[]; stage?: Stage | null};

const INK = '#0f1b2d', MUTED = '#5b6b7f', BG = '#f6f8fb';

const useEnter = (at_s: number) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - Math.round(at_s * fps), fps, config: {damping: 14, stiffness: 120, mass: 0.8}});
};

const isActive = (w: number[] | null, t: number) => !!w && t >= w[0] && t <= w[1];

const Card: React.FC<{u: Unit; i: number; at: number; on: boolean; anyOn: boolean; accent: string; n: number}> =
  ({u, i, at, on, anyOn, accent, n}) => {
  const s = useEnter(at);
  const lift = on ? 1.04 : 1;
  return (
    <div style={{flex: 1, minWidth: 0, background: '#fff', borderRadius: 24, padding: '36px 34px',
      boxShadow: on ? `0 24px 60px ${accent}44` : '0 10px 30px rgba(15,27,45,.08)',
      border: on ? `3px solid ${accent}` : '3px solid transparent',
      opacity: s * (anyOn && !on ? 0.55 : 1), transform: `translateY(${(1 - s) * 60}px) scale(${(0.9 + 0.1 * s) * lift})`}}>
      <div style={{width: 76, height: 76, borderRadius: 20, background: on ? accent : `${accent}1f`, color: on ? '#fff' : accent,
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 34, fontWeight: 700, marginBottom: 22}}>
        {u.icon ? <span style={{width: 40, height: 40, display: 'inline-flex'}} dangerouslySetInnerHTML={{__html: u.icon}} /> : i + 1}
      </div>
      {u.value ? <div style={{fontSize: 52, fontWeight: 800, color: accent, marginBottom: 8}}>{u.value}</div> : null}
      <div style={{fontSize: n > 3 ? 34 : 40, fontWeight: 700, color: INK, lineHeight: 1.15}}>{u.title}</div>
      {u.detail ? <div style={{fontSize: 28, color: MUTED, marginTop: 12, lineHeight: 1.35}}>{u.detail.replace(/\*\*/g, '')}</div> : null}
      {u.items ? <ul style={{fontSize: 28, color: MUTED, marginTop: 12, paddingLeft: 28}}>{u.items.map((x, k) => <li key={k}>{x}</li>)}</ul> : null}
    </div>
  );
};

const Chart: React.FC<{sc: Scene; accent: string; accent2: string}> = ({sc, accent, accent2}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const c = sc.chart!;
  const max = Math.max(...c.values, 1);
  return (
    <>
    <div style={{display: 'flex', alignItems: 'flex-end', gap: 40, flex: 1, minHeight: 0, padding: '0 40px', borderBottom: `4px solid #cbd5e1`}}>
      {c.values.map((v, i) => {
        const at = sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.3;
        const g = spring({frame: frame - Math.round(at * fps), fps, config: {damping: 18}});
        const hi = c.highlight === i + 1;
        return (
          <div key={i} style={{flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', height: '100%'}}>
            <div style={{fontSize: 34, fontWeight: 700, color: INK, opacity: g}}>{v}{c.unit ? ` ${c.unit}` : ''}</div>
            <div style={{width: '70%', height: `${(v / max) * 82 * g}%`, background: hi ? accent2 : accent, borderRadius: '14px 14px 0 0'}} />

          </div>
        );
      })}
    </div>
    <div style={{display: 'flex', gap: 40, padding: '14px 40px 0'}}>
      {c.labels.map((l, i) => <div key={i} style={{flex: 1, textAlign: 'center', fontSize: 26, color: MUTED}}>{l}</div>)}
    </div>
    </>
  );
};

const SceneView: React.FC<{sc: Scene; accent: string; accent2: string; title: string; page: string}> = ({sc, accent, accent2, title, page}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const head = useEnter(0.05);
  const fade = interpolate(t, [0, 0.35, sc.duration_s - 0.35, sc.duration_s], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const anyOn = sc.active.some((w) => isActive(w, t));
  if (sc.kind === 'title') {
    return (
      <AbsoluteFill style={{background: `linear-gradient(135deg, ${accent}, ${INK})`, color: '#fff', padding: 140, justifyContent: 'center', opacity: fade}}>
        {sc.label ? <div style={{fontSize: 30, letterSpacing: 4, opacity: 0.8, marginBottom: 24}}>{sc.label}</div> : null}
        <div style={{fontSize: 96, fontWeight: 800, lineHeight: 1.05, transform: `translateY(${(1 - head) * 60}px)`, opacity: head}}>{sc.heading}</div>
        <div style={{display: 'flex', gap: 24, marginTop: 56}}>
          {sc.units.map((u, i) => {
            const s = spring({frame: frame - Math.round((sc.appear[i] ?? 0.6) * fps), fps, config: {damping: 15}});
            return <div key={i} style={{fontSize: 34, padding: '16px 28px', borderRadius: 999, background: 'rgba(255,255,255,.14)', opacity: s,
              transform: `translateY(${(1 - s) * 30}px)`}}>{u.title}</div>;
          })}
        </div>
      </AbsoluteFill>
    );
  }
  const options = sc.kind === 'question' || sc.kind === 'answer';
  return (
    <AbsoluteFill style={{background: BG, padding: '110px 120px 90px', opacity: fade, fontFamily: 'inherit'}}>
      <div style={{position: 'absolute', left: 0, top: 0, right: 0, height: 10, background: `linear-gradient(90deg, ${accent}, ${accent2})`}} />
      <div style={{fontSize: 70, fontWeight: 800, color: INK, opacity: head, transform: `translateX(${(1 - head) * -50}px)`}}>{sc.heading}</div>
      {sc.subheading ? <div style={{fontSize: 34, color: MUTED, marginTop: 14, opacity: head}}>{sc.subheading}</div> : null}
      <div style={{position: 'absolute', left: 120, right: 120, top: sc.subheading ? 330 : 280, bottom: 110, display: 'flex', alignItems: 'center'}}>
        {sc.chart ? <div style={{width: '100%', height: '100%', display: 'flex', flexDirection: 'column'}}><Chart sc={sc} accent={accent} accent2={accent2} />
          {sc.chart.takeaway ? <div style={{fontSize: 32, color: INK, marginTop: 18, fontWeight: 600}}>{sc.chart.takeaway}</div> : null}</div>
        : (
          <div style={{display: 'flex', flexDirection: options || sc.units.length > 4 ? 'column' : 'row', gap: 32, width: '100%'}}>
            {sc.units.map((u, i) => (
              <Card key={i} u={sc.kind === 'answer' && sc.correct === i + 1 ? {...u, title: `✓ ${u.title}`} : u} i={i}
                at={sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.3}
                on={isActive(sc.active[i] ?? null, t) || (sc.kind === 'answer' && sc.correct === i + 1)} anyOn={anyOn}
                accent={accent} n={sc.units.length} />
            ))}
          </div>
        )}
      </div>
      <div style={{position: 'absolute', left: 120, right: 120, bottom: 40, display: 'flex', justifyContent: 'space-between', fontSize: 24, color: MUTED}}>
        <span style={{color: accent, fontWeight: 600}}>{title}</span><span>{page}</span>
      </div>
    </AbsoluteFill>
  );
};

// The presenter / dialogue room: the slide on a screen, the cartoon characters beside it. The
// characters are the same SVG drawings as in the built-in engine and are moved by the same code
// (toon(t) from cartoon.py): mouth from the voice, blinking, nodding, pointing at the screen.
const smooth = (x: number) => { x = Math.min(Math.max(x, 0), 1); return x * x * (3 - 2 * x); };

const StageView: React.FC<{stage: Stage; sc: Scene; children: React.ReactNode; accent: string}> = ({stage, sc, children, accent}) => {
  const frame = useCurrentFrame();
  const {fps, width} = useVideoConfig();
  const t = frame / fps;
  const k = width / 1280;
  const toon = useMemo(() => new Function('S', `${stage.toon_js}; return toon;`)(smooth), [stage.toon_js]);
  useLayoutEffect(() => {
    (window as any).TL = {talk: sc.talk || [], mouth: sc.mouth || {}, active: sc.active, appear: sc.appear};
    toon(t);
  });
  const [x, y, w, h] = stage.screen;
  const inner = (w - 20) * k;
  const talking = (who: string) => (sc.talk || []).some(([a, b, s]) => s === who && t >= a && t <= b);
  const tag = (who: string, label: string, cx: number) => (
    <div style={{position: 'absolute', left: cx * k, bottom: 14 * k, transform: 'translateX(-50%)', padding: `${5 * k}px ${14 * k}px`,
      borderRadius: 999, font: `600 ${15 * k}px/1 Inter, "Segoe UI", sans-serif`, letterSpacing: '.04em', textTransform: 'uppercase',
      background: talking(who) ? accent : '#fff', color: talking(who) ? '#fff' : '#475569', boxShadow: '0 4px 12px rgba(15,27,45,.12)'}}>{label}</div>
  );
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#fdf6ec,#f6ead8)'}}>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 74 * k, background: 'linear-gradient(#e2c9a4,#d6b88f)'}} />
      <svg viewBox="0 0 1280 720" style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} dangerouslySetInnerHTML={{__html: stage.back}} />
      <div style={{position: 'absolute', left: x * k, top: y * k, width: w * k, height: h * k, borderRadius: 18 * k, background: '#1f2937',
        padding: 10 * k, boxShadow: '0 30px 60px rgba(15,27,45,.22)'}}>
        <div style={{width: inner, height: (h - 20) * k, overflow: 'hidden', borderRadius: 10 * k, position: 'relative'}}>
          <div style={{width: 1920, height: 1080, transform: `scale(${inner / 1920})`, transformOrigin: '0 0', position: 'absolute', left: 0, top: 0}}>
            {children}
          </div>
        </div>
      </div>
      <svg viewBox="0 0 1280 720" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible'}}
        dangerouslySetInnerHTML={{__html: stage.front}} />
      {stage.tags ? <>{tag('expert', 'Expert', 128)}{tag('host', 'Host', 1152)}</> : null}
    </AbsoluteFill>
  );
};

// A scene written by Claude (react_scenes.py) that fails while drawing falls back to the template.
class Fallback extends React.Component<{fallback: React.ReactNode; children: React.ReactNode}, {failed: boolean}> {
  state = {failed: false};
  static getDerivedStateFromError() { return {failed: true}; }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}

export const Lesson: React.FC<LessonProps> = ({scenes, audio, accent, accent2, title, fps, stage}) => (
  <AbsoluteFill style={{background: BG, fontFamily: '"Segoe UI", Inter, Arial, sans-serif'}}>
    {audio ? <Audio src={staticFile(audio)} /> : null}
    {scenes.map((sc, i) => {
      const template = <SceneView sc={sc} accent={accent} accent2={accent2} title={title} page={`${i + 1} / ${scenes.length}`} />;
      const AI = AI_SCENES[i];
      const view = AI ? <Fallback fallback={template}><AbsoluteFill style={{background: BG}}><AI sc={sc} accent={accent} accent2={accent2} /></AbsoluteFill></Fallback> : template;
      return (
        <Sequence key={i} from={Math.round(sc.start_s * fps)} durationInFrames={Math.max(1, Math.round(sc.duration_s * fps))}>
          {stage ? <StageView stage={stage} sc={sc} accent={accent}>{view}</StageView> : view}
        </Sequence>
      );
    })}
  </AbsoluteFill>
);

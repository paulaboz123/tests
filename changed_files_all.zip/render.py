"""
render.py - draws the pictures of a video lesson (1280x720 by default): one per scene, or, for
animated scenes, one per step of the animation (animation.py decides the steps and the timing).

Scene types (the model picks one per scene in the storyboard):
  title       lesson or chapter title, goal or learning objectives
  bullets     a heading and 2-5 short key points
  steps       a process: numbered boxes connected by arrows
  cycle       a repeating process: boxes around a ring (e.g. the Sprint)
  timeline    phases or events in time order on a line
  hub         a central term with the parts around it (e.g. a team and its roles)
  comparison  2-3 cards side by side (options, before/after, pros/cons)
  table       a small grid with a header row
  concept     a key term with its definition and an optional example
  example     a worked example (situation, what to do, result)
  question / answer   a check-yourself question, then the same with the right answer marked
  slide       an original slide (only with ORIGINAL_SLIDES=yes)

Animation states: each element (key point, box, column, row ...) can be drawn
  "normal"  as usual
  "active"  highlighted: the one the voice talks about now (tinted, bold, accent edge)
  "muted"   pushed back (grey), while another one is active
  None      not shown yet (it appears when the voice gets to it)
The layout is always computed for all elements, so nothing moves when an element appears.

Try it on an existing storyboard:  uv run render.py data/output/<folder>/storyboard.json
"""
from __future__ import annotations

import json
import math
import sys
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

import config

BG = (248, 249, 251)
INK = (31, 41, 51)
MUTED = (100, 116, 139)
FAINT = (168, 178, 192)          # muted elements while another one is active
ACCENT = (13, 110, 123)
ACCENT_DARK = (8, 82, 92)
ACCENT_LIGHT = (225, 241, 241)
BOX = (255, 255, 255)
BORDER = (203, 213, 225)
LIGHT_BORDER = (226, 232, 240)
WHITE = (255, 255, 255)

FONTS = {
    False: ["C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/arial.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf"],
    True: ["C:/Windows/Fonts/segoeuib.ttf", "C:/Windows/Fonts/arialbd.ttf",
           "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
           "/System/Library/Fonts/Supplemental/Arial Bold.ttf"],
}


@lru_cache(maxsize=256)
def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    """TrueType font of this size (Segoe UI on Windows, DejaVu on Linux); cached."""
    for path in FONTS[bold]:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default(size=size)


def wrap(draw: ImageDraw.ImageDraw, text: str, fnt, max_w: float) -> list[str]:
    """Greedy word wrap; a single word wider than the line is split."""
    lines: list[str] = []
    cur = ""
    for word in text.split():
        while draw.textlength(word, font=fnt) > max_w and len(word) > 1:   # very long word
            cut = len(word)
            while cut > 1 and draw.textlength(word[:cut] + "-", font=fnt) > max_w:
                cut -= 1
            if cur:
                lines.append(cur)
                cur = ""
            lines.append(word[:cut] + "-")
            word = word[cut:]
        test = f"{cur} {word}".strip()
        if draw.textlength(test, font=fnt) <= max_w:
            cur = test
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines or [""]


def fit(draw, texts: list[str], max_w: float, max_h: float, sizes: range, bold: bool = False,
        gap: float = 0.0):
    """Largest font size at which all texts, wrapped to max_w, fit in max_h.
    Returns (font, wrapped texts, line height); falls back to the smallest size."""
    for size in sizes:
        fnt = font(size, bold)
        line_h = int(size * 1.28)
        wrapped = [wrap(draw, t, fnt, max_w) for t in texts]
        total = sum(len(w) for w in wrapped) * line_h + gap * size * max(len(texts) - 1, 0)
        if total <= max_h:
            return fnt, wrapped, line_h
    return fnt, wrapped, line_h


def fit_each(draw, texts: list[str], max_w: float, max_h: float, sizes: range, bold: bool = False):
    """Like fit(), but for texts in separate boxes: the largest size at which EACH text,
    wrapped to max_w, fits in max_h (one size for all, so the boxes look alike)."""
    for size in sizes:
        fnt = font(size, bold)
        line_h = int(size * 1.25)
        wrapped = [wrap(draw, t, fnt, max_w) for t in texts]
        if max(len(w) for w in wrapped) * line_h <= max_h and all(
                draw.textlength(line, font=fnt) <= max_w for w in wrapped for line in w):
            return fnt, wrapped, line_h
    return fnt, wrapped, line_h


class Canvas:
    def __init__(self) -> None:
        """Empty frame of VIDEO_WIDTH x VIDEO_HEIGHT. Sizes in this file are designed for
        1280 px wide and scaled with px()."""
        self.w, self.h = config.VIDEO_WIDTH, config.VIDEO_HEIGHT
        self.s = self.w / 1280
        self.img = Image.new("RGB", (self.w, self.h), BG)
        self.d = ImageDraw.Draw(self.img)
        self.m = int(80 * self.s)   # side margin

    def px(self, v: float) -> int:
        """Design size (for a 1280 px wide frame) -> pixels at the real width."""
        return int(v * self.s)

    def sizes(self, hi: int, lo: int) -> range:
        """Font sizes to try, largest first, scaled to the real width."""
        return range(self.px(hi), max(self.px(lo), 10) - 1, -1)

    def text_lines(self, lines: list[str], x: float, y: float, fnt, line_h: int, fill=INK,
                   center_w: float | None = None) -> float:
        """Draw lines of text from (x, y), centred in center_w if given. Returns the y below them."""
        for line in lines:
            lx = x + (center_w - self.d.textlength(line, font=fnt)) / 2 if center_w else x
            self.d.text((lx, y), line, font=fnt, fill=fill)
            y += line_h
        return y

    def chrome(self, footer: str, page: str, section: str = "") -> None:
        """Accent bar at the top, the section (chapter) name, the lesson title and the page
        number at the bottom, and a thin progress bar showing how far into the video we are."""
        self.d.rectangle([0, 0, self.w, self.px(8)], fill=ACCENT)
        fnt = font(self.px(17))
        y = self.h - self.px(40)
        if section:   # in a course: the chapter instead of the course title
            sf = font(self.px(17), True)
            self.d.text((self.m, y), section[:90], font=sf, fill=ACCENT)
        else:
            self.d.text((self.m, y), footer[:90], font=fnt, fill=MUTED)
        self.d.text((self.w - self.m - self.d.textlength(page, font=fnt), y), page, font=fnt, fill=MUTED)
        try:
            done, total = (int(x) for x in page.split("/"))
            bar_y = self.h - self.px(6)
            self.d.rectangle([0, bar_y, self.w, self.h], fill=LIGHT_BORDER)
            self.d.rectangle([0, bar_y, int(self.w * done / max(total, 1)), self.h], fill=ACCENT)
        except ValueError:
            pass

    def heading(self, text: str) -> int:
        """Scene heading at the top left with an accent underline. Returns the y below it."""
        fnt, (lines,), line_h = fit(self.d, [text], self.w - 2 * self.m, self.px(110), self.sizes(46, 28), True)
        y = self.text_lines(lines, self.m, self.px(56), fnt, line_h)
        self.d.rectangle([self.m, y + self.px(10), self.m + self.px(80), y + self.px(16)], fill=ACCENT)
        return int(y + self.px(50))


# --- Animation states ------------------------------------------------------------------------
def styles_for(n: int, styles: list | None) -> list:
    """The state of each of n elements; None = every element drawn normally (no animation)."""
    if styles is None:
        return ["normal"] * n
    return (list(styles) + ["normal"] * n)[:n]


def text_colour(style: str | None):
    return FAINT if style == "muted" else INK


def draw_title(c: Canvas, heading: str, goal: str, objectives: list[str] | None = None,
               label: str = "VIDEO LESSON") -> None:
    """Title scene: small label, lesson title, accent line, goal, and the learning objectives
    ("You will be able to") when there are any."""
    objectives = objectives or []
    width = c.w - 2 * c.px(140)
    label_f = font(c.px(20), True)
    t_font, (t_lines,), t_lh = fit(c.d, [heading], width, c.px(200 if objectives else 230), c.sizes(64, 32), True)
    g_font, (g_lines,), g_lh = fit(c.d, [goal], width, c.px(90 if objectives else 130), c.sizes(28, 18)) \
        if goal and not objectives else (None, ([],), 0)
    o_font, o_wrapped, o_lh = fit(c.d, objectives, width - c.px(40), c.px(170), c.sizes(26, 16), gap=0.4) \
        if objectives else (None, [], 0)
    o_h = (c.px(46) + sum(len(w) for w in o_wrapped) * o_lh + 0.4 * o_font.size * (len(objectives) - 1)) \
        if objectives else 0
    block = c.px(40) + len(t_lines) * t_lh + c.px(40) + len(g_lines) * g_lh + o_h
    y = (c.h - block) / 2 - c.px(10)
    x = c.px(140)
    c.d.text((x, y), label, font=label_f, fill=ACCENT)
    y = c.text_lines(t_lines, x, y + c.px(40), t_font, t_lh)
    c.d.rectangle([x, y + c.px(14), x + c.px(120), y + c.px(20)], fill=ACCENT)
    y += c.px(40)
    if g_lines:
        y = c.text_lines(g_lines, x, y, g_font, g_lh, fill=MUTED)
    if objectives:
        c.d.text((x, y), "YOU WILL BE ABLE TO", font=font(c.px(18), True), fill=MUTED)
        y += c.px(36)
        for lines in o_wrapped:
            _check(c, x + c.px(4), y + o_lh / 2)
            y = c.text_lines(lines, x + c.px(40), y, o_font, o_lh) + 0.4 * o_font.size


def _check(c: Canvas, x: float, cy: float, color=None) -> None:
    """A small tick mark at (x, cy)."""
    w = max(c.px(4), 2)
    s = c.px(9)
    c.d.line([(x, cy), (x + s * 0.8, cy + s * 0.8), (x + s * 2.2, cy - s * 0.9)], fill=color or ACCENT, width=w)


def draw_bullets(c: Canvas, heading: str, items: list[str], styles: list | None = None) -> None:
    """Heading plus key points with accent dots. The active point sits on a tinted band with an
    accent edge and bold text. A heading alone is shown large in the middle."""
    if not items:   # heading only: show it large in the middle
        fnt, (lines,), lh = fit(c.d, [heading], c.w - 2 * c.px(140), c.px(300), c.sizes(56, 30), True)
        c.text_lines(lines, c.px(140), (c.h - len(lines) * lh) / 2, fnt, lh, center_w=c.w - 2 * c.px(140))
        return
    st = styles_for(len(items), styles)
    top = c.heading(heading)
    indent = c.px(48)
    avail_h = c.h - top - c.px(90)
    # layout with the bold font, so a point never re-wraps when it becomes active
    bold, wrapped, lh = fit(c.d, items, c.w - 2 * c.m - indent - c.px(24), avail_h, c.sizes(36, 18), True, gap=0.8)
    regular = font(bold.size)
    total = sum(len(w) for w in wrapped) * lh + 0.8 * bold.size * (len(items) - 1)
    y = top + max(0, (avail_h - total) / 3)   # a bit above centre looks balanced
    r = max(c.px(7), 4)
    for lines, s in zip(wrapped, st, strict=True):
        block_h = len(lines) * lh
        if s is not None:
            if s == "active":
                pad = c.px(10)
                c.d.rounded_rectangle([c.m - pad, y - pad * 0.6, c.w - c.m + pad, y + block_h + pad * 0.6],
                                      radius=c.px(10), fill=ACCENT_LIGHT)
                c.d.rectangle([c.m - pad, y - pad * 0.6 + c.px(6), c.m - pad + c.px(5), y + block_h + pad * 0.6 - c.px(6)],
                              fill=ACCENT)
            cy = y + lh / 2
            dot = BORDER if s == "muted" else ACCENT
            rr = r * 1.25 if s == "active" else r
            c.d.ellipse([c.m + c.px(12) - rr, cy - rr, c.m + c.px(12) + rr, cy + rr], fill=dot)
            c.text_lines(lines, c.m + indent, y, bold if s == "active" else regular, lh, fill=text_colour(s))
        y += block_h + 0.8 * bold.size


def _arrow(c: Canvas, x1: float, y1: float, x2: float, y2: float, colour=ACCENT) -> None:
    """Arrow from (x1, y1) to (x2, y2), horizontal (pointing right) or vertical (pointing down)."""
    c.d.line([x1, y1, x2, y2], fill=colour, width=max(c.px(4), 2))
    head = c.px(12)
    if abs(x2 - x1) >= abs(y2 - y1):   # horizontal, pointing right
        c.d.polygon([(x2, y2), (x2 - head, y2 - head * 0.7), (x2 - head, y2 + head * 0.7)], fill=colour)
    else:                              # vertical, pointing down
        c.d.polygon([(x2, y2), (x2 - head * 0.7, y2 - head), (x2 + head * 0.7, y2 - head)], fill=colour)


def _number(c: Canvas, cx: float, cy: float, n: int | str, colour=ACCENT, r: float | None = None) -> None:
    """Filled circle with a number, centred at (cx, cy)."""
    r = r or c.px(22)
    c.d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=colour)
    f = font(int(r), True)
    t = str(n)
    box = c.d.textbbox((0, 0), t, font=f)
    c.d.text((cx - (box[2] - box[0]) / 2 - box[0], cy - (box[3] - box[1]) / 2 - box[1]), t, font=f, fill=WHITE)


def _card(c: Canvas, box: list[float], style: str | None, radius: int | None = None, top_bar: bool = True) -> None:
    """A white card with a border; tinted with a thick accent edge when active, faint when muted."""
    radius = radius or c.px(14)
    if style == "active":
        c.d.rounded_rectangle(box, radius=radius, fill=ACCENT_LIGHT, outline=ACCENT, width=max(c.px(3), 2))
    else:
        c.d.rounded_rectangle(box, radius=radius, fill=BOX,
                              outline=LIGHT_BORDER if style == "muted" else BORDER, width=max(c.px(2), 1))
        if top_bar and style != "muted":
            c.d.rectangle([box[0] + c.px(14), box[1], box[2] - c.px(14), box[1] + c.px(5)], fill=ACCENT)


def draw_steps(c: Canvas, heading: str, items: list[str], styles: list | None = None) -> None:
    """Process diagram: numbered boxes with arrows from left to right, or from top to bottom
    when there are many steps or long texts. A box appears with the arrow leading to it."""
    if len(items) < 2:
        return draw_bullets(c, heading, items, styles)
    st = styles_for(len(items), styles)
    top = c.heading(heading)
    avail_h = c.h - top - c.px(90)
    n = len(items)
    gap = c.px(56)
    box_w = (c.w - 2 * c.m - (n - 1) * gap) / n
    pad = c.px(16)
    if n <= 5 and box_w >= c.px(170):   # horizontal flow
        text_h = avail_h - c.px(90)
        bold, wrapped, lh = fit_each(c.d, items, box_w - 2 * pad, min(text_h, c.px(240)), c.sizes(30, 16), True)
        if max(len(w) for w in wrapped) * lh <= min(text_h, c.px(240)):
            regular = font(bold.size)
            box_h = max(c.px(190), c.px(80) + max(len(w) for w in wrapped) * lh + pad)
            y0 = top + (avail_h - box_h) / 2
            for i, (lines, s) in enumerate(zip(wrapped, st, strict=True)):
                if s is None:
                    continue
                x0 = c.m + i * (box_w + gap)
                _card(c, [x0, y0, x0 + box_w, y0 + box_h], s)
                _number(c, x0 + box_w / 2, y0 + c.px(46), i + 1, FAINT if s == "muted" else ACCENT)
                ty = y0 + c.px(80) + (box_h - c.px(80) - pad - len(lines) * lh) / 2
                c.text_lines(lines, x0 + pad, ty, bold if s == "active" else regular, lh, fill=text_colour(s),
                             center_w=box_w - 2 * pad)
                if i > 0:   # the arrow into this box
                    xa = x0 - gap
                    _arrow(c, xa + c.px(8), y0 + box_h / 2, x0 - c.px(8), y0 + box_h / 2,
                           LIGHT_BORDER if s == "muted" else ACCENT)
            return
    # vertical flow: numbered rows with arrows between them
    row_gap = c.px(26)
    bold, wrapped, lh = fit(c.d, items, c.w - 2 * c.m - c.px(110), avail_h - (n - 1) * row_gap - n * c.px(16),
                            c.sizes(30, 16), True)
    regular = font(bold.size)
    y = top
    for i, (lines, s) in enumerate(zip(wrapped, st, strict=True)):
        row_h = max(len(lines) * lh, c.px(44)) + c.px(16)
        if s is not None:
            if s == "active":
                c.d.rounded_rectangle([c.m - c.px(8), y, c.w - c.m, y + row_h], radius=c.px(10), fill=ACCENT_LIGHT)
            _number(c, c.m + c.px(24), y + row_h / 2, i + 1, FAINT if s == "muted" else ACCENT)
            c.text_lines(lines, c.m + c.px(70), y + (row_h - len(lines) * lh) / 2,
                         bold if s == "active" else regular, lh, fill=text_colour(s))
        y += row_h
        if i < n - 1:
            nxt = st[i + 1]
            if nxt is not None:
                _arrow(c, c.m + c.px(24), y + c.px(2), c.m + c.px(24), y + row_gap - c.px(2),
                       LIGHT_BORDER if nxt == "muted" else ACCENT)
            y += row_gap


def _ring_arrow(c: Canvas, cx: float, cy: float, rx: float, ry: float, angle: float, colour) -> None:
    """A small arrowhead on the ring (an ellipse) at `angle` (radians), pointing clockwise."""
    size = c.px(13)
    x, y = cx + rx * math.cos(angle), cy + ry * math.sin(angle)
    tx, ty = -rx * math.sin(angle), ry * math.cos(angle)      # clockwise tangent of the ellipse
    norm = math.hypot(tx, ty) or 1
    tx, ty = tx / norm, ty / norm
    nx, ny = ty, -tx
    tip = (x + tx * size, y + ty * size)
    c.d.polygon([tip, (x - tx * size * 0.4 + nx * size * 0.8, y - ty * size * 0.4 + ny * size * 0.8),
                 (x - tx * size * 0.4 - nx * size * 0.8, y - ty * size * 0.4 - ny * size * 0.8)], fill=colour)


def draw_cycle(c: Canvas, heading: str, items: list[str], styles: list | None = None) -> None:
    """A repeating process: 3-6 boxes on a ring, clockwise from the top, with arrows on the ring."""
    if len(items) < 3:
        return draw_steps(c, heading, items, styles)
    st = styles_for(len(items), styles)
    top = c.heading(heading)
    n = len(items)
    avail_h = c.h - top - c.px(80)
    cx, cy = c.w / 2, top + avail_h / 2
    box_w, box_h = c.px(280 if n <= 4 else 240), c.px(112)
    ry = avail_h / 2 - box_h / 2 - c.px(4)
    rx = min(c.w / 2 - c.m - box_w / 2, ry * 1.9)
    pad = c.px(12)
    bold, wrapped, lh = fit_each(c.d, items, box_w - 2 * pad - c.px(16), box_h - 2 * pad, c.sizes(28, 14), True)
    regular = font(bold.size)
    angles = [-math.pi / 2 + 2 * math.pi * i / n for i in range(n)]
    # the ring (an ellipse through the box centres) with direction chevrons between boxes
    c.d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], outline=ACCENT_LIGHT, width=max(c.px(10), 4))
    for i, a in enumerate(angles):
        if st[i] is not None and st[(i + 1) % n] is not None:
            _ring_arrow(c, cx, cy, rx, ry, a + math.pi / n, ACCENT if st[(i + 1) % n] != "muted" else BORDER)
    for i, (lines, s, a) in enumerate(zip(wrapped, st, angles, strict=True)):
        if s is None:
            continue
        bx, by = cx + rx * math.cos(a) - box_w / 2, cy + ry * math.sin(a) - box_h / 2
        _card(c, [bx, by, bx + box_w, by + box_h], s, top_bar=False)
        _number(c, bx + c.px(2), by + c.px(2), i + 1, FAINT if s == "muted" else ACCENT, r=c.px(16))
        ty = by + (box_h - len(lines) * lh) / 2
        c.text_lines(lines, bx + pad, ty, bold if s == "active" else regular, lh, fill=text_colour(s),
                     center_w=box_w - 2 * pad)


def draw_timeline(c: Canvas, heading: str, items: list[str], styles: list | None = None) -> None:
    """Phases or events in order on a horizontal line; labels alternate above and below the
    line when there are many, so they have room."""
    if len(items) < 2:
        return draw_bullets(c, heading, items, styles)
    st = styles_for(len(items), styles)
    top = c.heading(heading)
    n = len(items)
    avail_h = c.h - top - c.px(80)
    line_y = top + avail_h / 2
    alternate = n >= 5
    # labels are centred under their marker: keep the first and last label inside the margins
    col_w = min((c.w - 2 * c.m) / (n - 1) * (1.8 if alternate else 0.95), c.px(300))
    x0, x1 = c.m + col_w / 2, c.w - c.m - col_w / 2
    step = (x1 - x0) / (n - 1)
    col_w = min(col_w, step * (1.8 if alternate else 0.95))
    text_h = avail_h / 2 - c.px(50)
    bold, wrapped, lh = fit_each(c.d, items, col_w, min(text_h, c.px(130)), c.sizes(26, 14), True)
    regular = font(bold.size)
    shown_x = [x0 + i * step for i, s in enumerate(st) if s is not None]
    c.d.line([x0, line_y, x1, line_y], fill=LIGHT_BORDER, width=max(c.px(6), 3))
    if shown_x:
        c.d.line([x0, line_y, max(shown_x), line_y], fill=ACCENT, width=max(c.px(6), 3))
    for i, (lines, s) in enumerate(zip(wrapped, st, strict=True)):
        if s is None:
            continue
        x = x0 + i * step
        r = c.px(20 if s == "active" else 16)
        colour = FAINT if s == "muted" else ACCENT
        if s == "active":
            c.d.ellipse([x - r - c.px(7), line_y - r - c.px(7), x + r + c.px(7), line_y + r + c.px(7)], fill=ACCENT_LIGHT)
        _number(c, x, line_y, i + 1, colour, r=r)
        above = alternate and i % 2 == 1
        block = len(lines) * lh
        ty = line_y - c.px(40) - block if above else line_y + c.px(40)
        c.text_lines(lines, x - col_w / 2, ty, bold if s == "active" else regular, lh, fill=text_colour(s),
                     center_w=col_w)


def draw_hub(c: Canvas, heading: str, center: str, items: list[str], styles: list | None = None) -> None:
    """A central term in a circle with its parts in cards around it, joined by lines."""
    if len(items) < 2:
        return draw_bullets(c, heading, items, styles)
    st = styles_for(len(items), styles)
    top = c.heading(heading)
    n = len(items)
    avail_h = c.h - top - c.px(80)
    cx, cy = c.w / 2, top + avail_h / 2
    box_w, box_h = c.px(300), c.px(112)
    rx, ry = c.w / 2 - c.m - box_w / 2, avail_h / 2 - box_h / 2
    angles = [-math.pi / 2 + 2 * math.pi * i / n for i in range(n)] if n != 2 else [math.pi, 0.0]
    if n == 4:
        angles = [math.radians(a) for a in (-145, -35, 35, 145)]
    pad = c.px(12)
    bold, wrapped, lh = fit_each(c.d, items, box_w - 2 * pad, box_h - 2 * pad, c.sizes(28, 14), True)
    regular = font(bold.size)
    centres = [(cx + rx * math.cos(a), cy + ry * math.sin(a)) for a in angles]
    for (bx, by), s in zip(centres, st, strict=True):   # connectors first, under everything
        if s is not None:
            c.d.line([cx, cy, bx, by], fill=ACCENT if s == "active" else BORDER if s == "normal" else LIGHT_BORDER,
                     width=max(c.px(4 if s == "active" else 3), 2))
    r = c.px(86)
    c.d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=ACCENT)
    cf, (clines,), clh = fit(c.d, [center or heading], 2 * r - c.px(24), 2 * r - c.px(30), c.sizes(28, 14), True)
    c.text_lines(clines, cx - r, cy - len(clines) * clh / 2, cf, clh, fill=WHITE, center_w=2 * r)
    for (bx, by), lines, s in zip(centres, wrapped, st, strict=True):
        if s is None:
            continue
        box = [bx - box_w / 2, by - box_h / 2, bx + box_w / 2, by + box_h / 2]
        _card(c, box, s, top_bar=False)
        c.text_lines(lines, box[0] + pad, by - len(lines) * lh / 2, bold if s == "active" else regular, lh,
                     fill=text_colour(s), center_w=box_w - 2 * pad)


def mask_area(im: Image.Image, spec: str) -> Image.Image:
    """Paint over part of a slide (e.g. the presenter's camera picture) with the slide's own
    background colour, taken from just outside that area."""
    import numpy as np

    import media
    left, t, r, b = media.parse_crop(spec)
    w, h = im.size
    box = [int(left * w), int(t * h), int(r * w), int(b * h)]
    arr = np.asarray(im)
    band = max(4, w // 100)
    samples = [arr[max(box[1] - band, 0):box[1], box[0]:box[2]].reshape(-1, 3),     # above
               arr[box[1]:box[3], max(box[0] - band, 0):box[0]].reshape(-1, 3)]     # left
    samples = [s for s in samples if len(s)]
    colour = tuple(int(v) for v in np.median(np.concatenate(samples), axis=0)) if samples else (255, 255, 255)
    im = im.copy()
    ImageDraw.Draw(im).rectangle(box, fill=colour)
    return im


def draw_comparison(c: Canvas, heading: str, columns: list[dict], styles: list | None = None) -> None:
    """Two or three cards side by side, each with a heading and short points; a column can
    appear or be highlighted as a whole."""
    st = styles_for(len(columns), styles)
    top = c.heading(heading)
    n = len(columns)
    gap = c.px(24)
    col_w = (c.w - 2 * c.m - (n - 1) * gap) / n
    pad = c.px(20)
    avail_h = c.h - top - c.px(96)
    head_font, head_lines, head_lh = fit(c.d, [col["heading"] for col in columns], col_w - 2 * pad,
                                         c.px(70) * n, c.sizes(24, 16), True)
    all_items = [x for col in columns for x in col["items"]]
    item_font, _, item_lh = fit(c.d, all_items, col_w - 2 * pad - c.px(22), avail_h * n,
                                c.sizes(24, 14), gap=0.6)
    wrapped = [[wrap(c.d, x, item_font, col_w - 2 * pad - c.px(22)) for x in col["items"]] for col in columns]
    head_h = max(len(h) for h in head_lines) * head_lh
    body_h = max(sum(len(w) for w in col) * item_lh + 0.6 * item_font.size * (len(col) - 1) for col in wrapped)
    card_h = min(avail_h, pad + head_h + c.px(18) + body_h + pad)
    y0 = top + max(0, (avail_h - card_h) / 3)
    r = max(c.px(5), 3)
    for i, s in enumerate(st):
        if s is None:
            continue
        x0 = c.m + i * (col_w + gap)
        _card(c, [x0, y0, x0 + col_w, y0 + card_h], s)
        y = c.text_lines(head_lines[i], x0 + pad, y0 + pad, head_font, head_lh,
                         fill=ACCENT_DARK if s == "active" else text_colour(s))
        c.d.line([x0 + pad, y + c.px(6), x0 + col_w - pad, y + c.px(6)], fill=BORDER, width=1)
        y += c.px(18)
        for lines in wrapped[i]:
            cy = y + item_lh / 2
            c.d.ellipse([x0 + pad, cy - r, x0 + pad + 2 * r, cy + r], fill=BORDER if s == "muted" else ACCENT)
            y = c.text_lines(lines, x0 + pad + c.px(22), y, item_font, item_lh, fill=text_colour(s)) \
                + 0.6 * item_font.size


def draw_table(c: Canvas, heading: str, header: list[str], rows: list[list[str]], styles: list | None = None) -> None:
    """A small grid: tinted header row, rows with thin rules, text wrapped inside each cell.
    Rows can appear one by one, and the row being talked about is highlighted."""
    st = styles_for(len(rows), styles)
    top = c.heading(heading)
    n = len(header)
    width = c.w - 2 * c.m
    # columns as wide as their longest text needs (each at least 15% of the table)
    need = [max(len(header[j]), *(len(r[j]) for r in rows)) for j in range(n)]
    share = [max(x / sum(need), 0.15) for x in need]
    widths = [width * x / sum(share) for x in share]
    lefts = [c.m + sum(widths[:j]) for j in range(n)]
    pad = c.px(14)
    avail_h = c.h - top - c.px(96)
    for size in c.sizes(24, 13):
        body, bold = font(size), font(size, True)
        lh = int(size * 1.28)
        head_wrapped = [wrap(c.d, h, bold, widths[j] - 2 * pad) for j, h in enumerate(header)]
        row_wrapped = [[wrap(c.d, cell, bold, widths[j] - 2 * pad) for j, cell in enumerate(r)] for r in rows]
        head_h = max(len(w) for w in head_wrapped) * lh + 2 * pad
        row_hs = [max(len(w) for w in r) * lh + 2 * pad for r in row_wrapped]
        if head_h + sum(row_hs) <= avail_h:
            break
    y = top + max(0, (avail_h - head_h - sum(row_hs)) / 3)
    c.d.rounded_rectangle([c.m, y, c.m + width, y + head_h], radius=c.px(8), fill=ACCENT_LIGHT)
    for j, lines in enumerate(head_wrapped):
        c.text_lines(lines, lefts[j] + pad, y + pad, bold, lh)
    y += head_h
    for r, h, s in zip(row_wrapped, row_hs, st, strict=True):
        if s is not None:
            if s == "active":
                c.d.rectangle([c.m, y + 1, c.m + width, y + h - 1], fill=ACCENT_LIGHT)
                c.d.rectangle([c.m, y + 1, c.m + c.px(5), y + h - 1], fill=ACCENT)
            for j, lines in enumerate(r):
                c.text_lines(lines, lefts[j] + pad, y + pad, bold if s == "active" or j == 0 else body, lh,
                             fill=text_colour(s))
            c.d.line([c.m, y + h, c.m + width, y + h], fill=BORDER, width=1)
        y += h


def draw_concept(c: Canvas, term: str, items: list[str], styles: list | None = None) -> None:
    """A key term, large, with its definition and an optional example underneath; the
    definition and the example can appear one after the other."""
    st = styles_for(len(items[:2]), styles)
    width = c.w - 2 * c.px(140)
    x = c.px(140)
    label_f = font(c.px(20), True)
    t_font, (t_lines,), t_lh = fit(c.d, [term], width, c.px(150), c.sizes(56, 30), True)
    d_font, (d_lines,), d_lh = fit(c.d, [items[0]], width, c.px(170), c.sizes(32, 18))
    example = items[1] if len(items) > 1 else ""
    e_font, (e_lines,), e_lh = (fit(c.d, [example], width - c.px(48), c.px(110), c.sizes(22, 14))
                                if example else (None, ([],), 0))
    block = c.px(40) + len(t_lines) * t_lh + c.px(44) + len(d_lines) * d_lh + \
        (c.px(40) + len(e_lines) * e_lh + c.px(32) if example else 0)
    y = (c.h - block) / 2 - c.px(10)
    c.d.text((x, y), "KEY TERM", font=label_f, fill=ACCENT)
    y = c.text_lines(t_lines, x, y + c.px(40), t_font, t_lh)
    c.d.rectangle([x, y + c.px(14), x + c.px(120), y + c.px(20)], fill=ACCENT)
    y += c.px(44)
    if st[0] is not None:
        c.text_lines(d_lines, x, y, d_font, d_lh, fill=text_colour(st[0]))
    y += len(d_lines) * d_lh
    if example and st[1] is not None:
        box_h = len(e_lines) * e_lh + c.px(32)
        y += c.px(28)
        c.d.rounded_rectangle([x, y, x + width, y + box_h], radius=c.px(10),
                              fill=ACCENT_LIGHT if st[1] != "muted" else LIGHT_BORDER)
        c.text_lines(e_lines, x + c.px(24), y + c.px(16), e_font, e_lh, fill=text_colour(st[1]))


def draw_example(c: Canvas, heading: str, items: list[str], styles: list | None = None) -> None:
    """Worked example: label, heading, and a tinted card with the lines of the example
    (e.g. situation -> what to do -> result); the lines can appear one by one."""
    st = styles_for(len(items), styles)
    width = c.w - 2 * c.m
    c.d.text((c.m, c.px(40)), "EXAMPLE", font=font(c.px(20), True), fill=ACCENT)
    fnt_h, (h_lines,), h_lh = fit(c.d, [heading], width, c.px(100), c.sizes(42, 26), True)
    y = c.text_lines(h_lines, c.m, c.px(74), fnt_h, h_lh) + c.px(26)
    pad = c.px(30)
    avail_h = c.h - y - c.px(100)
    bold, wrapped, lh = fit(c.d, items, width - 2 * pad - c.px(30), avail_h - 2 * pad, c.sizes(30, 16), True, gap=0.9)
    regular = font(bold.size)
    body_h = sum(len(w) for w in wrapped) * lh + 0.9 * bold.size * (len(items) - 1)
    y += max(0, (avail_h - body_h - 2 * pad) / 3)   # a bit above centre looks balanced
    c.d.rounded_rectangle([c.m, y, c.m + width, y + body_h + 2 * pad], radius=c.px(16), fill=ACCENT_LIGHT)
    c.d.rectangle([c.m, y + c.px(16), c.m + c.px(8), y + body_h + 2 * pad - c.px(16)], fill=ACCENT)
    y += pad
    for lines, s in zip(wrapped, st, strict=True):
        if s is not None:
            cy = y + lh / 2
            colour = FAINT if s == "muted" else ACCENT
            c.d.polygon([(c.m + pad, cy - c.px(8)), (c.m + pad + c.px(12), cy), (c.m + pad, cy + c.px(8))], fill=colour)
            c.text_lines(lines, c.m + pad + c.px(30), y, bold if s == "active" else regular, lh, fill=text_colour(s))
        y += len(lines) * lh + 0.9 * bold.size


def draw_question(c: Canvas, question: str, options: list[str], correct: int = 0) -> None:
    """Check-yourself question with options A, B, C. With `correct` (1-based) the right option is
    highlighted and the others dimmed - the answer scene that follows the question."""
    width = c.w - 2 * c.m
    label = "ANSWER" if correct else "CHECK YOURSELF"
    c.d.text((c.m, c.px(40)), label, font=font(c.px(20), True), fill=ACCENT)
    q_font, (q_lines,), q_lh = fit(c.d, [question], width, c.px(150), c.sizes(40, 24), True)
    y = c.text_lines(q_lines, c.m, c.px(74), q_font, q_lh) + c.px(30)
    gap = c.px(16)
    avail_h = c.h - y - c.px(96) - gap * (len(options) - 1)
    pad = c.px(20)
    letter_w = c.px(56)
    o_font, wrapped, o_lh = fit(c.d, options, width - letter_w - 3 * pad, avail_h - 2 * pad * len(options),
                                c.sizes(30, 16))
    heights = [max(len(lines) * o_lh, c.px(44)) + 2 * pad for lines in wrapped]
    y += max(0, (avail_h + gap * (len(options) - 1) - sum(heights) - gap * (len(options) - 1)) / 3)
    for n, (lines, box_h) in enumerate(zip(wrapped, heights, strict=True), 1):
        right, dim = correct == n, bool(correct) and correct != n
        fill = ACCENT if right else BOX
        c.d.rounded_rectangle([c.m, y, c.m + width, y + box_h], radius=c.px(12), fill=fill,
                              outline=ACCENT if right else BORDER, width=max(c.px(2), 1))
        cx, cy = c.m + pad + letter_w / 2, y + box_h / 2
        r = c.px(22)
        c.d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 255, 255) if right else ACCENT_LIGHT)
        lf = font(c.px(22), True)
        letter = chr(64 + n)
        c.d.text((cx - c.d.textlength(letter, font=lf) / 2, cy - c.px(14)), letter, font=lf, fill=ACCENT)
        ink = (255, 255, 255) if right else MUTED if dim else INK
        ty = y + (box_h - len(lines) * o_lh) / 2
        c.text_lines(lines, c.m + letter_w + 2 * pad, ty, o_font, o_lh, fill=ink)
        if right:
            _check(c, c.m + width - c.px(56), cy, color=(255, 255, 255))
        y += box_h + gap


def draw_slide(c: Canvas, image: Path, caption: str) -> None:
    """Original slide, as large as fits, with a soft shadow and its source underneath."""
    top, bottom = c.px(36), c.h - c.px(80)
    max_w, max_h = c.w - c.m, bottom - top
    with Image.open(image) as im:
        im = im.convert("RGB")
        if config.SLIDE_MASK:
            im = mask_area(im, config.SLIDE_MASK)
        scale = min(max_w / im.width, max_h / im.height)
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.LANCZOS)
    x, y = (c.w - im.width) // 2, top + (max_h - im.height) // 2
    sh = c.px(6)
    c.d.rectangle([x + sh, y + sh, x + im.width + sh, y + im.height + sh], fill=(226, 232, 240))
    c.img.paste(im, (x, y))
    c.d.rectangle([x, y, x + im.width, y + im.height], outline=BORDER, width=max(c.px(1), 1))
    if caption:
        f = font(c.px(17))
        c.d.text((x, y + im.height + c.px(10)), caption[:120], font=f, fill=MUTED)


ANIMATED = {"bullets", "cards", "stats", "callout", "steps", "cycle", "timeline", "hub", "comparison", "table",
            "concept", "example", "chart", "formula", "calculation"}


def units(scene: dict) -> int:
    """How many elements of a scene can appear or be highlighted one by one."""
    kind = scene.get("visual")
    if kind == "comparison":
        return len(scene.get("columns", []))
    if kind == "table":
        return len(scene.get("table_rows", []))
    if kind == "chart":
        return len(scene.get("chart", {}).get("labels", []))
    n = len(scene.get("elements") or scene.get("items", []))
    if kind == "concept":
        return min(n, 2)
    return n if kind in ANIMATED else 0


def render_scene(scene: dict, out: Path, *, lesson_title: str, goal: str, page: str,
                 slide_image: Path | None = None, caption: str = "", styles: list | None = None) -> Path:
    """Draw one scene (or one step of its animation, given `styles`) to a PNG."""
    c = Canvas()
    kind = scene.get("visual", "bullets")
    heading, items = scene.get("heading", ""), scene.get("items", [])
    if kind == "chart" and scene.get("chart"):   # the simple slides show the data as a table
        ch = scene["chart"]   # (not `c`: that is the canvas)
        scene = {**scene, "table_header": ["", ch.get("unit") or "value"],
                 "table_rows": [[lab, f"{float(v):g}"] for lab, v in zip(ch["labels"], ch["values"], strict=False)]}
        kind = "table"
    elif kind == "calculation":
        scene = {**scene, "table_header": ["Step", "Calculation", "Result"],
                 "table_rows": [[e.get("title", ""), e.get("expression", ""), e.get("value", "")]
                                for e in scene.get("elements", [])]}
        kind = "table"
    elif kind in ("cards", "stats", "callout", "formula"):   # the designer layouts need the browser
        formula = kind == "formula"
        kind = "bullets"
        items = ([scene["formula"]] if formula and scene.get("formula") else []) + \
            [" ".join(x for x in (e.get("value", ""), e.get("title", ""), e.get("detail", "") if scene.get("visual") == "formula" else "") if x)
             for e in scene.get("elements", [])] or items
    if kind == "title":
        draw_title(c, heading or lesson_title, scene.get("subtitle", goal), items, scene.get("label") or "VIDEO LESSON")
    elif kind == "slide" and slide_image and slide_image.exists():
        draw_slide(c, slide_image, caption)
    elif kind == "steps":
        draw_steps(c, heading, items, styles)
    elif kind == "cycle":
        draw_cycle(c, heading, items, styles)
    elif kind == "timeline":
        draw_timeline(c, heading, items, styles)
    elif kind == "hub":
        draw_hub(c, heading, scene.get("center", ""), items, styles)
    elif kind == "comparison" and len(scene.get("columns", [])) >= 2:
        draw_comparison(c, heading, scene["columns"], styles)
    elif kind == "table" and scene.get("table_header") and scene.get("table_rows"):
        draw_table(c, heading, scene["table_header"], scene["table_rows"], styles)
    elif kind == "concept" and heading and items:
        draw_concept(c, heading, items, styles)
    elif kind == "example" and items:
        draw_example(c, heading, items, styles)
    elif kind in ("question", "answer") and len(items) >= 2:
        draw_question(c, heading, items, scene.get("correct", 0) if kind == "answer" else 0)
    else:
        draw_bullets(c, heading, items, styles)
    if kind != "title":   # slide scenes already have a caption at the bottom
        section = scene.get("section", "")
        section = "" if section in ("Introduction", "Summary") else section
        c.chrome("" if kind == "slide" and slide_image else lesson_title, page, section)
    out.parent.mkdir(parents=True, exist_ok=True)
    c.img.save(out, compress_level=1)
    return out


if __name__ == "__main__":
    # Re-draw the scenes of a storyboard.json (after editing it by hand) to check the look.
    sb_path = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    if not sb_path or not sb_path.exists():
        print("Usage: uv run render.py data/output/<folder>/storyboard.json")
        sys.exit(1)
    sb = json.loads(sb_path.read_text(encoding="utf-8"))
    for i, sc in enumerate(sb["scenes"], 1):
        img = Path(sc["slide_image"]) if sc.get("slide_image") else None
        p = render_scene(sc, sb_path.parent / "scenes" / f"scene_{i:02d}.png", lesson_title=sb["title"],
                         goal=sb.get("goal", ""), page=f"{i} / {len(sb['scenes'])}",
                         slide_image=img, caption=sc.get("caption", ""))
        print(p)

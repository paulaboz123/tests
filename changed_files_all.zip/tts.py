"""
tts.py - turns narration text into speech, locally (no audio or text leaves the laptop here).

Engines (TTS_ENGINE in .env):
- kokoro: Kokoro-82M, an open model (Apache 2.0) with natural English voices, run on the CPU
  with onnxruntime. Needs two files in models/ (~120 MB), fetched once from GitHub:
      uv add kokoro-onnx
      uv run tts.py --download
- system: the voice built into Windows (via pyttsx3). Robotic, but needs no download.
      uv add pyttsx3
- elevenlabs: ElevenLabs cloud voices (most natural). ELEVENLABS_API_KEY in .env; the text goes
  to ElevenLabs. Cost: the characters ElevenLabs bills x ELEVENLABS_USD_PER_1K_CHARS, logged like
  model calls. A lesson is spoken in short parts (so the slides can follow the voice); each part is
  sent with what comes before and after it (request stitching), with steady settings and a fixed
  seed, and the silence at its ends is cut: the parts join into one flowing narration.

Kokoro is the default: free and local. The cloud voices are there to compare (benchmark.py).

Usage:
  uv run tts.py --download                   # once
  uv run tts.py "Hello, this is a test."     # writes data/output/tts_test.wav and shows the speed
  uv run tts.py --voices                     # list the Kokoro voices (try a few, set TTS_VOICE)
"""
from __future__ import annotations

import argparse
import importlib.util
import logging
import re
import sys
import tempfile
import time
import wave
from pathlib import Path

import numpy as np

import config

log = logging.getLogger("tts")
# Kokoro's phonemizer warns "words count mismatch" on almost every sentence (it counts words
# before and after splitting punctuation differently). Harmless: the audio is complete.
logging.getLogger("phonemizer").setLevel(logging.ERROR)

KOKORO_RELEASE = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
KOKORO_MODEL = "kokoro-v1.0.int8.onnx"   # 88 MB, fastest on a CPU; quality close to the full model
KOKORO_VOICES = "voices-v1.0.bin"        # 28 MB, all voices
PAUSE_AFTER_S = 0.45                     # silence after each scene, so scenes don't run together


class TTSError(RuntimeError):
    pass


# --- Model files ---------------------------------------------------------------------------
def kokoro_paths() -> tuple[Path, Path]:
    """Where the Kokoro model and voice files are expected (the models/ folder)."""
    return config.MODELS_DIR / KOKORO_MODEL, config.MODELS_DIR / KOKORO_VOICES


def download() -> None:
    """Fetch the Kokoro files from GitHub (honours HTTPS_PROXY and CA_BUNDLE)."""
    import llm  # reuse its HTTP settings (proxy, company certificate)

    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    for path in kokoro_paths():
        if path.exists() and path.stat().st_size > 1_000_000:
            log.info("%s already there", path.name)
            continue
        part = path.with_suffix(path.suffix + ".part")
        log.info("Downloading %s ...", path.name)
        with llm._http().stream("GET", KOKORO_RELEASE + path.name, follow_redirects=True,
                                timeout=600) as r:
            if r.status_code != 200:
                raise TTSError(f"Download failed (HTTP {r.status_code}). If GitHub is blocked, download "
                               f"{KOKORO_RELEASE + path.name} in the browser and put it in {config.MODELS_DIR}")
            with open(part, "wb") as f:
                for chunk in r.iter_bytes(1 << 20):
                    f.write(chunk)
        part.replace(path)
        log.info("Saved %s (%.0f MB)", path, path.stat().st_size / 1e6)


ENGINES = ("kokoro", "system", "elevenlabs")
# ElevenLabs default voices (every account has them): a name in .env or benchmark.py is enough
ELEVEN_VOICES = {
    "alice": "Xb7hH8MSUJpSbSDYk0k2", "bill": "pqHfZKP75CvOlQylNhV4", "brian": "nPczCjzI2devNBz1zQrb",
    "callum": "N2lVS1w4EtoT3dr4eOWO", "charlie": "IKne3meq5aSn9XLyUdCD", "charlotte": "XB0fDUnXU5powFXDhCwa",
    "chris": "iP95p4xoKVk53GoZ742B", "daniel": "onwK4e9ZLuTAKqWW03F9", "eric": "cjVigY5qzO86Huf0OWal",
    "george": "JBFqnCBsd6RMkjVDRZzb", "jessica": "cgSgspJ2msm6clMCkdW9", "laura": "FGY2WhTYpPnrIDTdsKH5",
    "liam": "TX3LPaxmHKxFdv7VOQHJ", "lily": "pFZP5JQG7iQjIQuC4Bku", "matilda": "XrExE9yKIg1WjnnlVkGX",
    "sarah": "EXAVITQu4vr4xnSDxMaL", "will": "bIHbv24MWmeRgasZH58o",
}
ELEVEN_DEFAULTS = {"narrator": "lily", "host": "matilda", "expert": "george"}
# short names for the ElevenLabs models (benchmark.py elevenlabs:lily@flash); full ids work too
ELEVEN_MODELS = {"v2": "eleven_multilingual_v2", "flash": "eleven_flash_v2_5", "turbo": "eleven_turbo_v2_5",
                 "v3": "eleven_v3", "v4": "eleven_v4"}


def eleven_voice_id(name_or_id: str) -> str:
    """lily -> its voice id; an id stays as it is."""
    return ELEVEN_VOICES.get((name_or_id or "").strip().lower(), (name_or_id or "").strip())


def eleven_voice_name(voice_id: str) -> str:
    """A voice id -> its name when it is a default voice (for run cards and reports)."""
    return next((n.capitalize() for n, v in ELEVEN_VOICES.items() if v == voice_id), voice_id)


def eleven_model_id(name: str) -> str:
    return ELEVEN_MODELS.get((name or "").strip().lower(), (name or "").strip())


ROLE_VOICES = {   # engine -> (narrator, host, expert) settings
    "kokoro": ("TTS_VOICE", "HOST_VOICE", "EXPERT_VOICE"),
    "elevenlabs": ("ELEVENLABS_VOICE", "ELEVENLABS_HOST_VOICE", "ELEVENLABS_EXPERT_VOICE"),
}


def role_voice(role: str = "narrator") -> str | None:
    """The voice of the current engine for a role: narrator, host or expert (None = default)."""
    names = ROLE_VOICES.get(config.TTS_ENGINE)
    if not names:
        return None
    value = getattr(config, names[{"narrator": 0, "host": 1, "expert": 2}.get(role, 0)], "")
    if config.TTS_ENGINE == "elevenlabs":
        return eleven_voice_id(value or ELEVEN_DEFAULTS.get(role, "lily"))
    return value or None


def engine_label() -> str:
    """How the voice is made, for the run card."""
    return {"kokoro": "Kokoro (local, free)", "system": "Windows voice (local, free)",
            "elevenlabs": f"ElevenLabs {eleven_model_id(config.ELEVENLABS_MODEL)} (cloud, ${config.ELEVENLABS_USD_PER_1K_CHARS}/1k chars;"
                          f" {'parts joined with context' if config.ELEVENLABS_CONTEXT else 'parts spoken separately'},"
                          f" stability {config.ELEVENLABS_STABILITY})",
            }.get(config.TTS_ENGINE, config.TTS_ENGINE)


def check(engine: str | None = None) -> tuple[bool, str]:
    """Is the configured engine (or `engine`) usable? (for doctor.py, benchmark.py and app.py)"""
    engine = (engine or config.TTS_ENGINE).lower()
    if engine == "elevenlabs":
        if not config.ELEVENLABS_API_KEY:
            return False, "ELEVENLABS_API_KEY not set in .env"
        return True, f"ElevenLabs {config.ELEVENLABS_MODEL}"
    if engine == "kokoro":
        if importlib.util.find_spec("kokoro_onnx") is None:
            return False, "kokoro-onnx not installed (uv add kokoro-onnx)"
        missing = [p.name for p in kokoro_paths() if not p.exists()]
        return (not missing, f"voice {config.TTS_VOICE}" if not missing else f"missing {missing}")
    if engine == "system":
        if importlib.util.find_spec("pyttsx3") is None:
            return False, "pyttsx3 not installed (uv add pyttsx3)"
        return True, "Windows voice"
    return False, f"unknown TTS_ENGINE {engine!r} (use one of {', '.join(ENGINES)})"


# --- Synthesis -------------------------------------------------------------------------------
_kokoro = None


def _get_kokoro():
    """Load Kokoro once and reuse it; checks the files and the configured voice."""
    global _kokoro
    if _kokoro is None:
        try:
            from kokoro_onnx import Kokoro
        except ImportError as e:
            raise TTSError("kokoro-onnx is not installed. Run: uv add kokoro-onnx") from e
        model, voices = kokoro_paths()
        if not model.exists() or not voices.exists():
            raise TTSError(f"Kokoro model files missing in {config.MODELS_DIR}. Run: uv run tts.py --download")
        _kokoro = Kokoro(str(model), str(voices))
        if config.TTS_VOICE not in _kokoro.get_voices():
            raise TTSError(f"Voice {config.TTS_VOICE!r} not found. See: uv run tts.py --voices")
    return _kokoro


def clean_text(text: str) -> str:
    """Narration as it should be shown (subtitles): no markdown, no source labels, single spaces."""
    text = re.sub(r"\[(?:S|P)\d+\]", "", text)
    text = re.sub(r"[*_#`>|]", "", text)
    return " ".join(text.split())


def load_pronunciations() -> dict[str, str]:
    """Terms and how to say them, from pronunciation.csv (columns: term,say_as).
    Example rows:  KPI,K P I    VLOOKUP,V lookup    SAP,S A P    Roche,Rosh"""
    path = config.PRONUNCIATION_FILE
    if not path.exists():
        return {}
    import csv
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if len(r) >= 2 and r[0].strip() and not r[0].startswith("#")]
    return {r[0].strip(): r[1].strip() for r in rows if r[0].strip().lower() != "term"}


def clean_for_speech(text: str) -> str:
    """Narration as it should be spoken: clean_text, common abbreviations written out, and the
    terms from pronunciation.csv replaced by how to say them (whole words, case-sensitive)."""
    text = clean_text(text)
    text = text.replace("&", " and ").replace("e.g.", "for example").replace("i.e.", "that is")
    for term, say_as in sorted(load_pronunciations().items(), key=lambda kv: -len(kv[0])):
        text = re.sub(rf"(?<!\w){re.escape(term)}(?!\w)", say_as, text)
    return " ".join(text.split())


def _write_wav(path: Path, samples: np.ndarray, rate: int) -> None:
    """Save mono float samples (-1..1) as a 16-bit .wav file."""
    pcm = (np.clip(samples, -1.0, 1.0) * 32767).astype(np.int16)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())


def _read_wav(path: Path) -> tuple[np.ndarray, int]:
    """Load a 16-bit .wav as mono float samples (-1..1). Returns (samples, sample rate)."""
    with wave.open(str(path), "rb") as w:
        rate, width, channels = w.getframerate(), w.getsampwidth(), w.getnchannels()
        raw = w.readframes(w.getnframes())
    if width != 2:
        raise TTSError(f"Unexpected sample width {width} in {path.name}")
    data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32767
    if channels > 1:
        data = data.reshape(-1, channels).mean(axis=1)
    return data, rate


def _system_tts(text: str) -> tuple[np.ndarray, int]:
    """Speak with the voice built into Windows (pyttsx3). Returns (samples, sample rate)."""
    try:
        import pyttsx3
    except ImportError as e:
        raise TTSError("pyttsx3 is not installed. Run: uv add pyttsx3") from e
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "speech.wav"
        engine = pyttsx3.init()
        engine.setProperty("rate", int(170 * config.TTS_SPEED))
        engine.save_to_file(text, str(out))
        engine.runAndWait()
        engine.stop()
        if not out.exists():
            raise TTSError("The system voice produced no audio")
        return _read_wav(out)


def synthesize(text: str, voice: str | None = None, context: dict | None = None) -> tuple[np.ndarray, int]:
    """Mono float samples and sample rate for a text (voice: a Kokoro voice, default TTS_VOICE).
    context: {"before": text spoken just before, "after": text spoken next} (ElevenLabs uses it for
    a flowing narration; the local voices don't need it)."""
    text = clean_for_speech(text)
    if not text:
        raise TTSError("Nothing to say: the narration is empty")
    if config.TTS_ENGINE == "kokoro":
        k = _get_kokoro()
        if voice and voice not in k.get_voices():
            raise TTSError(f"Voice {voice!r} not found. See: uv run tts.py --voices")
        samples, rate = k.create(text, voice=voice or config.TTS_VOICE, speed=config.TTS_SPEED,
                                             lang="en-us")
        return np.asarray(samples, dtype=np.float32), rate
    if config.TTS_ENGINE == "system":
        return _system_tts(text)
    if config.TTS_ENGINE == "elevenlabs":   # leaves the laptop: no personal data
        import safety
        found = safety.personal_data_in(text)
        if found:
            raise TTSError(f"Not sent to {config.TTS_ENGINE}: the text contains {' and '.join(found)}")
    if config.TTS_ENGINE == "elevenlabs":
        ctx = context or {}
        voice_id = eleven_voice_id(voice or role_voice("narrator") or "")
        return _priced(text, "elevenlabs", eleven_model_id(config.ELEVENLABS_MODEL), config.ELEVENLABS_USD_PER_1K_CHARS,
                       lambda chunk, before, after: _elevenlabs(chunk, voice_id, before, after),
                       ctx.get("before", ""), ctx.get("after", ""))
    raise TTSError(f"Unknown TTS_ENGINE={config.TTS_ENGINE!r}, use one of {', '.join(ENGINES)}")


# --- Cloud voices ------------------------------------------------------------------------------
def _chunks(text: str, limit: int = 2500) -> list[str]:
    """Split long text at sentence ends (cloud voices take a limited number of characters)."""
    out, cur = [], ""
    for sentence in re.split(r"(?<=[.!?])\s+", text):
        if cur and len(cur) + len(sentence) + 1 > limit:
            out.append(cur)
            cur = ""
        cur = f"{cur} {sentence}".strip()
    return out + ([cur] if cur else [])


def _priced(text: str, provider: str, model: str, usd_per_1k: float, call, before: str = "",
            after: str = "") -> tuple[np.ndarray, int]:
    """Speak with a paid cloud voice: chunk by chunk (each knowing its neighbours), and log the cost
    per character billed (the run card and the spending lock count it like a model call)."""
    import llm
    llm._check_budget()
    if provider == "elevenlabs":   # characters left this month: a clear message instead of an error
        import usage
        try:
            usage.reserve_elevenlabs(len(text))
        except usage.QuotaExceeded as e:
            raise TTSError(str(e)) from None
    t0 = time.perf_counter()
    chunks = _chunks(text)
    parts = [call(c, chunks[i - 1] if i else before, chunks[i + 1] if i + 1 < len(chunks) else after)
             for i, c in enumerate(chunks)]
    rates = {p[1] for p in parts}
    if len(rates) != 1:
        raise TTSError(f"{provider} returned different sample rates {rates}")
    # what the provider says it billed (ElevenLabs: the character-cost header), else the text length
    told = [p[2].get("chars") if len(p) > 2 else None for p in parts]
    billed = sum(told) if all(x is not None for x in told) else len(text)
    llm.log_fixed_cost("voice", f"{provider}/{model}", billed / 1000 * usd_per_1k, time.perf_counter() - t0,
                       backend=provider, characters=billed)
    return np.concatenate([p[0] for p in parts]), rates.pop()


_eleven_voices: list[dict] | None = None


def _elevenlabs_voices() -> list[dict]:
    """The voices of the ElevenLabs account (premade and own)."""
    global _eleven_voices
    if _eleven_voices is None:
        import llm
        r = llm._http().get(f"{config.ELEVENLABS_BASE_URL}/v1/voices", headers={"xi-api-key": config.ELEVENLABS_API_KEY},
                            timeout=30)
        if r.status_code != 200:
            raise TTSError(f"ElevenLabs voices: HTTP {r.status_code} {r.text[:200]}")
        _eleven_voices = r.json().get("voices", [])
    return _eleven_voices


# request ids of the parts just spoken, per voice: the next part continues from them
_stitch: dict[str, list[tuple[str, str, float]]] = {}
STITCH_MAX_AGE_S = 90 * 60   # ElevenLabs keeps them 2 hours
CONTEXT_CHARS = 400          # how much of the neighbouring text is sent along


def eleven_body(text: str, voice_id: str, before: str = "", after: str = "") -> dict:
    """The request for one part: steady settings, a fixed seed and (ELEVENLABS_CONTEXT) what comes
    before and after it. The parts spoken just before in this voice are referred to by their
    request ids (best continuity); otherwise their text is sent. Eleven v3 has no stitching."""
    model = eleven_model_id(config.ELEVENLABS_MODEL)
    settings = {"stability": config.ELEVENLABS_STABILITY, "similarity_boost": config.ELEVENLABS_SIMILARITY,
                "style": config.ELEVENLABS_STYLE, "use_speaker_boost": True}
    if abs(config.TTS_SPEED - 1.0) > 0.01:
        settings["speed"] = min(1.2, max(0.7, config.TTS_SPEED))
    body = {"text": text, "model_id": model, "voice_settings": settings}
    if config.ELEVENLABS_SEED > 0:
        body["seed"] = config.ELEVENLABS_SEED
    if config.ELEVENLABS_CONTEXT and "v3" not in model:
        done = [x for x in _stitch.get(voice_id, []) if time.time() - x[2] < STITCH_MAX_AGE_S]
        if before and done and done[-1][1] == before:   # the part before was just spoken: continue from it
            body["previous_request_ids"] = [x[0] for x in done[-3:]]
        elif before:
            body["previous_text"] = before[-CONTEXT_CHARS:]
        if after:
            body["next_text"] = after[:CONTEXT_CHARS]
    return body


def trim_silence(samples: np.ndarray, rate: int, threshold_db: float = -42.0, keep_s: float = 0.04) -> np.ndarray:
    """Cut the silence at both ends of a part (our own pauses then set the rhythm)."""
    loud = np.flatnonzero(np.abs(samples) > 10 ** (threshold_db / 20))
    if not len(loud):
        return samples
    keep = int(keep_s * rate)
    return samples[max(0, loud[0] - keep): min(len(samples), loud[-1] + keep + int(0.02 * rate))]


def _elevenlabs(text: str, voice_id: str, before: str = "", after: str = "") -> tuple[np.ndarray, int, dict]:
    """One part from ElevenLabs: (samples, rate, {"chars": characters billed or None})."""
    import llm
    url = f"{config.ELEVENLABS_BASE_URL}/v1/text-to-speech/{voice_id}"
    body = eleven_body(text, voice_id, before, after)
    headers = {"xi-api-key": config.ELEVENLABS_API_KEY, "Content-Type": "application/json"}
    r = llm._http().post(url, params={"output_format": "pcm_24000"}, json=body, headers=headers, timeout=120)
    if r.status_code == 200:
        samples, rate = np.frombuffer(r.content, dtype=np.int16).astype(np.float32) / 32767, 24000
    elif r.status_code in (400, 403, 422) and "format" in r.text.lower():   # plan without raw audio: take mp3
        r = llm._http().post(url, params={"output_format": "mp3_44100_128"}, json=body, headers=headers, timeout=120)
        if r.status_code != 200:
            import usage
            raise TTSError(usage.explain_elevenlabs_error(r.status_code, r.text))
        samples, rate = _decode_mp3(r.content)
    else:
        import usage
        raise TTSError(usage.explain_elevenlabs_error(r.status_code, r.text))
    request_id = r.headers.get("request-id")
    if request_id:
        _stitch.setdefault(voice_id, []).append((request_id, text, time.time()))
        del _stitch[voice_id][:-3]
    cost = r.headers.get("character-cost")
    if config.ELEVENLABS_CONTEXT:   # joined parts: our pauses set the rhythm (off = as before, to compare)
        samples = trim_silence(samples, rate)
    return samples, rate, {"chars": int(cost) if cost and cost.isdigit() else None}


def _decode_mp3(data: bytes) -> tuple[np.ndarray, int]:
    """mp3 bytes -> mono float samples at 24 kHz (via ffmpeg)."""
    import subprocess
    with tempfile.TemporaryDirectory() as tmp:
        src, dst = Path(tmp) / "a.mp3", Path(tmp) / "a.wav"
        src.write_bytes(data)
        subprocess.run([config.FFMPEG, "-y", "-loglevel", "error", "-i", str(src), "-ac", "1", "-ar", "24000", str(dst)],
                       check=True)
        return _read_wav(dst)


def speak_to_wav(text: str, out: Path, pause_after_s: float = PAUSE_AFTER_S, voice: str | None = None,
                 context: dict | None = None) -> float:
    """Speak a text into a .wav file (with a short pause at the end). Returns its length in s.
    context: the neighbouring texts (see synthesize)."""
    if context:
        samples, rate = synthesize(text, voice, context=context)
    else:
        samples, rate = synthesize(text, voice) if voice else synthesize(text)
    lead = np.zeros(int(0.15 * rate), dtype=np.float32)
    tail = np.zeros(int(pause_after_s * rate), dtype=np.float32)
    audio = np.concatenate([lead, samples, tail])
    _write_wav(out, audio, rate)
    return len(audio) / rate


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("text", nargs="?", help="text to speak as a test")
    ap.add_argument("--download", action="store_true", help="download the Kokoro model files")
    ap.add_argument("--voices", action="store_true", help="list the voices of the engine")
    ap.add_argument("--engine", choices=ENGINES, help="override TTS_ENGINE for this test")
    args = ap.parse_args()
    config.setup_logging()
    if args.engine:
        config.TTS_ENGINE = args.engine
    try:
        if args.download:
            download()
        if args.voices and config.TTS_ENGINE == "elevenlabs":
            for v in _elevenlabs_voices():
                labels = v.get("labels") or {}
                print(f"  {v['voice_id']}  {v['name']:<20} {labels.get('gender', '')} {labels.get('accent', '')}")
        elif args.voices:
            names = sorted(_get_kokoro().get_voices())
            print("English voices (a = American, b = British; f = female, m = male):")
            print("  " + ", ".join(v for v in names if v[:1] in "ab"))
        if args.text:
            t0 = time.perf_counter()
            out = config.OUTPUT_DIR / f"tts_test_{config.TTS_ENGINE}.wav"
            secs = speak_to_wav(args.text, out)
            took = time.perf_counter() - t0
            log.info("Wrote %s: %.1fs of speech in %.1fs (%s)", out, secs, took, engine_label())
    except Exception as e:   # noqa: BLE001 - show a readable message, not a traceback
        log.error("%s", e)
        return 1
    if not (args.download or args.voices or args.text):
        ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Presenter assets: sources and licences

| File / package | What | Author | Licence | Source |
|---|---|---|---|---|
| `robot.glb` | 3D robot (`PRO_PRESENTER=robot`) | RobotExpressive by Tomás Laulhé (Quaternius), face shapes by Don McCurdy | CC0 1.0 | three.js examples (`examples/models/gltf/RobotExpressive`, r170) |
| `cat.glb` | 3D cat (`cat`) | "Toon Cat FREE" by Omabuarts Studio | **CC BY 4.0: credit the author** | https://sketchfab.com/3d-models/toon-cat-free-b2bd1ee7858444bda366110a2d960386 |
| `woman-suit.glb`, `man-suit.glb` | 3D people (`person-3d`) | Quaternius, Ultimate Animated Character Pack (2019), Suit_Female / Suit_Male | CC0 1.0 | https://opengameart.org/content/animated-characters-pack (web-ready copies: github.com/nrknithin/html-anime) |
| `@dicebear/micah` | 2D person (`person-2d`, `PRO_AVATAR=micah`) | Avatar Illustration System by Micah Lanier | CC BY 4.0: credit the author | https://www.figma.com/community/file/829741575478342595 |
| `@dicebear/avataaars` | 2D person (`avataaars`) | Avataaars by Pablo Stanley | free for personal and commercial use | https://avataaars.com/ |
| `@dicebear/notionists` | 2D person (`notionists`) | Notionists by Zoish | CC0 1.0 | https://heyzoish.gumroad.com/l/notionists |

Credit line for a video that uses the cat or micah (description or end card):
"Toon Cat FREE by Omabuarts Studio (CC BY 4.0)" / "Avatar Illustration System by Micah Lanier (CC BY 4.0)".

The 3D files are drawn by `src/pro/Character3D.tsx` (recoloured there), the 2D people by
`src/pro/Avatar2D.tsx` (DiceBear 9.4.2 packages, installed by `npm install`).

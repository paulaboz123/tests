import React from 'react';
import {Composition} from 'remotion';
import {Lesson, LessonProps} from './Lesson';
import {Pro, ProProps} from './pro/Pro';

const defaults: LessonProps = {fps: 30, width: 1920, height: 1080, total_s: 3, audio: '', title: 'Lesson',
  accent: '#0b6e79', accent2: '#f2a541', scenes: []};

const pro: ProProps = {...defaults, mouth: [], talk: [], cast: [{who: 'presenter', color: '#0b6e79', side: 'right'}],
  character: 'robot', avatar: 'micah'};

const metadata = ({props}: {props: {total_s: number; fps: number; width: number; height: number}}) => ({
  durationInFrames: Math.max(1, Math.round(props.total_s * props.fps)),
  fps: props.fps, width: props.width, height: props.height,
});

export const Root: React.FC = () => (
  <>
    <Composition id="Lesson" component={Lesson} fps={30} width={1920} height={1080} durationInFrames={90}
      defaultProps={defaults} calculateMetadata={metadata} />
    <Composition id="Pro" component={Pro} fps={30} width={1920} height={1080} durationInFrames={90}
      defaultProps={pro} calculateMetadata={metadata} />
  </>
);

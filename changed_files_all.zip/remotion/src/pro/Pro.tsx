// "Remotion Pro" lesson: the same storyboard, voice and timing as the other engines, drawn as a
// motion-design video: a living dark backdrop, glass cards that flip in with the voice, charts
// and numbers that count up, push transitions between scenes, and presenters (3D: robot, cat,
// person; or a 2D illustrated person) that talk in time with the voice, wave, point at the screen
// and are happy about the right answer.
// Props are written by remotion_render.py (pro=True).
import React, {useEffect, useMemo, useState} from 'react';
import {AbsoluteFill, Audio, Sequence, continueRender, delayRender, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import type {LessonProps, Scene} from '../Lesson';
import {Avatar2D, AvatarStyle} from './Avatar2D';
import {Act, Character, Member, Point} from './cast';
import {Character3D} from './Character3D';
import {SceneBody} from './scenes';
import {FAINT, FONT, LeadContext, NIGHT, SOFT, clamp, hexA} from './theme';

export type ProProps = LessonProps & {mouth: number[]; talk: [number, number, string][]; cast: Member[];
  character?: Character; avatar?: AvatarStyle;   // who presents (remotion_render.py, PRO_PRESENTER / PRO_AVATAR)
  aa?: boolean; sharp?: number};   // aa: smooth 3D edges (off when 3D is drawn in software); sharp: 3D pixel density

const LEAD = 0.3;   // scenes overlap by this much at each cut (push transition)

// The backdrop: deep gradient, slow glowing colour clouds, a perspective floor grid, drifting specks.
const Backdrop: React.FC<{accent: string; accent2: string}> = ({accent, accent2}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const orb = (x: number, y: number, r: number, c: string, sx: number, sy: number, ph: number) => (
    <div style={{position: 'absolute', left: x + Math.sin(t * sx + ph) * 140 - r, top: y + Math.cos(t * sy + ph) * 90 - r,
      width: r * 2, height: r * 2, borderRadius: r, background: `radial-gradient(circle, ${hexA(c, 0.5)}, ${hexA(c, 0.18)} 35%, transparent 70%)`}} />
  );
  const specks = useMemo(() => Array.from({length: 46}, (_, i) => ({
    x: (i * 397) % width, y: (i * 211) % height, s: 2 + (i % 4), v: 6 + (i % 7) * 3, a: 0.15 + (i % 5) * 0.08})), [width, height]);
  return (
    <AbsoluteFill style={{background: `radial-gradient(120% 90% at 30% 20%, #13284a 0%, #0b1730 45%, ${NIGHT} 100%)`, overflow: 'hidden'}}>
      {orb(width * 0.22, height * 0.3, 520, accent, 0.11, 0.09, 0)}
      {orb(width * 0.8, height * 0.75, 600, accent2, 0.08, 0.12, 2)}
      {orb(width * 0.62, height * 0.12, 380, '#6d5dfc', 0.13, 0.07, 4)}
      <div style={{position: 'absolute', left: -width * 0.25, right: -width * 0.25, bottom: -height * 0.1, height: height * 0.55,
        transform: 'perspective(900px) rotateX(64deg)', transformOrigin: '50% 100%', opacity: 0.35,
        backgroundImage: `linear-gradient(${hexA(accent, 0.55)} 1.5px, transparent 1.5px), linear-gradient(90deg, ${hexA(accent, 0.55)} 1.5px, transparent 1.5px)`,
        backgroundSize: '90px 90px', backgroundPosition: `0px ${(t * 30) % 90}px`,
        maskImage: 'linear-gradient(transparent, black 60%)', WebkitMaskImage: 'linear-gradient(transparent, black 60%)'}} />
      {specks.map((p, i) => (
        <div key={i} style={{position: 'absolute', left: p.x + Math.sin(t * 0.3 + i) * 20, top: ((p.y - t * p.v) % height + height) % height,
          width: p.s, height: p.s, borderRadius: p.s, background: '#fff', opacity: p.a}} />
      ))}
    </AbsoluteFill>
  );
};

// Film look on top: a soft vignette and a fine grain (one small noise tile, moved every frame:
// cheap to draw, also without a graphics card).
const grainTile = (() => {
  let url = '';
  return () => {
    if (url || typeof document === 'undefined') return url;
    const c = document.createElement('canvas');
    c.width = c.height = 192;
    const g = c.getContext('2d')!;
    const img = g.createImageData(192, 192);
    let s = 1234567;
    for (let i = 0; i < img.data.length; i += 4) {
      s = (s * 16807) % 2147483647;
      const v = s % 256;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    url = c.toDataURL('image/png');
    return url;
  };
})();

const Finish: React.FC = () => {
  const frame = useCurrentFrame();
  const tile = grainTile();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,.55) 100%)'}} />
      {tile ? <AbsoluteFill style={{backgroundImage: `url(${tile})`, opacity: 0.05, mixBlendMode: 'overlay',
        backgroundPosition: `${(frame * 37) % 192}px ${(frame * 71) % 192}px`}} /> : null}
    </AbsoluteFill>
  );
};

// One scene inside its box, pushed in from the right and out to the left at the cuts.
const SceneShell: React.FC<{sc: Scene; first: boolean; last: boolean; accent: string; accent2: string; w: number; h: number}> =
  ({sc, first, last, accent, accent2, w, h}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lead = first ? 0 : LEAD;
  const t = frame / fps - lead;
  const d = sc.duration_s;
  const enter = first ? 1 : interpolate(t, [-LEAD, LEAD * 0.9], [0, 1], {...clamp, easing: (x) => 1 - Math.pow(1 - x, 3)});
  const exit = last ? 0 : interpolate(t, [d - LEAD * 0.4, d + LEAD], [0, 1], {...clamp, easing: (x) => x * x});
  const drift = interpolate(t, [0, Math.max(1, d)], [1, 1.025], clamp);
  return (
    <LeadContext.Provider value={lead}>
      <div style={{position: 'absolute', inset: 0, opacity: Math.min(enter, 1 - exit),
        transform: `translateX(${(1 - enter) * 140 - exit * 140}px) scale(${drift * (0.97 + 0.03 * enter)})`,
        filter: `blur(${(1 - enter) * 14 + exit * 14}px)`, transformOrigin: '30% 50%'}}>
        <SceneBody sc={sc} accent={accent} accent2={accent2} w={w} h={h} />
      </div>
    </LeadContext.Provider>
  );
};

// Title of the lesson, scene counter and a progress line.
const Chrome: React.FC<{title: string; scenes: Scene[]; accent: string; accent2: string; total: number}> = ({title, scenes, accent, accent2, total}) => {
  const frame = useCurrentFrame();
  const {fps, width} = useVideoConfig();
  const t = frame / fps;
  const i = Math.max(0, scenes.findIndex((s) => t >= s.start_s && t < s.start_s + s.duration_s));
  const show = interpolate(t, [0.8, 1.6], [0, 1], clamp);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div style={{position: 'absolute', left: 64, top: 44, display: 'flex', alignItems: 'center', gap: 14, opacity: show,
        color: SOFT, fontSize: 22, fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase'}}>
        <div style={{width: 14, height: 14, borderRadius: 4, background: `linear-gradient(135deg, ${accent}, ${accent2})`}} />{title}
      </div>
      <div style={{position: 'absolute', right: 64, top: 44, color: FAINT, fontSize: 22, fontWeight: 600, opacity: show,
        fontVariantNumeric: 'tabular-nums'}}>{String(i + 1).padStart(2, '0')} / {String(scenes.length).padStart(2, '0')}</div>
      <div style={{position: 'absolute', left: 0, bottom: 0, height: 5, width: width * Math.min(1, t / total),
        background: `linear-gradient(90deg, ${accent}, ${accent2})`, boxShadow: `0 0 18px ${accent2}`}} />
    </AbsoluteFill>
  );
};

// What the presenters do: wave at the start and the end, thumbs up on the right answer, and
// turn to the screen while the voice explains an element (or when it appears).
const plan = (scenes: Scene[], total: number, talk: [number, number, string][], cast: Member[]) => {
  const speakerAt = (t: number) => talk.find(([a, b]) => t >= a - 0.2 && t <= b + 0.2)?.[2];
  const acts: Act[] = [{name: 'Wave', start: 0.1, end: 2.6}];
  if (total > 10) acts.push({name: 'Wave', start: total - 2.6, end: total});
  const points: Point[] = [];
  for (const sc of scenes) {
    if (sc.kind === 'answer') acts.push({name: 'ThumbsUp', start: sc.start_s + 0.5, end: sc.start_s + 2.4});
    if (sc.kind === 'title') continue;
    // a short turn to the screen as each element comes up, then back to the audience
    const wins = sc.active.some((w) => w) ? (sc.active.filter(Boolean) as number[][]).map((w) => [w[0], Math.min(w[1], w[0] + 1.8)])
      : sc.appear.map((a) => [a, a + 1.6]);
    for (const [a, b] of wins) {
      const start = sc.start_s + a, end = sc.start_s + b;
      if (end - start < 0.6) continue;
      points.push({start, end, who: cast.length > 1 ? speakerAt((start + end) / 2) : undefined});
    }
  }
  return {acts, points};
};

const useFonts = () => {
  const [handle] = useState(() => delayRender('Loading fonts'));
  useEffect(() => {
    Promise.all(['400', '600', '700', '800'].map((w) => document.fonts.load(`${w} 40px Inter`)))
      .then(() => continueRender(handle)).catch(() => continueRender(handle));
  }, [handle]);
};

export const Pro: React.FC<ProProps> = ({scenes, audio, accent, accent2, title, fps, width, total_s, mouth, talk, cast,
  character = 'robot', avatar = 'micah', aa = true, sharp = 1.5}) => {
  useFonts();
  const {acts, points} = useMemo(() => plan(scenes, total_s, talk || [], cast || []), [scenes, total_s, talk, cast]);
  const k = width / 1920;
  const duo = (cast || []).length >= 2;
  const solo = (cast || []).length === 1;
  // content box in 1920x1080 units; the dialogue layout is drawn at the solo size and scaled down
  const box = duo ? {x: 470, y: 150, w: 1180, h: 830, s: 0.83} : solo ? {x: 100, y: 150, w: 1180, h: 830, s: 1}
    : {x: 120, y: 150, w: 1680, h: 830, s: 1};
  const robotW = 660, robotH = 980;
  const edge = duo ? 100 : 10;   // how far past the screen's edge the presenter's box may reach
  return (
    <AbsoluteFill style={{fontFamily: FONT, background: NIGHT}}>
      {audio ? <Audio src={staticFile(audio)} /> : null}
      <Backdrop accent={accent} accent2={accent2} />
      <AbsoluteFill style={{transform: `scale(${k})`, transformOrigin: '0 0', width: 1920, height: 1080}}>
        {character !== 'person-2d' && (cast || []).map((m, i) => (
          <div key={`floor${i}`} style={{position: 'absolute', top: 905, width: 420, height: 90, borderRadius: '50%',
            left: m.side === 'right' ? (duo ? 1540 : 1385) : 20, background: `radial-gradient(ellipse, ${hexA(m.color, 0.55)}, transparent 70%)`,
            filter: 'blur(6px)'}} />
        ))}
        <div style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h, transform: `scale(${box.s})`, transformOrigin: '0 0'}}>
          {scenes.map((sc, i) => {
            const first = i === 0, last = i === scenes.length - 1;
            const from = Math.max(0, Math.round((sc.start_s - (first ? 0 : LEAD)) * fps));
            const to = Math.round((sc.start_s + sc.duration_s + (last ? 0 : LEAD)) * fps);
            return (
              <Sequence key={i} from={from} durationInFrames={Math.max(1, to - from)} layout="none">
                <SceneShell sc={sc} first={first} last={last} accent={accent} accent2={accent2} w={box.w} h={box.h} />
              </Sequence>
            );
          })}
        </div>
        {(cast || []).map((m, i) => (
          <div key={m.who} style={{position: 'absolute', top: 70, width: robotW, height: robotH,
            left: m.side === 'right' ? 1920 - robotW + edge : -edge}}>
            {character === 'person-2d'
              ? <Avatar2D look={avatar} duo={duo} member={m} mouth={mouth} talk={talk} acts={acts} points={points} width={robotW} height={robotH} />
              : <Character3D kind={character} member={m} mouth={mouth} talk={talk} acts={acts} points={points} width={robotW}
                height={robotH} aa={aa} sharp={sharp} />}
          </div>
        ))}
      </AbsoluteFill>
      <Chrome title={title} scenes={scenes} accent={accent} accent2={accent2} total={total_s} />
      <Finish />
    </AbsoluteFill>
  );
};

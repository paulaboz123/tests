// The 3D presenters, drawn with three.js. Three ready-made, freely licensed models (assets/README.md):
// - robot:     RobotExpressive (Quaternius, CC0), drawn as a glossy toy: smooth surfaces, a white shell
//              with the speaker's colour on the rings, hands and feet;
// - cat:       Toon Cat FREE (Omabuarts Studio, CC-BY 4.0), its own colours;
// - person-3d: a woman and a man in suits (Quaternius, CC0), stylised (big head, simple face).
// Every frame is set from the video time, so renders are the same each time, and nothing follows
// the raw voice frame by frame (that jitters): the mouth follows the voice lightly averaged, the head
// only slowly. Body moves are the models' own animations where they have them (idle, wave, thumbs up,
// victory), each played once across its window and blended in and out, otherwise posed in code.
import React, {useEffect, useLayoutEffect, useMemo, useRef, useState} from 'react';
import {useThree} from '@react-three/fiber';
import {ThreeCanvas} from '@remotion/three';
import {cancelRender, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import * as THREE from 'three';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {MeshoptDecoder} from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {toCreasedNormals} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {clone as cloneSkinned} from 'three/examples/jsm/utils/SkeletonUtils.js';
import {Act, Member, PresenterProps, acting, pointing} from './cast';
import {blink, ease, smoothAt, talking, windowAmount} from './motion';

export type Kind3D = 'robot' | 'cat' | 'person-3d';

// The model file each presenter uses (remotion_render.py copies the same files next to the props).
export const modelFile = (kind: Kind3D, member: Member) =>
  kind === 'robot' ? 'robot.glb' : kind === 'cat' ? 'cat.glb' : member.who === 'host' ? 'man-suit.glb' : 'woman-suit.glb';

// colours of the two people (their files carry no usable colours)
const PEOPLE: Record<string, Record<string, string>> = {
  'woman-suit.glb': {Skin: '#c88462', Black: '#1d2440', Belt: '#2a1d1a', Shirt: '#f6f3ee', Details: '#f0c36a', Face: '#16141c', Hair: '#3b2418'},
  'man-suit.glb': {Skin: '#a8694a', Black: '#1b2d6b', Belt: '#16141c', Shirt: '#e7eefc', Details: '#e23b4a', Face: '#16141c', Hair: '#1c1512'},
};

const material = (kind: Kind3D, file: string, m: any, member: Member) => {
  if (kind === 'cat') {   // its own painted colours, a little satin; the second cat (host) a cooler coat
    const c = m.clone();
    if (member.who === 'host') c.color = new THREE.Color('#c9c6ff');
    c.roughness = 0.62;
    c.metalness = 0;
    return c;
  }
  if (kind === 'person-3d') {
    const color = PEOPLE[file]?.[m.name] || '#cccccc';
    const shiny = m.name === 'Face' || m.name === 'Hair';
    // plain (not clear-coated) material: these models have many more corners than the robot
    return new THREE.MeshStandardMaterial({color, roughness: shiny ? 0.35 : 0.62, metalness: 0, side: THREE.DoubleSide});
  }
  // robot: Main = shell, Grey = rings, hands and feet, Black = eyes and joints
  if (m.name === 'Main') return new THREE.MeshPhysicalMaterial({color: '#f3f5fa', roughness: 0.3, metalness: 0, clearcoat: 1, clearcoatRoughness: 0.12});
  if (m.name === 'Grey') {
    return new THREE.MeshPhysicalMaterial({color: member.color, roughness: 0.32, metalness: 0.05, clearcoat: 0.8, clearcoatRoughness: 0.15});
  }
  return new THREE.MeshPhysicalMaterial({color: '#0b0e1a', roughness: 0.14, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.05});
};

// how tall each one stands in the scene (the camera is the same for all)
const HEIGHT: Record<Kind3D, number> = {robot: 5.0, cat: 3.7, 'person-3d': 4.9};

const cache: Record<string, Promise<any>> = {};
const loadModel = (url: string, smooth: boolean) => {
  if (!cache[url]) {
    cache[url] = new Promise((resolve, reject) => new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).load(url, (g: any) => {
      if (smooth) {
        g.scene.traverse((o: any) => {
          if (!o.isMesh) return;
          // the robot's parts are modelled tiny (scaled up 100x in the file): work at a larger size,
          // so close corners are not taken as one, then scale back
          const big = o.geometry.clone();
          big.scale(1000, 1000, 1000);
          const s = toCreasedNormals(big, (55 * Math.PI) / 180);
          s.scale(0.001, 0.001, 0.001);
          o.geometry = s;
        });
      }
      resolve(g);
    }, undefined, reject));
  }
  return cache[url];
};

type Rig = {scene: THREE.Object3D; mixer: THREE.AnimationMixer; actions: Record<string, THREE.AnimationAction>;
  get: (name: string) => THREE.Object3D | undefined; face: any; scale: number; lift: number; reset: () => void};

const useRig = (gltf: any, kind: Kind3D, file: string, member: Member): Rig => useMemo(() => {
  const scene = cloneSkinned(gltf.scene) as THREE.Object3D;
  scene.traverse((o: any) => {
    if (o.isMesh) {
      o.frustumCulled = false;
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      const made = mats.map((m: any) => material(kind, file, m, member));
      o.material = made.length === 1 ? made[0] : made;
    }
  });
  scene.updateMatrixWorld(true);   // the bones in place before measuring (skinned models)
  const box = new THREE.Box3().setFromObject(scene, true);
  const scale = HEIGHT[kind] / Math.max(0.01, box.max.y - box.min.y);
  const mixer = new THREE.AnimationMixer(scene);
  const actions: Record<string, THREE.AnimationAction> = {};
  for (const clip of gltf.animations as THREE.AnimationClip[]) {
    const a = mixer.clipAction(clip);
    a.play();
    a.setEffectiveWeight(0);
    actions[clip.name] = a;
  }
  let face: any = null;
  scene.traverse((o: any) => { if (o.morphTargetDictionary && o.morphTargetDictionary.Surprised !== undefined) face = o; });
  const named: Record<string, THREE.Object3D> = {};
  const rest: [THREE.Object3D, THREE.Quaternion, THREE.Vector3, THREE.Vector3][] = [];
  scene.traverse((o) => {
    if (o.name && !named[o.name]) named[o.name] = o;
    rest.push([o, o.quaternion.clone(), o.position.clone(), o.scale.clone()]);
  });
  // every frame starts from the model's rest pose (the turns in code never pile up)
  const reset = () => rest.forEach(([o, q, p, s]) => { o.quaternion.copy(q); o.position.copy(p); o.scale.copy(s); });
  // the file's bone names lose their dots on loading (UpperArm.R -> UpperArmR): look them up the same way
  return {scene, mixer, actions, get: (n: string) => named[THREE.PropertyBinding.sanitizeNodeName(n)], face, scale,
    lift: -box.min.y * scale, reset};
}, [gltf, kind, file, member]);

// the model's own clips: idle underneath, acts on top (each played once across its window)
const playClips = (rig: Rig, t: number, acts: Act[], idle: string, clips: Partial<Record<Act['name'], string>>) => {
  const {actions, mixer} = rig;
  let rest = 1;
  for (const name of Object.keys(actions)) actions[name].setEffectiveWeight(0);
  for (const a of acts) {
    const act = actions[clips[a.name] || ''];
    if (!act) continue;
    const w = windowAmount(t, a.start, a.end, 0.35);
    if (w <= 0) continue;
    const len = act.getClip().duration;
    act.time = Math.min(1, Math.max(0, (t - a.start) / Math.max(0.1, a.end - a.start))) * (len - 0.001);
    act.setEffectiveWeight(w);
    rest -= w;
  }
  const base = actions[idle];
  if (base) {
    base.time = t % base.getClip().duration;
    base.setEffectiveWeight(Math.max(0, rest));
  }
  mixer.update(0);
};

const Body: React.FC<{gltf: any; kind: Kind3D; file: string; member: Member; t: number; frame: number; fps: number;
  mouth: number[]; talk: PresenterProps['talk']; acts: Act[]; points: PresenterProps['points']; onReady: () => void}> = (
  {gltf, kind, file, member, t, frame, fps, mouth, talk, acts, points, onReady}) => {
  const rig = useRig(gltf, kind, file, member);
  // the model arrives after the frame was drawn: draw again with it, then let Remotion take the picture
  const {advance} = useThree();
  const ready = useRef(false);
  useEffect(() => {
    if (ready.current) return;
    ready.current = true;
    advance(performance.now());
    onReady();
  }, [advance, onReady]);
  useLayoutEffect(() => {
    const speak = talking(t, talk, member.who);
    const m = speak * smoothAt(mouth, frame, 2, 1);                                                  // the mouth
    const flow = speak * smoothAt(mouth, frame, Math.round(fps * 0.6), Math.round(fps * 0.25));   // the head
    const toward = member.side === 'right' ? -1 : 1;   // the screen is on the other side
    const p = ease(pointing(t, points, member.who));
    const seed = member.side === 'left' ? 1 : 2;
    const g = (n: string) => rig.get(n);
    rig.reset();

    if (kind === 'robot') {
      playClips(rig, t, acts, 'Idle', {Wave: 'Wave', ThumbsUp: 'ThumbsUp'});
      if (rig.face) rig.face.morphTargetInfluences[rig.face.morphTargetDictionary.Surprised] = Math.min(0.55, m * 0.65);
      g('Head')?.rotateX(-flow * 0.05 + Math.sin(t * 0.7) * 0.015);
      g('Head')?.rotateY(Math.sin(t * 0.45 + seed) * 0.05);
      rig.scene.rotation.y = toward * (0.22 + 0.3 * p);
      // the arm on the screen's side lifts toward it (in these rigs a turn about x lifts an arm sideways)
      const near = member.side === 'right' ? 'R' : 'L';
      if (p > 0) g(`UpperArm.${near}`)?.rotateX(0.8 * p);   // the arm is long: not so high it leaves the picture
    } else if (kind === 'person-3d') {
      playClips(rig, t, acts, 'Idle', {ThumbsUp: 'Victory'});
      g('Head')?.rotateX(flow * 0.06 - Math.sin(t * 0.7) * 0.015);
      g('Head')?.rotateY(Math.sin(t * 0.45 + seed) * 0.06);
      rig.scene.rotation.y = toward * (0.25 + 0.3 * p);
      // the arm on the screen's side points at it, the other one waves (a turn about x lifts an arm
      // sideways in these rigs); the far hand moves a little while talking
      const near = member.side === 'right' ? 'R' : 'L';
      const far = near === 'R' ? 'L' : 'R';
      const wave = acting(t, acts, 'Wave');
      if (p > 0) g(`UpperArm.${near}`)?.rotateX(0.95 * p);
      if (wave.w > 0) {
        g(`UpperArm.${far}`)?.rotateX(2.6 * wave.w);
        g(`LowerArm.${far}`)?.rotateY(Math.sin(t * 9) * 0.45 * wave.w);
      }
      const gest = flow * (1 - p) * (1 - wave.w);
      if (gest > 0) g(`UpperArm.${far}`)?.rotateX(0.35 * gest * (0.6 + 0.4 * Math.sin(t * 2.1)));
    } else {
      // the cat: breathing, tail and ears alive, mouth with the voice, head to the screen
      const happy = acting(t, acts, 'ThumbsUp');
      const hello = acting(t, acts, 'Wave');
      for (const name of Object.keys(rig.actions)) rig.actions[name].setEffectiveWeight(0);
      rig.mixer.update(0);
      const head = g('head_018');
      if (head) {
        head.rotateY(toward * 0.35 * p + Math.sin(t * 0.45 + seed) * 0.08);
        head.rotateZ(Math.sin(t * 2.4) * 0.16 * hello.w + Math.sin(t * 0.6) * 0.04);
        head.rotateX(-flow * 0.08 - 0.1 * hello.w);
      }
      g('mouth_021')?.rotateX(Math.min(0.45, m * 0.55));
      const twitch = (s: number) => blink(t * 0.8, s);
      g('ear.L_019')?.rotateZ(0.25 * twitch(seed + 1) + 0.2 * hello.w);
      g('ear.R_020')?.rotateZ(-0.25 * twitch(seed + 4) - 0.2 * hello.w);
      ['tail.01_08', 'tail.02_09', 'tail.03_010'].forEach((n, i) =>
        g(n)?.rotateZ(Math.sin(t * (1.6 + happy.w * 3) - i * 0.6) * (0.18 + 0.12 * happy.w)));
      g('spine.02_013')?.scale.setScalar(1 + Math.sin(t * 2.2) * 0.012);
      rig.scene.position.y = Math.abs(Math.sin(happy.k * Math.PI * 3)) * 0.35 * happy.w / rig.scale;
      rig.scene.rotation.y = toward * (0.3 + 0.25 * p);
    }
  });
  return (
    <group position={[0, rig.lift - 0.05, 0]} scale={rig.scale}>
      <primitive object={rig.scene} />
    </group>
  );
};

// soft studio reflections (a neutral room, made in code: nothing is downloaded)
const Studio: React.FC = () => {
  const {gl, scene} = useThree();
  useLayoutEffect(() => {
    const pmrem = new THREE.PMREMGenerator(gl);
    const env = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = env;
    (scene as any).environmentIntensity = 0.75;
    pmrem.dispose();
    return () => { scene.environment = null; env.dispose(); };
  }, [gl, scene]);
  return null;
};

export const Character3D: React.FC<PresenterProps & {kind: Kind3D; sharp?: number}> = (
  {kind, member, mouth, talk, acts, points, width, height, aa = true, sharp = 1.5}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const file = modelFile(kind, member);
  const [gltf, setGltf] = useState<any>(null);
  const [handle] = useState(() => delayRender(`Loading the 3D presenter (${file})`));
  useEffect(() => {
    loadModel(staticFile(file), kind === 'robot').then((g) => setGltf(g)).catch((e) => cancelRender(e));
  }, [file, kind]);
  const onReady = useMemo(() => () => continueRender(handle), [handle]);
  const t = frame / fps;
  return (
    <ThreeCanvas width={width} height={height} linear={false} dpr={aa ? sharp : 1}
      gl={{antialias: aa, alpha: true, preserveDrawingBuffer: true}}
      camera={{fov: 24, position: [0, 2.6, 17], near: 0.1, far: 100}} style={{background: 'transparent'}}>
      <Studio />
      <hemisphereLight args={['#e4ecff', '#1b2133', 0.55]} />
      <directionalLight position={[5, 9, 8]} intensity={2.0} />
      <directionalLight position={[-5, 3, 6]} intensity={0.6} color="#cfd8ff" />
      <directionalLight position={[-6, 5, -7]} intensity={2.4} color={member.color} />
      <directionalLight position={[6, 4, -6]} intensity={1.2} color="#ffffff" />
      {gltf ? <Body gltf={gltf} kind={kind} file={file} member={member} t={t} frame={frame} fps={fps} mouth={mouth}
        talk={talk} acts={acts} points={points} onReady={onReady} /> : null}
      <CameraAim y={2.25} />
    </ThreeCanvas>
  );
};

// Points the camera at the presenter's chest (three.js cameras look along -z by default).
const CameraAim: React.FC<{y: number}> = ({y}) => {
  const {camera} = useThree();
  useLayoutEffect(() => {
    camera.lookAt(0, y, 0);
    camera.updateProjectionMatrix();
  }, [camera, y]);
  return null;
};

// Smooth, frame-exact motion helpers for the 3D presenters: nothing follows the raw voice level
// frame by frame (that jitters); everything is averaged or eased.

export const ease = (x: number) => (x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x));

// 0..1: how much a window [a, b] is "on" at time t, with soft edges of f seconds
export const windowAmount = (t: number, a: number, b: number, f = 0.35) => Math.min(ease((t - a) / f), ease((b - t) / f));

// the voice level averaged over a few frames around `frame` (back, forward)
export const smoothAt = (values: number[], frame: number, back: number, fwd: number) => {
  let sum = 0;
  let n = 0;
  for (let k = frame - back; k <= frame + fwd; k++) {
    if (k >= 0 && k < values.length) {
      sum += values[k];
      n++;
    }
  }
  return n ? sum / n : 0;
};

// 0..1: is this person talking now (soft in and out)
export const talking = (t: number, talk: [number, number, string][], who: string) =>
  talk.reduce((acc, [a, b, w]) => (w === who ? Math.max(acc, windowAmount(t, a, b, 0.15)) : acc), 0);

// a blink every 3-5 seconds (same in every render): 0 open .. 1 closed
export const blink = (t: number, seed: number) => {
  const period = 3.4 + (seed % 3) * 0.6;
  const phase = (t + seed * 0.77) % period;
  const d = 0.16;
  return phase < d ? Math.sin((phase / d) * Math.PI) : 0;
};

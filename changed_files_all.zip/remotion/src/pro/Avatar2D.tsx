// The 2D presenters: an illustrated person in a round portrait, drawn as SVG (fast: no 3D).
// Drawings from DiceBear (assets/README.md): micah (CC BY 4.0, Micah Lanier), avataaars (free for
// personal and commercial use, Pablo Stanley), notionists (CC0, Zoish). The mouth changes with the
// real voice (on twos, like hand-drawn animation: at most 15 changes a second), the eyes blink, the
// portrait breathes, tilts to the screen while the voice explains an element, says hello at the
// start and the end, and is happy on the right answer. Notionists also wave, point and give an OK
// with a hand.
import React, {useMemo} from 'react';
import {createAvatar} from '@dicebear/core';
import * as micah from '@dicebear/micah';
import * as avataaars from '@dicebear/avataaars';
import * as notionists from '@dicebear/notionists';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {PresenterProps, acting, pointing} from './cast';
import {blink, ease, smoothAt, talking} from './motion';
import {hexA} from './theme';

export type AvatarStyle = 'micah' | 'avataaars' | 'notionists';

type Look = {style: any; base: Record<string, Record<string, any>>; mouthKey: string; mouths: [string, string, string];
  happyMouth: string; eyesKey?: string; eyes?: {open: string; closed: string; happy: string};
  gestures?: {none: string; wave: string; point: string; ok: string}; paper?: string};

// who looks like what: the presenter and the expert are women, the host is a man
const W = 'woman', M = 'man';
const LOOKS: Record<AvatarStyle, Look> = {
  micah: {
    style: micah,
    base: {
      [W]: {hair: ['full'], hairColor: ['77311d'], baseColor: ['f9c9b6'], shirt: ['collared'], shirtColor: ['ffffff'],
        earrings: ['stud'], earringsProbability: 100, earringColor: ['f4d150'], glassesProbability: 0, eyebrows: ['eyelashesUp'],
        nose: ['curve'], facialHairProbability: 0, ears: ['attached']},
      [M]: {hair: ['fonze'], hairColor: ['000000'], baseColor: ['ac6651'], shirt: ['crew'], shirtColor: ['e0ddff'],
        earringsProbability: 0, glassesProbability: 0, eyebrows: ['up'], nose: ['curve'], facialHairProbability: 0, ears: ['attached']},
    },
    mouthKey: 'mouth', mouths: ['smile', 'surprised', 'laughing'], happyMouth: 'laughing',
    eyesKey: 'eyes', eyes: {open: 'eyes', closed: 'smiling', happy: 'smiling'},
  },
  avataaars: {
    style: avataaars,
    base: {
      [W]: {top: ['bob'], hairColor: ['4a312c'], skinColor: ['edb98a'], clothing: ['blazerAndShirt'], clothesColor: ['5199e4'],
        eyebrows: ['defaultNatural'], accessoriesProbability: 0, facialHairProbability: 0, style: ['default']},
      [M]: {top: ['shortFlat'], hairColor: ['2c1b18'], skinColor: ['d08b5b'], clothing: ['collarAndSweater'], clothesColor: ['25557c'],
        eyebrows: ['defaultNatural'], accessoriesProbability: 0, facialHair: ['beardLight'], facialHairColor: ['2c1b18'],
        facialHairProbability: 100, style: ['default']},
    },
    mouthKey: 'mouth', mouths: ['twinkle', 'default', 'smile'], happyMouth: 'smile',
    eyesKey: 'eyes', eyes: {open: 'default', closed: 'closed', happy: 'happy'},
  },
  notionists: {
    style: notionists,
    base: {
      [W]: {hair: ['variant28'], body: ['variant21'], brows: ['variant01'], eyes: ['variant01'], nose: ['variant01'],
        glassesProbability: 0, beardProbability: 0, bodyIconProbability: 0},
      [M]: {hair: ['variant06'], body: ['variant20'], brows: ['variant01'], eyes: ['variant01'], nose: ['variant01'],
        glassesProbability: 0, beardProbability: 0, bodyIconProbability: 0},
    },
    mouthKey: 'lips', mouths: ['variant03', 'variant29', 'variant25'], happyMouth: 'variant25',
    gestures: {none: '', wave: 'waveLongArm', point: 'pointLongArm', ok: 'okLongArm'}, paper: '#fbfaf7',
  },
};

const draw = (look: Look, base: Record<string, any>, mouth: string, eyes: string | undefined, gesture: string) => {
  const o: Record<string, any> = {...base, [look.mouthKey]: [mouth], size: 512, seed: 'presenter', randomizeIds: true};
  if (look.eyesKey && eyes) o[look.eyesKey] = [eyes];
  if (look.gestures) {
    o.gestureProbability = gesture ? 100 : 0;
    if (gesture) o.gesture = [gesture];
  }
  // fill the box it is put in
  return createAvatar(look.style, o).toString().replace(/width="512"/, 'width="100%"').replace(/height="512"/, 'height="100%"');
};

export const Avatar2D: React.FC<PresenterProps & {look: AvatarStyle; duo?: boolean}> = (
  {look: name, duo = false, member, mouth, talk, acts, points, width, height}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const look = LOOKS[name] || LOOKS.micah;
  const base = look.base[member.who === 'host' ? M : W];
  // every picture this presenter needs, drawn once
  const pics = useMemo(() => {
    const out: Record<string, string> = {};
    const eyes = look.eyes ? [look.eyes.open, look.eyes.closed, look.eyes.happy] : [undefined];
    const gestures = look.gestures ? Object.values(look.gestures) : [''];
    for (const m of new Set([...look.mouths, look.happyMouth])) {
      for (const e of new Set(eyes)) for (const g of gestures) out[`${m}|${e}|${g}`] = draw(look, base, m, e, g);
    }
    return out;
  }, [look, base]);

  // what the face does now
  const speak = talking(t, talk, member.who);
  const onTwos = frame - (frame % 2);
  const level = speak * smoothAt(mouth, onTwos, 1, 1);
  const flow = speak * smoothAt(mouth, frame, Math.round(fps * 0.6), Math.round(fps * 0.25));
  const happy = acting(t, acts, 'ThumbsUp');
  const hello = acting(t, acts, 'Wave');
  const p = ease(pointing(t, points, member.who));
  let m = level < 0.16 ? look.mouths[0] : level < 0.42 ? look.mouths[1] : look.mouths[2];
  if (happy.w > 0.5 && level < 0.16) m = look.happyMouth;
  const seed = member.side === 'left' ? 1 : 2;
  const eyes = look.eyes ? (happy.w > 0.5 ? look.eyes.happy : blink(t, seed) > 0.4 ? look.eyes.closed : look.eyes.open) : undefined;
  const gesture = !look.gestures ? '' : hello.w > 0.3 ? look.gestures.wave : happy.w > 0.3 ? look.gestures.ok
    : p > 0.3 ? look.gestures.point : look.gestures.none;
  const svg = pics[`${m}|${eyes}|${gesture}`] || Object.values(pics)[0];

  // how the portrait moves: pops in, breathes, leans to the screen, hops to say hello or when happy
  const toward = member.side === 'right' ? -1 : 1;
  const pop = interpolate(t, [0, 0.55], [0.6, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: (x) => 1 - Math.pow(1 - x, 3)});
  const show = interpolate(t, [0, 0.35], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const hop = Math.abs(Math.sin(hello.k * Math.PI * 2)) * 14 * hello.w + Math.abs(Math.sin(happy.k * Math.PI * 3)) * 18 * happy.w;
  const breathe = Math.sin(t * 1.7 + seed) * 4;
  const lean = toward * (4 * p) + Math.sin(t * 0.5 + seed) * 1.2 + Math.sin(t * 7) * 3 * hello.w;
  const size = Math.min(width, height) * (duo ? 0.62 : 0.82);   // two portraits: smaller, beside the content
  const ring = 0.35 + 0.65 * Math.min(1, flow * 2.2);
  // drawn with gradients and borders only: blurred shadows are slow to draw in every frame
  return (
    <div style={{position: 'absolute', left: (width - size) / 2 + toward * 16 * p, top: height * 0.5 - size / 2 + 40 - hop,
      width: size, height: size, opacity: show, transform: `scale(${pop}) rotate(${lean}deg)`}}>
      <div style={{position: 'absolute', left: '-6%', right: '-6%', top: '88%', height: '22%', borderRadius: '50%',
        background: 'radial-gradient(ellipse, rgba(0,0,0,0.45), transparent 70%)'}} />
      <div style={{position: 'absolute', inset: '-16%', borderRadius: '50%', opacity: speak * ring,
        background: `radial-gradient(circle, ${hexA(member.color, 0.6)} 52%, ${hexA(member.color, 0.18)} 62%, transparent 71%)`}} />
      <div style={{position: 'absolute', inset: -12, borderRadius: '50%', border: `6px solid ${hexA(member.color, 0.9)}`,
        opacity: speak * ring}} />
      <div style={{position: 'absolute', inset: 0, borderRadius: '50%', overflow: 'hidden', border: '5px solid rgba(255,255,255,0.8)',
        background: look.paper || `radial-gradient(circle at 35% 30%, ${hexA(member.color, 0.95)}, ${hexA(member.color, 0.55)} 60%, ${hexA('#0b1730', 0.9)})`}}>
        <div style={{position: 'absolute', left: '4%', top: '7%', width: '92%', height: '92%', transform: `translateY(${breathe}px)`}}
          dangerouslySetInnerHTML={{__html: svg}} />
      </div>
    </div>
  );
};

// Who presents and what they do, shared by the 3D and the 2D presenters.
import {windowAmount} from './motion';

export type Member = {who: string; color: string; side: 'left' | 'right'};
export type Act = {name: 'Wave' | 'ThumbsUp'; start: number; end: number};   // in video seconds
export type Point = {start: number; end: number; who?: string};               // turning to the screen
export type Character = 'robot' | 'cat' | 'person-3d' | 'person-2d';

export type PresenterProps = {member: Member; mouth: number[]; talk: [number, number, string][]; acts: Act[];
  points: Point[]; width: number; height: number; aa?: boolean};

// 0..1: how much this presenter turns to the screen now
export const pointing = (t: number, points: Point[], who: string) =>
  points.reduce((acc, q) => (q.who && q.who !== who ? acc : Math.max(acc, windowAmount(t, q.start, q.end, 0.5))), 0);

// 0..1 for an act now, and how far into it (0..1)
export const acting = (t: number, acts: Act[], name: Act['name']) => {
  for (const a of acts) {
    if (a.name !== name) continue;
    const w = windowAmount(t, a.start, a.end, 0.35);
    if (w > 0) return {w, k: Math.min(1, Math.max(0, (t - a.start) / Math.max(0.1, a.end - a.start)))};
  }
  return {w: 0, k: 0};
};

"""
runcard.py - the "run card" of every result (document, slides, video, conversation, course):
what it was made from, with which solution, what it cost and how long it took.

Written next to the result as run_card.json (for compare.py) and run_card.md (to read):
  - request:  what was asked (the person's own words when made with ask.py)
  - input:    which sources of the knowledge base were used, how many excerpts, where in them
  - solution: which model wrote and reviewed it, search model, slide reader, voice(s), slide
              engine, characters, pictures, code and prompt versions
  - cost:     every model call grouped by step and model (calls, tokens, estimated $), plus the
              local steps (free) and the time each part took
  - quality:  the verdict and review scores (added by quality.py)

Costs are estimates from list prices (config.PRICES), not invoices. Local models cost $0.
Compare results of different setups (free vs paid, Sonnet vs Opus): uv run compare.py
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import config
import store

# set by ask.py: the request in the person's own words, shown on the card
request_text = ""

FILES = ["lesson.html", "lesson.md", "slides.pdf", "slides.pptx", "notes.md", "lesson_video.mp4",
         "lesson_audio.mp3", "lesson_video.srt", "lesson_audio.srt", "chapters.txt", "script.md", "quiz.md"]


def cost_summary(calls: list[dict]) -> dict:
    """Model calls added up per step and model, and in total."""
    rows: dict[tuple, dict] = {}
    for c in calls:
        r = rows.setdefault((c["step"], c["model"], c["backend"]),
                            {"step": c["step"], "model": c["model"], "backend": c["backend"], "calls": 0,
                             "in_tokens": 0, "out_tokens": 0, "cache_read_tokens": 0, "characters": 0,
                             "seconds": 0.0, "cost_usd": 0.0})
        r["calls"] += 1
        r["in_tokens"] += int(c.get("in_tokens") or 0)
        r["out_tokens"] += int(c.get("out_tokens") or 0)
        r["characters"] += int(c.get("characters") or 0)
        r["cache_read_tokens"] += int(c.get("cache_read_tokens") or 0)
        r["seconds"] = round(r["seconds"] + float(c.get("seconds") or 0), 1)
        r["cost_usd"] = round(r["cost_usd"] + float(c.get("cost_usd") or 0), 6)
    by_step = sorted(rows.values(), key=lambda r: -r["cost_usd"])
    return {"total_usd": round(sum(r["cost_usd"] for r in by_step), 4),
            "model_calls": sum(r["calls"] for r in by_step),
            "in_tokens": sum(r["in_tokens"] for r in by_step), "out_tokens": sum(r["out_tokens"] for r in by_step),
            "cache_read_tokens": sum(r["cache_read_tokens"] for r in by_step),
            "model_seconds": round(sum(r["seconds"] for r in by_step), 1), "by_step": by_step,
            "note": "estimate from list prices; local models and local steps are free"}


def input_summary(sources: dict) -> dict:
    """The sources a result was made from: per source title, how many excerpts and where."""
    used: dict[str, dict] = {}
    for _label, s in sorted(sources.items(), key=lambda kv: (kv[1].get("title", ""), kv[1].get("start", 0))):
        u = used.setdefault(s.get("title", s.get("video_id", "?")),
                            {"source": s.get("title", ""), "id": s.get("video_id", ""), "excerpts": 0, "where": []})
        u["excerpts"] += 1
        where = s.get("where") or f"{store.fmt_ts(s.get('start', 0))}-{store.fmt_ts(s.get('end', 0))}"
        if where not in u["where"]:
            u["where"].append(where)
    try:
        base = {"sources_in_knowledge_base": len(store.available_recordings()),
                "excerpts_in_knowledge_base": len(store.all_segments())}
    except (OSError, ValueError, KeyError):
        base = {}
    return {**base, "sources_used": len(used), "excerpts_used": sum(u["excerpts"] for u in used.values()),
            "used": list(used.values())}


def solution(kind: str, style: str = "", characters: str = "", renderer: str = "", models: list[str] | None = None,
             settings: dict | None = None) -> dict:
    """What made the result. `models`: the models actually called (from the cost log)."""
    def where(backend: str) -> str:
        return "local" if backend == "ollama" else "Amazon Bedrock via gateway"
    out = {"writing_model": f"{(settings or {}).get('model') or config.CHAT_MODEL} ({where(config.CHAT_BACKEND)})",
           "review_model": config.REVIEW_MODEL or config.CHAT_MODEL,
           "search_model": f"{config.EMBED_MODEL} ({where(config.EMBED_BACKEND)})",
           "models_called": sorted(set(models or []))}
    if kind not in ("document", "slides"):
        import tts
        name = tts.eleven_voice_name if config.TTS_ENGINE == "elevenlabs" else (lambda v: v)
        try:
            who = (f"host {name(tts.role_voice('host'))}, expert {name(tts.role_voice('expert'))}" if style == "dialogue"
                   else f"voice {name(tts.role_voice('narrator') or 'default')}")
        except tts.TTSError:
            who = "voice: default"
        out["voice"] = f"{tts.engine_label()}: {who}"
    if kind not in ("document", "audio"):
        engine = {"html": "designer slides (html" + (", GSAP motion)" if config.GSAP else ")"),
                  "remotion": "Remotion (React templates)", "remotion-ai": "Remotion, scene code written by Claude",
                  "remotion-pro": "Remotion Pro (motion-design scenes, presenters)"}
        out.update({"slides": engine.get(renderer, f"simple slides ({renderer or 'pillow'})"),
                    "style": style,
                    "pictures": config.IMAGE_MODEL or "built-in drawings and icons (no image model)"})
        if style in ("presenter", "dialogue"):
            out["characters"] = characters or config.CHARACTERS
            if renderer == "remotion-pro":   # Pro draws its own presenters
                out["characters"] = config.PRO_PRESENTER + (f" ({config.PRO_AVATAR})" if config.PRO_PRESENTER == "person-2d" else "")
        out["slide_reader"] = f"{config.VISION_MODEL} ({where(config.VISION_BACKEND)})"
    if settings:
        out.update({k: settings[k] for k in ("skill", "prompt_version", "code_version", "self_review") if k in settings})
    return out


def write(out_dir: Path, *, kind: str, title: str, request: dict, sources: dict, calls: list[dict],
          timings: dict | None = None, style: str = "", characters: str = "", renderer: str = "",
          settings: dict | None = None, extra: dict | None = None) -> dict:
    """Write run_card.json and run_card.md into the result's folder. Returns the card."""
    previous = store.read_json(out_dir / "run_card.json", {}) or {}
    card = {
        "kind": kind, "title": title, "folder": out_dir.name, "created": datetime.now().isoformat(timespec="seconds"),
        "request": {**({"text": request_text} if request_text else {}), **request},
        "files": [f for f in FILES if (out_dir / f).exists()],
        "input": input_summary(sources),
        "solution": solution(kind, style, characters, renderer, [c["model"] for c in calls], settings),
        "cost": cost_summary(calls),
        "calls": calls,   # every model call, so later additions (the review) are added up exactly
        "time": timings or {},
        **(extra or {}),
    }
    if previous.get("quality"):
        card["quality"] = previous["quality"]
    save(out_dir, card)
    return card


def add_quality(out_dir: Path, result: dict, review_calls: list[dict]) -> None:
    """Add the verdict (and the cost of the model review) to an existing run card."""
    card = store.read_json(out_dir / "run_card.json", {}) or {}
    if not card:
        return
    q = {"verdict": result.get("status"), "fail": result.get("fail", [])[:5], "issues": len(result.get("issues", []))}
    if result.get("review"):
        q.update({k: result["review"].get(k) for k in ("faithful", "level_fit", "clarity")})
    card["quality"] = q
    if review_calls:   # the review is part of what the result cost
        card["calls"] = card.get("calls", []) + review_calls
        card["cost"] = cost_summary(card["calls"])
    save(out_dir, card)


def save(out_dir: Path, card: dict) -> None:
    store.write_json(out_dir / "run_card.json", card)
    (out_dir / "run_card.md").write_text(markdown(card), encoding="utf-8")


def markdown(card: dict) -> str:
    """The run card to read."""
    r, i, s, c = card["request"], card["input"], card["solution"], card["cost"]
    out = [f"# Run card: {card['title']}", "",
           f"**Output:** {card['kind']} · {', '.join(card['files']) or 'plan only'} · created {card['created']}", ""]
    if r.get("text"):
        out += [f"**Request:** \"{r['text']}\"", ""]
    hide = {"text"} | ({"characters"} if r.get("style") not in ("presenter", "dialogue") else set())
    asked = ", ".join(f"{k} {v}" for k, v in r.items() if k not in hide and v not in ("", None, [], {}))
    out += [f"**Settings:** {asked}", "", "## Input", ""]
    if "sources_in_knowledge_base" in i:
        out += [f"Knowledge base: {i['sources_in_knowledge_base']} sources, {i['excerpts_in_knowledge_base']} excerpts. "
                f"Used: {i['sources_used']} sources, {i['excerpts_used']} excerpts.", ""]
    out += ["| Source | Excerpts | Where |", "|---|---|---|"]
    out += [f"| {u['source']} | {u['excerpts']} | {', '.join(u['where'][:6])}{' ...' if len(u['where']) > 6 else ''} |"
            for u in i["used"]]
    out += ["", "## Solution", "", "| Part | Used |", "|---|---|"]
    out += [f"| {k.replace('_', ' ')} | {', '.join(v) if isinstance(v, list) else v} |" for k, v in s.items()]
    out += ["", "## Cost and time", "",
            f"**Model cost: ${c['total_usd']:.4f}** ({c['model_calls']} calls, {c['in_tokens']:,} tokens in, "
            f"{c['out_tokens']:,} out; {c['note']})", "",
            "| Step | Model | Calls | Tokens in / out | Seconds | Cost $ |", "|---|---|---|---|---|---|"]
    out += [f"| {x['step']} | {x['model']} | {x['calls']} | "
            + (f"{x['characters']:,} characters" if x.get("characters") else f"{x['in_tokens']:,} / {x['out_tokens']:,}")
            + f" | {x['seconds']} | {x['cost_usd']:.4f} |" for x in c["by_step"]]
    if card.get("time"):
        out += ["", "Time: " + ", ".join(f"{k.replace('_s', '')} {v} s" for k, v in card["time"].items()
                                       if isinstance(v, int | float))]
    q = card.get("quality")
    if q:
        out += ["", "## Quality", "", f"**Verdict: {q['verdict']}**"
                + (f" · review: true to sources {q['faithful']}/5, level {q['level_fit']}/5, clarity {q['clarity']}/5"
                   if q.get("faithful") else "")]
        out += [f"- {x}" for x in q.get("fail", [])]
    return "\n".join(out) + "\n"

"""Remotion Pro: who presents (robot, cat, people in 3D or 2D; one, two in a conversation, none on
request), what the composition gets (who talks when, the mouth from the real voice, which presenter),
how 3D is drawn, and (with Remotion installed) real renders with picture and sound."""
from __future__ import annotations

import json

import numpy as np
import pytest
from conftest import needs_ffmpeg

import config
import media
import remotion_render
import tts


def test_who_presents(monkeypatch):
    monkeypatch.setattr(config, "PRO_PRESENTER", "robot")
    assert [m["who"] for m in remotion_render.cast({"style": "presenter"})] == ["presenter"]
    assert remotion_render.cast({"style": "clean"}) == []                          # slides: the scenes alone
    duo = remotion_render.cast({"style": "dialogue"})
    assert [(m["who"], m["side"]) for m in duo] == [("expert", "left"), ("host", "right")] and duo[0]["color"] != duo[1]["color"]
    monkeypatch.setattr(config, "PRO_PRESENTER", "none")
    assert remotion_render.cast({"style": "dialogue"}) == [] and remotion_render.presenter() == ("none", "")


def test_presenter_choice(monkeypatch):
    for who in ("robot", "cat", "person-3d"):
        monkeypatch.setattr(config, "PRO_PRESENTER", who)
        assert remotion_render.presenter() == (who, "")
    monkeypatch.setattr(config, "PRO_PRESENTER", "person_2d")                    # written either way
    monkeypatch.setattr(config, "PRO_AVATAR", "notionists")
    assert remotion_render.presenter() == ("person-2d", "notionists")
    monkeypatch.setattr(config, "PRO_AVATAR", "pixar")                           # unknown look: the default
    assert remotion_render.presenter() == ("person-2d", "micah")
    monkeypatch.setattr(config, "PRO_PRESENTER", "dragon")                       # unknown: the robot
    assert remotion_render.presenter() == ("robot", "")
    for who, files in remotion_render.MODELS.items():                            # every 3D model ships
        assert all((remotion_render.ASSETS / f).stat().st_size > 50_000 for f in files), who
    assert set(remotion_render.MODELS) == set(remotion_render.PRESENTERS)


def test_how_3d_is_drawn(monkeypatch):
    monkeypatch.setattr(config, "REMOTION_GL", "")
    assert remotion_render.gl_modes() == ["", "swangle"]               # the browser's choice first, software if it fails
    monkeypatch.setattr(config, "REMOTION_GL", "angle")
    assert remotion_render.gl_modes() == ["angle", "swangle"]
    monkeypatch.setattr(config, "REMOTION_GL", "swangle")
    assert remotion_render.gl_modes() == ["swangle"]
    assert remotion_render.ROBOT.exists() and remotion_render.ROBOT.stat().st_size > 100_000   # the CC0 model ships


def test_the_composition_gets_voice_timing_and_speakers(project, tmp_path, monkeypatch):
    monkeypatch.setattr(config, "PRO_PRESENTER", "cat")
    rate = 24000
    t = np.arange(int(rate * 4.0)) / rate
    voice = (0.4 * np.sin(2 * np.pi * 180 * t) * (np.sin(2 * np.pi * 3 * t) > 0)).astype(np.float32)
    wav = tmp_path / "narration.wav"
    tts._write_wav(wav, voice, rate)
    sb = {"title": "T", "style": "dialogue", "scenes": [
        {"visual": "cards", "heading": "Roles", "narration": "a b", "elements": [{"title": "PO", "detail": "", "icon": "", "value": ""}]}]}
    plan = [(0, {"text": "Who orders the backlog?", "speaker": "host", "pause": 0.3}),
            (0, {"text": "The Product Owner does.", "speaker": "expert", "pause": 0.3})]
    data = remotion_render.pro_props(sb, plan, [2.0, 2.0], wav)
    assert data["character"] == "cat" and data["stage"] is None and len(data["cast"]) == 2
    assert [w for _, _, w in data["talk"]] == ["host", "expert"] and data["talk"][1][0] == pytest.approx(2.1)
    assert len(data["mouth"]) >= 119 and max(data["mouth"]) > 0.5 and min(data["mouth"]) < 0.1   # opens and closes
    assert data["scenes"][0]["kind"] == "cards" and data["total_s"] == 4.0


@needs_ffmpeg
@pytest.mark.slow(900)   # every frame is drawn in a browser, 3D included
def test_a_pro_video_with_two_3d_presenters(project, tmp_path, monkeypatch):
    if not remotion_render.available()[0]:
        pytest.skip("Remotion not installed")
    monkeypatch.setattr(config, "PRO_PRESENTER", "robot")
    rate = 24000
    t = np.arange(int(rate * 3.0)) / rate
    tts._write_wav(tmp_path / "narration.wav", (0.3 * np.sin(2 * np.pi * 200 * t)).astype(np.float32), rate)
    sb = {"title": "Scrum", "style": "dialogue", "scenes": [
        {"visual": "cards", "heading": "Three roles", "narration": "x",
         "elements": [{"title": "Product Owner", "detail": "Orders the backlog", "icon": "", "value": ""},
                      {"title": "Developers", "detail": "Build the increment", "icon": "", "value": ""}]}]}
    plan = [(0, {"text": "Who orders the backlog?", "speaker": "host", "pause": 0.3}),
            (0, {"text": "The Product Owner, and the Developers build.", "speaker": "expert", "pause": 0.3})]
    out = remotion_render.render(tmp_path, sb, plan, [1.5, 1.5], tmp_path / "narration.wav", pro=True)
    tracks = media.stream_durations(out)
    assert abs(tracks["video"] - 3.0) < 0.2 and abs(tracks["audio"] - 3.0) < 0.3
    props = json.loads((tmp_path / "remotion_props.json").read_text(encoding="utf-8"))
    assert len(props["cast"]) == 2 and props["mouth"] and [w for _, _, w in props["talk"]] == ["host", "expert"]
    assert not (tmp_path / "robot.glb").exists()                                 # the model copy is cleaned up


@needs_ffmpeg
@pytest.mark.slow(600)
def test_a_pro_video_with_a_2d_presenter(project, tmp_path, monkeypatch):
    if not remotion_render.available()[0]:
        pytest.skip("Remotion not installed")
    monkeypatch.setattr(config, "PRO_PRESENTER", "person-2d")
    monkeypatch.setattr(config, "PRO_AVATAR", "avataaars")
    rate = 24000
    t = np.arange(int(rate * 2.0)) / rate
    tts._write_wav(tmp_path / "narration.wav", (0.3 * np.sin(2 * np.pi * 200 * t)).astype(np.float32), rate)
    sb = {"title": "Scrum", "style": "presenter", "scenes": [
        {"visual": "cards", "heading": "Three roles", "narration": "x",
         "elements": [{"title": "Product Owner", "detail": "Orders the backlog", "icon": "", "value": ""}]}]}
    plan = [(0, {"text": "The Product Owner orders the backlog.", "speaker": "presenter", "pause": 0.3})]
    out = remotion_render.render(tmp_path, sb, plan, [2.0], tmp_path / "narration.wav", pro=True)
    tracks = media.stream_durations(out)
    assert abs(tracks["video"] - 2.0) < 0.2 and abs(tracks["audio"] - 2.0) < 0.3
    props = json.loads((tmp_path / "remotion_props.json").read_text(encoding="utf-8"))
    assert props["character"] == "person-2d" and props["avatar"] == "avataaars" and len(props["cast"]) == 1
    assert not list(tmp_path.glob("*.glb"))                                       # 2D needs no 3D file
